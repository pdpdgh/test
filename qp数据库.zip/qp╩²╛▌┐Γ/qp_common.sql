/*
 Navicat Premium Data Transfer

 Source Server         : master
 Source Server Type    : MySQL
 Source Server Version : 80020
 Source Host           : 192.168.2.191:3306
 Source Schema         : qp_common

 Target Server Type    : MySQL
 Target Server Version : 80020
 File Encoding         : 65001

 Date: 13/06/2020 15:25:22
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for bet_order
-- ----------------------------
DROP TABLE IF EXISTS `bet_order`;
CREATE TABLE `bet_order`  (
  `order_id` int(0) NOT NULL AUTO_INCREMENT COMMENT '注单表id',
  `bet_id` varchar(64) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT '00' COMMENT '注单ID',
  `player_id` bigint(0) NULL DEFAULT NULL COMMENT '玩家ID',
  `platform_type` int(0) NULL DEFAULT NULL COMMENT '平台类型',
  `platform_id` int(0) NULL DEFAULT NULL COMMENT '平台ID',
  `game_id` varchar(30) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT '00' COMMENT '平台子游戏ID',
  `game_lv` int(0) NULL DEFAULT NULL COMMENT '平台游戏房间等级',
  `room_id` int(0) NULL DEFAULT NULL COMMENT '游戏房间ID',
  `match_id` varchar(64) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT '00' COMMENT '游戏牌局ID',
  `bet_gold` decimal(64, 2) NULL DEFAULT 0.00 COMMENT '下注金额',
  `win_gold` decimal(64, 2) NULL DEFAULT 0.00 COMMENT '输赢金额',
  `sit_tax` decimal(64, 2) NULL DEFAULT 0.00 COMMENT '输赢金额',
  `is_banker` int(0) NULL DEFAULT 0 COMMENT '是否庄家（0是 1不是）',
  `begin_time` datetime(6) NULL DEFAULT NULL COMMENT '开始时间',
  `end_time` datetime(6) NULL DEFAULT NULL COMMENT '结束时间',
  `create_time` datetime(6) NULL DEFAULT NULL COMMENT '创建时间',
  `card_info` varchar(64) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT '00' COMMENT '手牌信息',
  `chair_id` int(0) NULL DEFAULT NULL COMMENT '椅子号',
  `lv_name` varchar(64) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT '00' COMMENT '手牌信息',
  `nick_name` varchar(30) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT '00' COMMENT '玩家昵称',
  PRIMARY KEY (`order_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 4447 CHARACTER SET = utf8 COLLATE = utf8_general_ci COMMENT = '玩家注单表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of bet_order
-- ----------------------------
INSERT INTO `bet_order` VALUES (4399, '50-1591095596-129215155-2', 3018882447, 1, 1, '830', 8304, 8304, '50-1591095596-129215155-2', 60.00, -60.00, 0.00, 1, '2020-06-02 18:59:56.000000', '2020-06-02 19:00:23.000000', '2020-06-02 19:25:00.273000', '0938131422251918031a0b2c0c2d081c2a3a29042', 2, '00', '00');
INSERT INTO `bet_order` VALUES (4400, '50-1591095632-129215364-1', 3018882447, 1, 1, '830', 8304, 8304, '50-1591095632-129215364-1', 240.00, -240.00, 0.00, 1, '2020-06-02 19:00:32.000000', '2020-06-02 19:00:53.000000', '2020-06-02 19:25:00.340000', '3d0d2a36050127123b29320b38023c16041a213a3', 1, '00', '00');
INSERT INTO `bet_order` VALUES (4401, '50-1591095557-129214944-5', 3018882447, 1, 1, '860', 8603, 8603, '50-1591095557-129214944-5', 280.00, -280.00, 0.00, 1, '2020-06-02 18:59:17.000000', '2020-06-02 18:59:32.000000', '2020-06-02 19:25:00.380000', '1c27330d2b183807222c17340b3a062', 5, '00', '00');
INSERT INTO `bet_order` VALUES (4402, '50-1591095677-129215626-4', 3018882447, 1, 1, '870', 8704, 8704, '50-1591095677-129215626-4', 300.00, 1425.00, 75.00, 1, '2020-06-02 19:01:17.000000', '2020-06-02 19:01:28.000000', '2020-06-02 19:25:00.418000', '1d1b2a183708072717140302352b150c160419391121282605310a3a22124', 4, '00', '00');
INSERT INTO `bet_order` VALUES (4403, '50-1591095707-129215799-6', 3018882447, 1, 1, '870', 8704, 8704, '50-1591095707-129215799-6', 300.00, -300.00, 0.00, 1, '2020-06-02 19:01:47.000000', '2020-06-02 19:01:58.000000', '2020-06-02 19:25:00.459000', '0a392524322a35070319212c3b38341a3a1c112d18371505060c082836132', 6, '00', '00');
INSERT INTO `bet_order` VALUES (4404, '50-1591095743-129216015-4', 3018882447, 1, 1, '870', 8704, 8704, '50-1591095743-129216015-4', 300.00, -300.00, 0.00, 1, '2020-06-02 19:02:23.000000', '2020-06-02 19:02:34.000000', '2020-06-02 19:25:00.500000', '3d0d1d16352c1b08341339013c31061c0b073705231929222d213b0915023', 4, '00', '00');
INSERT INTO `bet_order` VALUES (4405, '50-1591095770-129216170-6', 3018882447, 1, 1, '870', 8704, 8704, '50-1591095770-129216170-6', 300.00, -300.00, 0.00, 1, '2020-06-02 19:02:50.000000', '2020-06-02 19:03:01.000000', '2020-06-02 19:25:00.559000', '153a050b3829252628123b1d0c1113342d0802311c1b27163219182403352', 6, '00', '00');
INSERT INTO `bet_order` VALUES (4406, '50-1591095797-129216316-5', 3018882447, 1, 1, '870', 8704, 8704, '50-1591095797-129216316-5', 300.00, -300.00, 0.00, 1, '2020-06-02 19:03:17.000000', '2020-06-02 19:03:28.000000', '2020-06-02 19:25:00.596000', '3d1c361502260c3411283c070306220b1b162312310a182714351a253a082', 5, '00', '00');
INSERT INTO `bet_order` VALUES (4407, '50-1591095824-129216479-4', 3018882447, 1, 1, '870', 8704, 8704, '50-1591095824-129216479-4', 300.00, -300.00, 0.00, 1, '2020-06-02 19:03:44.000000', '2020-06-02 19:03:55.000000', '2020-06-02 19:25:00.628000', '2a2c0b2d331719181311240a16142b1d0d2736320734091b2939311c21355', 4, '00', '00');
INSERT INTO `bet_order` VALUES (4408, '50-1591095848-129216610-4', 3018882447, 1, 1, '870', 8704, 8704, '50-1591095848-129216610-4', 300.00, 1425.00, 75.00, 1, '2020-06-02 19:04:08.000000', '2020-06-02 19:04:18.000000', '2020-06-02 19:25:00.670000', '1419172b22012d3a37063b0a1a1635050b150c393d0d3c33021d2a1808134', 4, '00', '00');
INSERT INTO `bet_order` VALUES (4409, '50-1591095878-129216801-4', 3018882447, 1, 1, '870', 8704, 8704, '50-1591095878-129216801-4', 300.00, -300.00, 0.00, 1, '2020-06-02 19:04:38.000000', '2020-06-02 19:04:50.000000', '2020-06-02 19:25:00.694000', '0d1c07362521093b392c153a280231261635143401063319271d3c1a38372', 4, '00', '00');
INSERT INTO `bet_order` VALUES (4410, '50-1591095908-129216985-6', 3018882447, 1, 1, '870', 8704, 8704, '50-1591095908-129216985-6', 300.00, -300.00, 0.00, 1, '2020-06-02 19:05:08.000000', '2020-06-02 19:05:19.000000', '2020-06-02 19:25:00.708000', '3c38132216280a323d1909212c01050b1d0c0d073a1a0615122d2a1817272', 6, '00', '00');
INSERT INTO `bet_order` VALUES (4411, '50-1591095932-129217121-4', 3018882447, 1, 1, '870', 8704, 8704, '50-1591095932-129217121-4', 300.00, -300.00, 0.00, 1, '2020-06-02 19:05:32.000000', '2020-06-02 19:05:41.000000', '2020-06-02 19:25:00.725000', '081737133211213829071d2a182423350a253c280b2b3903120c3d1c01276', 4, '00', '00');
INSERT INTO `bet_order` VALUES (4412, '50-1591096097-129218077-4', 3018882447, 1, 1, '870', 8704, 8704, '50-1591096097-129218077-4', 300.00, -300.00, 0.00, 1, '2020-06-02 19:08:17.000000', '2020-06-02 19:08:29.000000', '2020-06-02 19:25:00.737000', '3d2c3a2905130a270d12090626360323332419083528173902371c38222d6', 4, '00', '00');
INSERT INTO `bet_order` VALUES (4413, '50-1591096136-129218312-4', 3018882447, 1, 1, '870', 8704, 8704, '50-1591096136-129218312-4', 300.00, -300.00, 0.00, 1, '2020-06-02 19:08:56.000000', '2020-06-02 19:09:07.000000', '2020-06-02 19:25:00.753000', '2705281c2a313d0c2616213733122301081424031d0b0a19343a060439181', 4, '00', '00');
INSERT INTO `bet_order` VALUES (4414, '50-1591096169-129218503-6', 3018882447, 1, 1, '870', 8704, 8704, '50-1591096169-129218503-6', 300.00, -300.00, 0.00, 1, '2020-06-02 19:09:29.000000', '2020-06-02 19:09:39.000000', '2020-06-02 19:25:00.764000', '211c1a08071b291923333d3c2b2613253b152c16350c0501093412240d145', 6, '00', '00');
INSERT INTO `bet_order` VALUES (4415, '50-1591096196-129218666-2', 3018882447, 1, 1, '870', 8704, 8704, '50-1591096196-129218666-2', 300.00, -300.00, 0.00, 1, '2020-06-02 19:09:56.000000', '2020-06-02 19:10:08.000000', '2020-06-02 19:25:00.778000', '11212d1615363928233c0d3b0938040c17032402190734353231011d25135', 2, '00', '00');
INSERT INTO `bet_order` VALUES (4416, '50-1591096223-129218819-3', 3018882447, 1, 1, '870', 8704, 8704, '50-1591096223-129218819-3', 300.00, -300.00, 0.00, 1, '2020-06-02 19:10:23.000000', '2020-06-02 19:10:35.000000', '2020-06-02 19:25:00.787000', '2d2a09083421173704133111180c333b0b1915123d3a2706362635391b2b6', 3, '00', '00');
INSERT INTO `bet_order` VALUES (4417, '50-1591096253-129218993-3', 3018882447, 1, 1, '870', 8704, 8704, '50-1591096253-129218993-3', 300.00, -300.00, 0.00, 1, '2020-06-02 19:10:53.000000', '2020-06-02 19:11:05.000000', '2020-06-02 19:25:00.801000', '2c092603220a273329373b241619321c2b3a36151b1d2d11120107022a396', 3, '00', '00');
INSERT INTO `bet_order` VALUES (4418, '50-1591096283-129219163-6', 3018882447, 1, 1, '870', 8704, 8704, '50-1591096283-129219163-6', 300.00, -300.00, 0.00, 1, '2020-06-02 19:11:23.000000', '2020-06-02 19:11:34.000000', '2020-06-02 19:25:00.814000', '2d3a0935141c2b1a262221313938292c0c3b1b0b0619051d1836073711024', 6, '00', '00');
INSERT INTO `bet_order` VALUES (4419, '50-1591096331-129219444-1', 3018882447, 1, 1, '870', 8704, 8704, '50-1591096331-129219444-1', 300.00, -300.00, 0.00, 1, '2020-06-02 19:12:11.000000', '2020-06-02 19:12:22.000000', '2020-06-02 19:25:00.828000', '270b2331283d1b1a26133a351536330d09170512082c321d19372102112b2', 1, '00', '00');
INSERT INTO `bet_order` VALUES (4420, '50-1591095695-129215732-1', 3018882447, 1, 1, '1355', 8704, 8704, '50-1591095695-129215732-1', 1425.00, -1425.00, 0.00, 1, '2020-06-02 19:01:35.000000', '2020-06-02 19:01:35.000000', '2020-06-02 19:25:00.840000', '0', 0, '00', '00');
INSERT INTO `bet_order` VALUES (4421, '50-1591095865-129216733-1', 3018882447, 1, 1, '1355', 8704, 8704, '50-1591095865-129216733-1', 1425.00, -1425.00, 0.00, 1, '2020-06-02 19:04:25.000000', '2020-06-02 19:04:25.000000', '2020-06-02 19:25:00.854000', '0', 0, '00', '00');
INSERT INTO `bet_order` VALUES (4422, '50-1591096779-129221969-2', 3018882447, 1, 1, '510', 5103, 5103, '50-1591096779-129221969-2', 300.00, -300.00, 0.00, 1, '2020-06-02 19:19:39.000000', '2020-06-02 19:19:51.000000', '2020-06-02 19:25:00.867000', '0', 0, '00', '00');
INSERT INTO `bet_order` VALUES (4423, '50-1591096799-129222099-1', 3018882447, 1, 1, '510', 5103, 5103, '50-1591096799-129222099-1', 700.00, -300.00, 0.00, 1, '2020-06-02 19:19:59.000000', '2020-06-02 19:20:23.000000', '2020-06-02 19:25:00.876000', '0', 0, '00', '00');
INSERT INTO `bet_order` VALUES (4424, '50-1591096832-129222279-4', 3018882447, 1, 1, '510', 5103, 5103, '50-1591096832-129222279-4', 8050.00, -300.00, 0.00, 1, '2020-06-02 19:20:32.000000', '2020-06-02 19:21:26.000000', '2020-06-02 19:25:00.886000', '0', 0, '00', '00');
INSERT INTO `bet_order` VALUES (4425, '50-1591096896-129222649-4', 3018882447, 1, 1, '510', 5103, 5103, '50-1591096896-129222649-4', 885.00, -300.00, 0.00, 1, '2020-06-02 19:21:36.000000', '2020-06-02 19:22:01.000000', '2020-06-02 19:25:00.895000', '0', 0, '00', '00');
INSERT INTO `bet_order` VALUES (4426, '50-1591096933-129222843-1', 3018882447, 1, 1, '510', 5102, 5102, '50-1591096933-129222843-1', 410.00, -300.00, 0.00, 1, '2020-06-02 19:22:13.000000', '2020-06-02 19:22:28.000000', '2020-06-02 19:25:00.906000', '0', 0, '00', '00');
INSERT INTO `bet_order` VALUES (4427, '50-1591096956-129222974-2', 3018882447, 1, 1, '510', 5101, 5101, '50-1591096956-129222974-2', 405.00, -300.00, 0.00, 1, '2020-06-02 19:22:36.000000', '2020-06-02 19:23:11.000000', '2020-06-02 19:25:00.917000', '0', 0, '00', '00');
INSERT INTO `bet_order` VALUES (4428, '50-1591097001-129223220-1', 3018882447, 1, 1, '510', 5101, 5101, '50-1591097001-129223220-1', 770.00, -300.00, 0.00, 1, '2020-06-02 19:23:21.000000', '2020-06-02 19:23:40.000000', '2020-06-02 19:25:00.929000', '0', 0, '00', '00');
INSERT INTO `bet_order` VALUES (4429, '50-1591095425-129214246-2', 3018882447, 1, 1, '1860', 18603, 18603, '50-1591095425-129214246-2', 50.00, -50.00, 0.00, 1, '2020-06-02 18:57:05.000000', '2020-06-02 18:57:49.000000', '2020-06-02 19:25:00.942000', '3832251c0c12192c28391600000737141a0', 2, '00', '00');
INSERT INTO `bet_order` VALUES (4430, '50-1591095461-129214436-2', 3018882447, 1, 1, '1860', 18603, 18603, '50-1591095461-129214436-2', 150.00, -150.00, 0.00, 1, '2020-06-02 18:57:41.000000', '2020-06-02 18:58:24.000000', '2020-06-02 19:25:00.953000', '091412351d321b36253731081700003c020', 2, '00', '00');
INSERT INTO `bet_order` VALUES (4431, '686-1591104532-15774083-3', 3018882447, 1, 8, '510', 5103, 5103, '686-1591104532-15774083-3', 20100.00, 14800.00, 0.00, 1, '2020-06-02 21:28:52.000000', '2020-06-02 21:30:28.000000', '2020-06-02 22:00:10.312000', '00', 0, '00', '00');
INSERT INTO `bet_order` VALUES (4432, '686-1591104628-15774083-3', 3018882447, 1, 8, '510', 5103, 5103, '686-1591104628-15774083-3', 26700.00, 22000.00, 0.00, 1, '2020-06-02 21:30:28.000000', '2020-06-02 21:32:24.000000', '2020-06-02 22:00:10.395000', '00', 0, '00', '00');
INSERT INTO `bet_order` VALUES (4433, '686-1591104744-15774083-3', 3018882447, 1, 8, '510', 5103, 5103, '686-1591104744-15774083-3', 25000.00, 11250.00, 0.00, 1, '2020-06-02 21:32:24.000000', '2020-06-02 21:34:02.000000', '2020-06-02 22:00:10.440000', '00', 0, '00', '00');
INSERT INTO `bet_order` VALUES (4434, '686-1591104842-15774083-3', 3018882447, 1, 8, '510', 5103, 5103, '686-1591104842-15774083-3', 23500.00, 4500.00, 0.00, 1, '2020-06-02 21:34:02.000000', '2020-06-02 21:35:47.000000', '2020-06-02 22:00:10.470000', '00', 0, '00', '00');
INSERT INTO `bet_order` VALUES (4435, '686-1591104947-15774083-3', 3018882447, 1, 8, '510', 5103, 5103, '686-1591104947-15774083-3', 27800.00, 2250.00, 0.00, 1, '2020-06-02 21:35:47.000000', '2020-06-02 21:37:37.000000', '2020-06-02 22:00:10.496000', '00', 0, '00', '00');
INSERT INTO `bet_order` VALUES (4436, '686-1591105057-15774083-3', 3018882447, 1, 8, '510', 5103, 5103, '686-1591105057-15774083-3', 25750.00, -1950.00, 0.00, 1, '2020-06-02 21:37:37.000000', '2020-06-02 21:39:37.000000', '2020-06-02 22:00:10.533000', '00', 0, '00', '00');
INSERT INTO `bet_order` VALUES (4437, '686-1591105177-15774083-3', 3018882447, 1, 8, '510', 5103, 5103, '686-1591105177-15774083-3', 29800.00, -1050.00, 0.00, 1, '2020-06-02 21:39:37.000000', '2020-06-02 21:41:33.000000', '2020-06-02 22:00:10.580000', '00', 0, '00', '00');
INSERT INTO `bet_order` VALUES (4438, '686-1591105293-15774083-3', 3018882447, 1, 8, '510', 5103, 5103, '686-1591105293-15774083-3', 11400.00, 10300.00, 0.00, 1, '2020-06-02 21:41:33.000000', '2020-06-02 21:43:16.000000', '2020-06-02 22:00:10.612000', '00', 0, '00', '00');
INSERT INTO `bet_order` VALUES (4439, '686-1591105611-15774083-4', 3018882447, 1, 8, '510', 5103, 5103, '686-1591105611-15774083-4', 1400.00, 700.00, 0.00, 1, '2020-06-02 21:46:51.000000', '2020-06-02 21:48:22.000000', '2020-06-02 22:00:10.639000', '00', 0, '00', '00');
INSERT INTO `bet_order` VALUES (4440, '686-1591105702-15774083-4', 3018882447, 1, 8, '510', 5103, 5103, '686-1591105702-15774083-4', 26300.00, 19550.00, 0.00, 1, '2020-06-02 21:48:22.000000', '2020-06-02 21:50:13.000000', '2020-06-02 22:00:10.666000', '00', 0, '00', '00');
INSERT INTO `bet_order` VALUES (4441, '686-1591105813-15774083-4', 3018882447, 1, 8, '510', 5103, 5103, '686-1591105813-15774083-4', 2850.00, -850.00, 0.00, 1, '2020-06-02 21:50:13.000000', '2020-06-02 21:52:12.000000', '2020-06-02 22:00:10.696000', '00', 0, '00', '00');
INSERT INTO `bet_order` VALUES (4442, '686-1591105932-15774083-4', 3018882447, 1, 8, '510', 5103, 5103, '686-1591105932-15774083-4', 36350.00, -5700.00, 0.00, 1, '2020-06-02 21:52:12.000000', '2020-06-02 21:54:36.000000', '2020-06-02 22:00:10.729000', '00', 0, '00', '00');
INSERT INTO `bet_order` VALUES (4443, '686-1591106076-15774083-4', 3018882447, 1, 8, '510', 5103, 5103, '686-1591106076-15774083-4', 13950.00, 15900.00, 0.00, 1, '2020-06-02 21:54:36.000000', '2020-06-02 21:56:22.000000', '2020-06-02 22:00:10.760000', '00', 0, '00', '00');
INSERT INTO `bet_order` VALUES (4444, '5250152319531', 3018874663, 1, 6, '18005', 18005, 18, '200554313', 6.00, 5.70, -0.30, 1, '2020-06-03 16:57:27.000000', '2020-06-03 16:57:27.000000', '2020-06-03 17:01:00.248000', '5250152319531', 0, '00', '00');
INSERT INTO `bet_order` VALUES (4445, '5250152319560', 3018874663, 1, 6, '18005', 18005, 18, '200554488', 3.00, -3.00, 0.00, 1, '2020-06-03 16:58:26.000000', '2020-06-03 16:58:26.000000', '2020-06-03 17:02:30.322000', '5250152319560', 0, '00', '00');
INSERT INTO `bet_order` VALUES (4446, '5250152319584', 3018874663, 1, 6, '18005', 18005, 18, '200554609', 2.00, 1.90, -0.10, 1, '2020-06-03 16:59:05.000000', '2020-06-03 16:59:05.000000', '2020-06-03 17:03:00.192000', '5250152319584', 0, '00', '00');
INSERT INTO `bet_order` VALUES (4447, '5250152319607', 3018874663, 1, 6, '18005', 18005, 18, '200554729', 9.00, -9.00, 0.00, 1, '2020-06-03 16:59:48.000000', '2020-06-03 16:59:48.000000', '2020-06-03 17:03:00.226000', '5250152319607', 0, '00', '00');

-- ----------------------------
-- Table structure for bet_order_copy1
-- ----------------------------
DROP TABLE IF EXISTS `bet_order_copy1`;
CREATE TABLE `bet_order_copy1`  (
  `order_id` int(0) NOT NULL AUTO_INCREMENT COMMENT '注单表id',
  `bet_id` varchar(64) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT '00' COMMENT '注单ID',
  `player_id` bigint(0) NULL DEFAULT NULL COMMENT '玩家ID',
  `platform_type` int(0) NULL DEFAULT NULL COMMENT '平台类型',
  `platform_id` int(0) NULL DEFAULT NULL COMMENT '平台ID',
  `game_id` varchar(30) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT '00' COMMENT '平台子游戏ID',
  `game_lv` int(0) NULL DEFAULT NULL COMMENT '平台游戏房间等级',
  `room_id` int(0) NULL DEFAULT NULL COMMENT '游戏房间ID',
  `match_id` varchar(64) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT '00' COMMENT '游戏牌局ID',
  `bet_gold` decimal(64, 2) NULL DEFAULT 0.00 COMMENT '下注金额',
  `win_gold` decimal(64, 2) NULL DEFAULT 0.00 COMMENT '输赢金额',
  `sit_tax` decimal(64, 2) NULL DEFAULT 0.00 COMMENT '输赢金额',
  `is_banker` int(0) NULL DEFAULT 0 COMMENT '是否庄家（0是 1不是）',
  `begin_time` datetime(6) NULL DEFAULT NULL COMMENT '开始时间',
  `end_time` datetime(6) NULL DEFAULT NULL COMMENT '结束时间',
  `create_time` datetime(6) NULL DEFAULT NULL COMMENT '创建时间',
  `card_info` varchar(64) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT '00' COMMENT '手牌信息',
  `chair_id` int(0) NULL DEFAULT NULL COMMENT '椅子号',
  `lv_name` varchar(64) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT '00' COMMENT '手牌信息',
  `nick_name` varchar(30) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT '00' COMMENT '玩家昵称',
  PRIMARY KEY (`order_id`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci COMMENT = '玩家注单表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of bet_order_copy1
-- ----------------------------

-- ----------------------------
-- Table structure for platform_game_list
-- ----------------------------
DROP TABLE IF EXISTS `platform_game_list`;
CREATE TABLE `platform_game_list`  (
  `uuid` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '唯一标识符',
  `p_id` int(0) NULL DEFAULT NULL COMMENT '平台编号',
  `p_name` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '平台名称',
  `p_icon` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '平台图标',
  `icon` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '游戏ICON',
  `name` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '游戏名称',
  `game_no` varchar(256) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '对方游戏编号',
  `sort` int(0) NULL DEFAULT NULL COMMENT '排序',
  `edit_time` datetime(0) NULL DEFAULT NULL COMMENT '修改时间',
  `edit_user` varchar(256) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '修改人',
  `is_enable` tinyint(1) NULL DEFAULT NULL COMMENT '是否启用',
  `is_recommend` tinyint(1) NULL DEFAULT NULL COMMENT '是否推荐',
  `is_maintain` tinyint(1) NULL DEFAULT NULL COMMENT '是否维护',
  `is_vertical` tinyint(1) NULL DEFAULT NULL COMMENT '是否竖屏',
  `puuid` int(0) NULL DEFAULT NULL COMMENT '对应平台的唯一标识符',
  `icon_name` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '图片原本名称',
  `open_time` int(0) NULL DEFAULT NULL COMMENT '在线多长时间就开启, 单位:分钟, 空与0表示不限制',
  `is_del` tinyint(1) NULL DEFAULT 0 COMMENT '是否删除 0 是 1否',
  PRIMARY KEY (`uuid`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci COMMENT = '第三方游戏列表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of platform_game_list
-- ----------------------------
INSERT INTO `platform_game_list` VALUES ('1_1_10', 1, '开元棋牌', '/KYqipai.png', '/icon/KY_QP/抢庄牌九_360.png', '抢庄牌九', '730', 9, NULL, 'admins', 1, 1, 0, 1, 1, NULL, NULL, 0);
INSERT INTO `platform_game_list` VALUES ('1_1_11', 1, '开元棋牌', '/KYqipai.png', '/icon/KY_QP/十三水_360.png', '十三水', '630', 10, NULL, 'admins', 1, 1, 0, 1, 1, NULL, NULL, 0);
INSERT INTO `platform_game_list` VALUES ('1_1_12', 1, '开元棋牌', '/KYqipai.png', '/icon/KY_QP/斗地主_360.png', '斗地主', '610', 11, NULL, 'admins', 1, 1, 0, 1, 1, NULL, NULL, 0);
INSERT INTO `platform_game_list` VALUES ('1_1_13', 1, '开元棋牌', '/KYqipai.png', '/icon/KY_QP/百家乐_360.png', '百家乐', '910', 12, NULL, 'admins', 1, 1, 0, 1, 1, NULL, NULL, 0);
INSERT INTO `platform_game_list` VALUES ('1_1_14', 1, '开元棋牌', '/KYqipai.png', '/icon/KY_QP/森林舞会_360.png', '森林舞会', '920', 13, NULL, 'admins', 1, 1, 0, 1, 1, NULL, NULL, 0);
INSERT INTO `platform_game_list` VALUES ('1_1_15', 1, '开元棋牌', '/KYqipai.png', '/icon/KY_QP/百人牛牛_360.png', '百人牛牛', '930', 14, NULL, 'admins', 1, 1, 0, 1, 1, NULL, NULL, 0);
INSERT INTO `platform_game_list` VALUES ('1_1_16', 1, '开元棋牌', '/KYqipai.png', '/icon/KY_QP/万人炸金花_360.png', '万人炸金花', '1950', 15, NULL, 'admins', 1, 1, 0, 1, 1, NULL, NULL, 0);
INSERT INTO `platform_game_list` VALUES ('1_1_17', 1, '开元棋牌', '/KYqipai.png', '/icon/KY_QP/血流麻将360x360.png', '血流成河', '650', 16, NULL, 'admins', 1, 1, 0, 1, 1, NULL, NULL, 0);
INSERT INTO `platform_game_list` VALUES ('1_1_18', 1, '开元棋牌', '/KYqipai.png', '/icon/KY_QP/kpqznn-360.png', '看牌抢庄牛牛', '890', 17, NULL, 'admins', 1, 1, 0, 1, 1, NULL, NULL, 0);
INSERT INTO `platform_game_list` VALUES ('1_1_19', 1, '开元棋牌', '/KYqipai.png', '/icon/KY_QP/二人麻将360x360.png', '二人麻将', '740', 18, NULL, 'admins', 1, 1, 0, 1, 1, NULL, NULL, 0);
INSERT INTO `platform_game_list` VALUES ('1_1_2', 1, '', '', '/icon/KY_QP/二八杠_360.png', '二八杠', '720', 1, NULL, 'admins', 1, 1, 0, 1, 1, NULL, NULL, 0);
INSERT INTO `platform_game_list` VALUES ('1_1_20', 1, '开元棋牌', '/KYqipai.png', '/icon/KY_QP/金沙银沙_360.png', '金鲨银鲨', '1940', 19, NULL, 'admins', 1, 1, 0, 1, 1, NULL, NULL, 0);
INSERT INTO `platform_game_list` VALUES ('1_1_21', 1, '开元棋牌', '/KYqipai.png', '/icon/KY_QP/奔驰宝马_360.png', '奔驰宝马', '1960', 20, NULL, 'admins', 1, 1, 0, 1, 1, NULL, NULL, 0);
INSERT INTO `platform_game_list` VALUES ('1_1_22', 1, '开元棋牌', '/KYqipai.png', '/icon/KY_QP/brtb_360x360.png', '百人骰宝', '1980', 21, NULL, 'admins', 1, 1, 0, 1, 1, NULL, NULL, 0);
INSERT INTO `platform_game_list` VALUES ('1_1_23', 1, '开元棋牌', '/KYqipai.png', '/icon/KY_QP/dtnn_360x360.png', '单挑牛牛', '1810', 22, NULL, 'admins', 1, 1, 0, 1, 1, NULL, NULL, 0);
INSERT INTO `platform_game_list` VALUES ('1_1_24', 1, '开元棋牌', '/KYqipai.png', '/icon/KY_QP/zjn_360x360.png', '炸金牛', '1990', 23, NULL, 'admins', 1, 1, 0, 1, 1, NULL, NULL, 0);
INSERT INTO `platform_game_list` VALUES ('1_1_25', 1, '开元棋牌', '/KYqipai.png', '/icon/KY_QP/ybqznn_360x360.png', '押宝抢庄牛牛', '1850', 24, NULL, 'admins', 1, 1, 0, 1, 1, NULL, NULL, 0);
INSERT INTO `platform_game_list` VALUES ('1_1_26', 1, '开元棋牌', '/KYqipai.png', '/icon/KY_QP/hbby_360x360.png', '红包捕鱼', '510', 25, NULL, 'admins', 1, 1, 0, 1, 1, NULL, NULL, 0);
INSERT INTO `platform_game_list` VALUES ('1_1_27', 1, '开元棋牌', '/KYqipai.png', '/icon/KY_QP/wxhh_360x360.png', '五星宏辉', '1970', 26, NULL, 'admins', 1, 1, 0, 1, 1, NULL, NULL, 0);
INSERT INTO `platform_game_list` VALUES ('1_1_28', 1, '开元棋牌', '/KYqipai.png', '/icon/KY_QP/dcpk_360x360.png', '赌场扑克', '1860', 27, NULL, 'admins', 1, 1, 0, 1, 1, NULL, NULL, 0);
INSERT INTO `platform_game_list` VALUES ('1_1_29', 1, '开元棋牌', '/KYqipai.png', '/icon/KY_QP/gssh_360x360.png', '港式梭哈', '1370', 28, NULL, 'admins', 1, 1, 0, 1, 1, NULL, NULL, 0);
INSERT INTO `platform_game_list` VALUES ('1_1_3', 1, '', '', '/icon/KY_QP/抢庄牛牛_360.png', '抢庄牛牛', '830', 2, NULL, 'admins', 1, 1, 0, 1, 1, NULL, NULL, 0);
INSERT INTO `platform_game_list` VALUES ('1_1_30', 1, '开元棋牌', '/KYqipai.png', '/icon/KY_QP/wztb_360x360.png', '血战骰宝', '1690', 29, NULL, 'admins', 1, 1, 0, 1, 1, NULL, NULL, 0);
INSERT INTO `platform_game_list` VALUES ('1_1_4', 1, '', '', '/icon/KY_QP/炸金花_360.png', '炸金花', '220', 3, NULL, 'admins', 1, 1, 0, 1, 1, NULL, NULL, 0);
INSERT INTO `platform_game_list` VALUES ('1_1_5', 1, '', '', '/icon/KY_QP/三公_360.png', '三公', '860', 4, NULL, 'admins', 1, 1, 0, 1, 1, NULL, NULL, 0);
INSERT INTO `platform_game_list` VALUES ('1_1_6', 1, '开元棋牌', '/KYqipai.png', '/icon/KY_QP/押庄龙虎_360.png', '押庄龙虎', '900', 5, NULL, 'admins', 1, 1, 0, 1, 1, NULL, NULL, 0);
INSERT INTO `platform_game_list` VALUES ('1_1_7', 1, '开元棋牌', '/KYqipai.png', '/icon/KY_QP/21点_360.png', '21点', '600', 6, NULL, 'admins', 1, 1, 0, 1, 1, NULL, NULL, 0);
INSERT INTO `platform_game_list` VALUES ('1_1_8', 1, '开元棋牌', '/KYqipai.png', '/icon/KY_QP/通比牛牛_360.png', '通比牛牛', '870', 7, NULL, 'admins', 1, 1, 0, 1, 1, NULL, NULL, 0);
INSERT INTO `platform_game_list` VALUES ('1_1_9', 1, '开元棋牌', '/KYqipai.png', '/icon/KY_QP/极速炸金花_360.png', '极速炸金花', '230', 8, NULL, 'admins', 1, 1, 0, 1, 1, NULL, NULL, 0);
INSERT INTO `platform_game_list` VALUES ('5_5_10', 5, '', '', '/icon/SY_QP/HJ_Button_dezhoupuke.png', '德州扑克', '14', 9, NULL, 'admins', 1, 0, 0, 1, 5, NULL, NULL, 0);
INSERT INTO `platform_game_list` VALUES ('5_5_2', 5, '', '', '/icon/SY_QP/HJ_Button_bairennunu.png', '百人牛牛', '1', 1, NULL, 'admins', 1, 0, 0, 1, 5, NULL, NULL, 0);
INSERT INTO `platform_game_list` VALUES ('5_5_3', 5, '', '', '/icon/SY_QP/HJ_Button_zhajinhua.png', '炸金花', '2', 2, NULL, 'admins', 1, 0, 0, 1, 5, NULL, NULL, 0);
INSERT INTO `platform_game_list` VALUES ('5_5_4', 5, '', '', '/icon/SY_QP/HJ_Button_longhudong.png', '龙虎斗', '3', 3, NULL, 'admins', 1, 0, 0, 1, 5, NULL, NULL, 0);
INSERT INTO `platform_game_list` VALUES ('5_5_5', 5, '', '', '/icon/SY_QP/HJ_Button_hongheidajian.png', '红黑大战', '4', 4, NULL, 'admins', 1, 0, 0, 1, 5, NULL, NULL, 0);
INSERT INTO `platform_game_list` VALUES ('5_5_6', 5, '', '', '/icon/SY_QP/HJ_Button_qianghongbao2.png', '抢红包', '6', 5, NULL, 'admins', 1, 0, 0, 1, 5, NULL, NULL, 0);
INSERT INTO `platform_game_list` VALUES ('5_5_7', 5, '', '', '/icon/SY_QP/HJ_Button_labaji.png', '拉霸', '7', 6, NULL, 'admins', 1, 0, 0, 1, 5, NULL, NULL, 0);
INSERT INTO `platform_game_list` VALUES ('5_5_8', 5, '', '', '/icon/SY_QP/HJ_Button_dongdizhu.png', '斗地主正式', '10', 7, NULL, 'admins', 1, 0, 0, 1, 5, NULL, NULL, 0);
INSERT INTO `platform_game_list` VALUES ('5_5_9', 5, '', '', '/icon/SY_QP/HJ_Button_errenmajiang.png', '二人麻将', '11', 8, NULL, 'admins', 1, 0, 0, 1, 5, NULL, NULL, 0);
INSERT INTO `platform_game_list` VALUES ('611_6_10', 6, '', '', '/icon/JDB_QP/18012_291x136(蛾)_cn.png', '百变抢庄牛牛', '18,18012', 9, NULL, 'admins', 0, 0, 0, 1, 611, NULL, NULL, 0);
INSERT INTO `platform_game_list` VALUES ('611_6_11', 6, '', '', '/icon/JDB_QP/18013_291x136(蛾)_cn.png', '通比六牛', '18,18013', 10, NULL, 'admins', 1, 0, 0, 1, 611, NULL, NULL, 0);
INSERT INTO `platform_game_list` VALUES ('611_6_12', 6, '', '', '/icon/JDB_QP/18015_291x136(蛾)_cn.png', '千变百人牛牛', '18,18015', 11, NULL, 'admins', 0, 0, 0, 1, 611, NULL, NULL, 0);
INSERT INTO `platform_game_list` VALUES ('611_6_13', 6, '', '', '/icon/JDB_QP/18016_291x136(蛾)_cn.png', '极速炸金花', '18,18016', 12, NULL, 'admins', 0, 0, 0, 1, 611, NULL, NULL, 0);
INSERT INTO `platform_game_list` VALUES ('611_6_14', 6, '', '', '/icon/JDB_QP/18017_291x136(蛾)_cn.png', '抢庄三公', '18,18017', 13, NULL, 'admins', 0, 0, 0, 1, 611, NULL, NULL, 0);
INSERT INTO `platform_game_list` VALUES ('611_6_15', 6, '', '', '/icon/JDB_QP/18018_291x136(蛾)_cn.png', '德州抢庄斗牛', '18,18018', 14, NULL, 'admins', 0, 0, 0, 1, 611, NULL, NULL, 0);
INSERT INTO `platform_game_list` VALUES ('611_6_2', 6, '', '', '/icon/JDB_QP/18001_291x136(蛾)_cn.png', '通比牛牛', '18,18001', 1, NULL, 'admins', 1, 0, 0, 1, 611, NULL, NULL, 0);
INSERT INTO `platform_game_list` VALUES ('611_6_3', 6, '', '', '/icon/JDB_QP/18002_291x136(蛾)_cn.png', '抢庄牛牛', '18,18002', 2, NULL, 'admins', 1, 0, 0, 1, 611, NULL, NULL, 0);
INSERT INTO `platform_game_list` VALUES ('611_6_4', 6, '', '', '/icon/JDB_QP/18004_291x136(蛾)_cn.png', '押庄射龙门', '18,18004', 3, NULL, 'admins', 1, 0, 0, 1, 611, NULL, NULL, 0);
INSERT INTO `platform_game_list` VALUES ('611_6_5', 6, '', '', '/icon/JDB_QP/18014_291x136(蛾)_cn.png', '抢庄六牛', '18,18005', 4, NULL, 'admins', 1, 0, 0, 1, 611, NULL, NULL, 0);
INSERT INTO `platform_game_list` VALUES ('611_6_6', 6, '', '', '/icon/JDB_QP/18006_291x136(蛾)_cn.png', '押庄龙虎斗', '18,18006', 5, NULL, 'admins', 0, 0, 0, 1, 611, NULL, NULL, 0);
INSERT INTO `platform_game_list` VALUES ('611_6_7', 6, '', '', '/icon/JDB_QP/18008_291x136(蛾)_cn.png', '通比德州斗牛', '18,18008', 6, NULL, 'admins', 0, 0, 0, 1, 611, NULL, NULL, 0);
INSERT INTO `platform_game_list` VALUES ('611_6_8', 6, '', '', '/icon/JDB_QP/18010_291x136(蛾)_cn.png', '金葫芦5PK', '18,18010', 7, NULL, 'admins', 0, 0, 0, 1, 611, NULL, NULL, 0);
INSERT INTO `platform_game_list` VALUES ('611_6_9', 6, '', '', '/icon/JDB_QP/18011_291x136(蛾)_cn.png', '幸运星5PK', '18,18011', 8, NULL, 'admins', 0, 0, 0, 1, 611, NULL, NULL, 0);
INSERT INTO `platform_game_list` VALUES ('711_7_10', 7, '', '', '/icon/FG_QP/6301斗地主.png', '斗地主', '6301', 9, NULL, 'admins', 1, 0, 0, 1, 711, NULL, NULL, 0);
INSERT INTO `platform_game_list` VALUES ('711_7_11', 7, '', '', '/icon/FG_QP/6302经典炸金花.png', '经典炸金花', '6302', 10, NULL, 'admins', 1, 0, 0, 1, 711, NULL, NULL, 0);
INSERT INTO `platform_game_list` VALUES ('711_7_12', 7, '', '', '/icon/FG_QP/6303梭哈.png', '梭哈', '6303', 11, NULL, 'admins', 1, 0, 0, 1, 711, NULL, NULL, 0);
INSERT INTO `platform_game_list` VALUES ('711_7_13', 7, '', '', '/icon/FG_QP/6504通比牛牛.png', '通比牛牛', '6504', 12, NULL, 'admins', 1, 0, 0, 1, 711, NULL, NULL, 0);
INSERT INTO `platform_game_list` VALUES ('711_7_14', 7, '', '', '/icon/FG_QP/6012二八杠.png', '二八杠', '6012', 13, NULL, 'admins', 1, 0, 0, 1, 711, NULL, NULL, 0);
INSERT INTO `platform_game_list` VALUES ('711_7_15', 7, '', '', '/icon/FG_QP/6013抢庄牌九.png', '抢庄牌九', '6013', 14, NULL, 'admins', 1, 0, 0, 1, 711, NULL, NULL, 0);
INSERT INTO `platform_game_list` VALUES ('711_7_16', 7, '', '', '/icon/FG_QP/6666欢乐德州.png', '欢乐德州', '6666', 15, NULL, 'admins', 1, 0, 0, 1, 711, NULL, NULL, 0);
INSERT INTO `platform_game_list` VALUES ('711_7_17', 7, '', '', '/icon/FG_QP/6506欢乐红包.png', '欢乐红包', '6506', 16, NULL, 'admins', 1, 0, 0, 1, 711, NULL, NULL, 0);
INSERT INTO `platform_game_list` VALUES ('711_7_18', 7, '', '', '/icon/FG_QP/6667欢乐麻将.png', '欢乐麻将', '6667', 17, NULL, 'admins', 1, 0, 0, 1, 711, NULL, NULL, 0);
INSERT INTO `platform_game_list` VALUES ('711_7_19', 7, '', '', '/icon/FG_QP/6010二十一点.png', '21点', '6010', 18, NULL, 'admins', 1, 0, 0, 1, 711, NULL, NULL, 0);
INSERT INTO `platform_game_list` VALUES ('711_7_2', 7, '', '', '/icon/FG_QP/6003百人牛牛.png', '百人牛牛', '6003', 1, NULL, 'admins', 1, 0, 0, 1, 711, NULL, NULL, 0);
INSERT INTO `platform_game_list` VALUES ('711_7_20', 7, '', '', '/icon/FG_QP/6507五星宏辉.png', '五星宏辉', '6507', 19, NULL, 'admins', 1, 0, 0, 1, 711, NULL, NULL, 0);
INSERT INTO `platform_game_list` VALUES ('711_7_21', 7, '', '', '/icon/FG_QP/6015关秦龙虎斗.png', '关秦龙虎斗', '6015', 20, NULL, 'admins', 1, 0, 0, 1, 711, NULL, NULL, 0);
INSERT INTO `platform_game_list` VALUES ('711_7_22', 7, '', '', '/icon/FG_QP/6016百人骰宝.png', '百人骰宝', '6016', 21, NULL, 'admins', 1, 0, 0, 1, 711, NULL, NULL, 0);
INSERT INTO `platform_game_list` VALUES ('711_7_23', 7, '', '', '/icon/FG_QP/6701抢庄牛牛3D.png', '抢庄牛牛3D', '6701', 22, NULL, 'admins', 1, 0, 0, 1, 711, NULL, NULL, 0);
INSERT INTO `platform_game_list` VALUES ('711_7_24', 7, '', '', '/icon/FG_QP/6702欢乐麻将3D.png', '欢乐麻将3D', '6702', 23, NULL, 'admins', 1, 0, 0, 1, 711, NULL, NULL, 0);
INSERT INTO `platform_game_list` VALUES ('711_7_25', 7, '', '', '/icon/FG_QP/6703乐斗牛魔王.png', '乐斗牛魔王3D', '6703', 24, NULL, 'admins', 1, 0, 0, 1, 711, NULL, NULL, 0);
INSERT INTO `platform_game_list` VALUES ('711_7_3', 7, '', '', '/icon/FG_QP/6005骰宝.png', '骰宝', '6005', 2, NULL, 'admins', 1, 0, 0, 1, 711, NULL, NULL, 0);
INSERT INTO `platform_game_list` VALUES ('711_7_4', 7, '', '', '/icon/FG_QP/6006百家乐.png', '百家乐', '6006', 3, NULL, 'admins', 1, 0, 0, 1, 711, NULL, NULL, 0);
INSERT INTO `platform_game_list` VALUES ('711_7_5', 7, '', '', '/icon/FG_QP/6008红黑大战.png', '红黑大战', '6008', 4, NULL, 'admins', 1, 0, 0, 1, 711, NULL, NULL, 0);
INSERT INTO `platform_game_list` VALUES ('711_7_6', 7, '', '', '/icon/FG_QP/6009德州牛仔.png', '德州牛仔', '6009', 5, NULL, 'admins', 1, 0, 0, 1, 711, NULL, NULL, 0);
INSERT INTO `platform_game_list` VALUES ('711_7_7', 7, '', '', '/icon/FG_QP/6007二人麻将.png', '二人麻将', '6007', 6, NULL, 'admins', 1, 0, 0, 1, 711, NULL, NULL, 0);
INSERT INTO `platform_game_list` VALUES ('711_7_8', 7, '', '', '/icon/FG_QP/6501抢庄牛牛.png', '抢庄牛牛', '6501', 7, NULL, 'admins', 1, 0, 0, 1, 711, NULL, NULL, 0);
INSERT INTO `platform_game_list` VALUES ('711_7_9', 7, '', '', '/icon/FG_QP/6502三公.png', '三公', '6502', 8, NULL, 'admins', 1, 0, 0, 1, 711, NULL, NULL, 0);
INSERT INTO `platform_game_list` VALUES ('8_8_10', 8, '', '', '/icon/LY_QP/极速炸金花.png', '极速炸金花', '230', 9, NULL, 'admins', 1, 0, 0, 1, 8, NULL, NULL, 0);
INSERT INTO `platform_game_list` VALUES ('8_8_11', 8, '', '', '/icon/LY_QP/抢庄牌九.png', '抢庄牌九', '730', 10, NULL, 'admins', 1, 0, 0, 1, 8, NULL, NULL, 0);
INSERT INTO `platform_game_list` VALUES ('8_8_12', 8, '', '', '/icon/LY_QP/十三水.png', '十三水', '630', 11, NULL, 'admins', 1, 0, 0, 1, 8, NULL, NULL, 0);
INSERT INTO `platform_game_list` VALUES ('8_8_13', 8, '', '', '/icon/LY_QP/斗地主.png', '斗地主', '610', 12, NULL, 'admins', 1, 0, 0, 1, 8, NULL, NULL, 0);
INSERT INTO `platform_game_list` VALUES ('8_8_14', 8, '', '', '/icon/LY_QP/看三张抢庄牛牛.png', '看三张抢庄牛牛', '890', 13, NULL, 'admins', 1, 0, 0, 1, 8, NULL, NULL, 0);
INSERT INTO `platform_game_list` VALUES ('8_8_15', 8, '', '', '/icon/LY_QP/百家乐.png', '百家乐', '910', 14, NULL, 'admins', 1, 0, 0, 1, 8, NULL, NULL, 0);
INSERT INTO `platform_game_list` VALUES ('8_8_16', 8, '', '', '/icon/LY_QP/红黑大战.png', '红黑大战', '950', 15, NULL, 'admins', 1, 0, 0, 1, 8, NULL, NULL, 0);
INSERT INTO `platform_game_list` VALUES ('8_8_17', 8, '', '', '/icon/LY_QP/二人麻将.png', '二人麻将', '740', 16, NULL, 'admins', 1, 0, 0, 1, 8, NULL, NULL, 0);
INSERT INTO `platform_game_list` VALUES ('8_8_18', 8, '', '', '/icon/LY_QP/百人牛牛.png', '百人牛牛', '930', 17, NULL, 'admins', 1, 0, 0, 1, 8, NULL, NULL, 0);
INSERT INTO `platform_game_list` VALUES ('8_8_19', 8, '', '', '/icon/LY_QP/捕鱼大作战.png', '捕鱼大作战', '510', 18, NULL, 'admins', 1, 0, 0, 1, 8, NULL, NULL, 0);
INSERT INTO `platform_game_list` VALUES ('8_8_2', 8, '', '', '/icon/LY_QP/德州扑克.png', '德州扑克', '620', 1, NULL, 'admins', 1, 0, 0, 1, 8, NULL, NULL, 0);
INSERT INTO `platform_game_list` VALUES ('8_8_20', 8, '', '', '/icon/LY_QP/血战到底.png', '血战到底', '8120', 19, NULL, 'admins', 1, 0, 0, 1, 8, NULL, NULL, 0);
INSERT INTO `platform_game_list` VALUES ('8_8_21', 8, '', '', '/icon/LY_QP/森林舞会.png', '森林舞会', '920', 20, NULL, 'admins', 1, 0, 0, 1, 8, NULL, NULL, 0);
INSERT INTO `platform_game_list` VALUES ('8_8_22', 8, '', '', '/icon/LY_QP/看四张抢庄牛牛.png', '看四张抢庄牛牛', '8150', 21, NULL, 'admins', 1, 0, 0, 1, 8, NULL, NULL, 0);
INSERT INTO `platform_game_list` VALUES ('8_8_23', 8, '', '', '/icon/LY_QP/癞子牛牛.png', '癞子牛牛', '8160', 22, NULL, 'admins', 1, 0, 0, 1, 8, NULL, NULL, 0);
INSERT INTO `platform_game_list` VALUES ('8_8_24', 8, '', '', '/icon/LY_QP/跑得快.png', '跑得快', '8130', 23, NULL, 'admins', 1, 0, 0, 1, 8, NULL, NULL, 0);
INSERT INTO `platform_game_list` VALUES ('8_8_25', 8, '', '', '/icon/LY_QP/万人推筒子.png', '万人推筒子', '8190', 24, NULL, 'admins', 1, 0, 0, 1, 8, NULL, NULL, 0);
INSERT INTO `platform_game_list` VALUES ('8_8_26', 8, '', '', '/icon/LY_QP/抢庄选三张.png', '抢庄选三张', '8200', 25, NULL, 'admins', 1, 0, 0, 1, 8, NULL, NULL, 0);
INSERT INTO `platform_game_list` VALUES ('8_8_27', 8, '', '', '/icon/LY_QP/抢红包.png', '抢红包', '8220', 26, NULL, 'admins', 1, 0, 0, 1, 8, NULL, NULL, 0);
INSERT INTO `platform_game_list` VALUES ('8_8_28', 8, '', '', '/icon/LY_QP/金鲨银鲨256X256.png', '金鲨银鲨', '940', 27, NULL, 'admins', 1, 0, 0, 1, 8, NULL, NULL, 0);
INSERT INTO `platform_game_list` VALUES ('8_8_29', 8, '', '', '/icon/LY_QP/头号玩家-256.png', '头号玩家', '8260', 28, NULL, 'admins', 1, 0, 0, 1, 8, NULL, NULL, 0);
INSERT INTO `platform_game_list` VALUES ('8_8_3', 8, '', '', '/icon/LY_QP/二八杠.png', '二八杠', '720', 2, NULL, 'admins', 1, 0, 0, 1, 8, NULL, NULL, 0);
INSERT INTO `platform_game_list` VALUES ('8_8_30', 8, '', '', '/icon/LY_QP/欢乐炸金花-256.png', '欢乐炸金花', '8270', 29, NULL, 'admins', 1, 0, 0, 1, 8, NULL, NULL, 0);
INSERT INTO `platform_game_list` VALUES ('8_8_31', 8, '', '', '/icon/LY_QP/好友包房256X256.png', '好友包房', '8280', 30, NULL, 'admins', 1, 0, 0, 1, 8, NULL, NULL, 0);
INSERT INTO `platform_game_list` VALUES ('8_8_4', 8, '', '', '/icon/LY_QP/抢庄牛牛.png', '抢庄牛牛', '830', 3, NULL, 'admins', 1, 0, 0, 1, 8, NULL, NULL, 0);
INSERT INTO `platform_game_list` VALUES ('8_8_5', 8, '', '', '/icon/LY_QP/炸金花.png', '炸金花', '220', 4, NULL, 'admins', 1, 0, 0, 1, 8, NULL, NULL, 0);
INSERT INTO `platform_game_list` VALUES ('8_8_6', 8, '', '', '/icon/LY_QP/三公.png', '三公', '860', 5, NULL, 'admins', 1, 0, 0, 1, 8, NULL, NULL, 0);
INSERT INTO `platform_game_list` VALUES ('8_8_7', 8, '', '', '/icon/LY_QP/龙虎斗.png', '龙虎斗', '900', 6, NULL, 'admins', 1, 0, 0, 1, 8, NULL, NULL, 0);
INSERT INTO `platform_game_list` VALUES ('8_8_8', 8, '', '', '/icon/LY_QP/21点.png', '21点', '600', 7, NULL, 'admins', 1, 0, 0, 1, 8, NULL, NULL, 0);
INSERT INTO `platform_game_list` VALUES ('8_8_9', 8, '', '', '/icon/LY_QP/通比牛牛.png', '通比牛牛', '870', 8, NULL, 'admins', 1, 0, 0, 1, 8, NULL, NULL, 0);

-- ----------------------------
-- Table structure for platform_list
-- ----------------------------
DROP TABLE IF EXISTS `platform_list`;
CREATE TABLE `platform_list`  (
  `id` int(0) NOT NULL AUTO_INCREMENT COMMENT '编号',
  `type` int(0) NULL DEFAULT NULL COMMENT '平台类型',
  `name` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '平台名称',
  `icon` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '平台图标',
  `sort` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '排序',
  `edit_time` datetime(0) NULL DEFAULT NULL COMMENT '修改时间',
  `edit_user` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '修改人',
  `is_enable` tinyint(1) NULL DEFAULT NULL COMMENT '是否启用',
  `is_maintain` tinyint(1) NULL DEFAULT NULL COMMENT '是否维护',
  `is_recommend` tinyint(1) NULL DEFAULT NULL COMMENT '是否推荐',
  `is_vertical` tinyint(1) NULL DEFAULT NULL COMMENT '是否竖屏',
  `identify_str` varchar(256) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '第三方游戏自定义的标识-组合字符',
  `uuid` varchar(256) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '唯一标识符',
  `dir_name` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '文件夹名称',
  `icon_name` varchar(256) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '图片原本名称',
  `mini_icon` varchar(256) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '左侧小图标',
  `miniIcon_name` varchar(256) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '左侧小图标原本名称',
  `top_score` int(0) NULL DEFAULT NULL COMMENT '平台可携带分数上限',
  `is_del` tinyint(1) NULL DEFAULT 1 COMMENT '是否删除 0 是 1 否',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 8 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci COMMENT = '第三方游戏平台表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of platform_list
-- ----------------------------
INSERT INTO `platform_list` VALUES (1, 1, '开元棋牌', '/photo_2020-04-23_15-28-39.jpg', '1', '2020-05-20 15:29:03', 'meixi', 1, 0, 1, 0, NULL, '1', '', 'photo_2020-04-23_15-28-39.jpg', '/JG棋牌.png', 'JG棋牌.png', 300, 0);
INSERT INTO `platform_list` VALUES (6, 1, 'JDB棋牌', '/JDBqipai.png', '3', '2020-05-20 15:33:37', 'meixi', 1, 0, 0, 0, NULL, '611', NULL, NULL, '/JDB棋牌.png', NULL, 50, 0);
INSERT INTO `platform_list` VALUES (7, 1, 'FG棋牌', '/FGqipai.png', '4', '2020-05-20 15:44:49', 'meixi', 1, 0, 0, 0, NULL, '711', NULL, NULL, '/FG棋牌.png', NULL, 100, 0);
INSERT INTO `platform_list` VALUES (8, 1, '乐游棋牌', '/LEGqipai.png', '5', '2020-05-20 15:39:58', 'meixi', 1, 0, 0, 0, NULL, '8', NULL, NULL, '/LEG棋牌.png', NULL, 50, 0);

-- ----------------------------
-- Table structure for platform_type
-- ----------------------------
DROP TABLE IF EXISTS `platform_type`;
CREATE TABLE `platform_type`  (
  `id` int(0) NOT NULL AUTO_INCREMENT,
  `name` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '分类名称',
  `sort` int(0) NULL DEFAULT NULL COMMENT '分类排序',
  `is_enable` tinyint(1) NULL DEFAULT NULL COMMENT '是否启用',
  `is_del` tinyint(1) NULL DEFAULT 1 COMMENT '是否删除 0是1否',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 6 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci COMMENT = '平台分类' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of platform_type
-- ----------------------------
INSERT INTO `platform_type` VALUES (1, '棋牌游戏', 1, 1, 0);
INSERT INTO `platform_type` VALUES (2, '捕鱼游戏', 2, 1, 0);
INSERT INTO `platform_type` VALUES (3, '电子游艺', 3, 1, 0);
INSERT INTO `platform_type` VALUES (4, '真人视讯', 4, 1, 0);
INSERT INTO `platform_type` VALUES (5, '彩票游戏', 5, 1, 0);
INSERT INTO `platform_type` VALUES (6, '体育游戏', 6, 1, 0);

-- ----------------------------
-- Table structure for site_db
-- ----------------------------
DROP TABLE IF EXISTS `site_db`;
CREATE TABLE `site_db`  (
  `id` int(0) NOT NULL AUTO_INCREMENT COMMENT '数据源',
  `url` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '数据源连接',
  `username` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '数据源账号',
  `password` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '数据源密码',
  `driverClassName` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '数据源驱动',
  `site_id` int(0) NULL DEFAULT NULL COMMENT '所属站点',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 3 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci COMMENT = '多数据源' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of site_db
-- ----------------------------
INSERT INTO `site_db` VALUES (1, 'jdbc:mysql://192.168.2.191:3306/qp_cloud?useUnicode=true&characterEncoding=utf8&zeroDateTimeBehavior=CONVERT_TO_NULL&useSSL=false&autoReconnect=true&serverTimezone=GMT%2B8&allowMultiQueries=true', 'root', '123456', 'com.mysql.cj.jdbc.Driver', 1);
INSERT INTO `site_db` VALUES (2, 'jdbc:mysql://192.168.2.191:3306/qp_cloud_a?useUnicode=true&characterEncoding=utf8&zeroDateTimeBehavior=CONVERT_TO_NULL&useSSL=false&autoReconnect=true&serverTimezone=GMT%2B8&allowMultiQueries=true', 'root', '123456', 'com.mysql.cj.jdbc.Driver', 3);
INSERT INTO `site_db` VALUES (3, 'jdbc:mysql://192.168.2.191:3306/qp_cloud_b?useUnicode=true&characterEncoding=utf8&zeroDateTimeBehavior=CONVERT_TO_NULL&useSSL=false&autoReconnect=true&serverTimezone=GMT%2B8&allowMultiQueries=true', 'root', '123456', 'com.mysql.cj.jdbc.Driver', 4);

-- ----------------------------
-- Table structure for site_list
-- ----------------------------
DROP TABLE IF EXISTS `site_list`;
CREATE TABLE `site_list`  (
  `id` int(0) NOT NULL AUTO_INCREMENT COMMENT 'id',
  `site_no` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '站点编号 lg：\"site_internal\"',
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '站点名称',
  `type` int(0) NULL DEFAULT NULL COMMENT '站点类型 lg：1全民代理，2无线代理，3双向税收，4共同盈亏',
  `host_url` varchar(256) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '后台域名',
  `h5_url` varchar(256) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT 'H5域名',
  `web_url` varchar(256) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '网站域名',
  `link_man` varchar(256) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '站点联系人',
  `link_phone` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '站点联系电话',
  `proportion` double NULL DEFAULT NULL COMMENT '站点分成比例',
  `create_time` datetime(0) NULL DEFAULT NULL COMMENT '开站时间',
  `operator` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '操作人',
  `is_mix_site` int(0) NULL DEFAULT NULL COMMENT '混合站点运营',
  `maintain_status` int(0) NULL DEFAULT NULL COMMENT '维护状态',
  `is_google_ver` int(0) NULL DEFAULT NULL COMMENT '是否开启谷歌验证器',
  `site_styles_id` int(0) NULL DEFAULT NULL COMMENT '风格',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 5 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci COMMENT = '站点名称' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of site_list
-- ----------------------------
INSERT INTO `site_list` VALUES (1, 'site_kaiyuan', '开元站点', 1, 'test01.server.com', NULL, NULL, NULL, NULL, 0, '2020-05-20 15:47:57', 'admin', 1, 1, 1, 0);
INSERT INTO `site_list` VALUES (3, 'site_a', '测试站点A', 2, 'test02.server.com', NULL, NULL, NULL, NULL, 0, '2020-05-27 14:13:44', 'admin', 1, 1, 1, 0);
INSERT INTO `site_list` VALUES (4, 'site_b', '测试站点B', 2, 'test03.server.com', NULL, NULL, NULL, NULL, 0, '2020-05-27 14:13:44', 'admin', 1, 1, 1, 0);
INSERT INTO `site_list` VALUES (5, 'site_share', '总站', 0, NULL, NULL, NULL, NULL, NULL, NULL, '2020-06-02 13:35:15', 'admin', 1, 1, 1, 0);

-- ----------------------------
-- Table structure for sys_dept
-- ----------------------------
DROP TABLE IF EXISTS `sys_dept`;
CREATE TABLE `sys_dept`  (
  `dept_id` int(0) NOT NULL AUTO_INCREMENT COMMENT '部门id',
  `parent_id` int(0) NULL DEFAULT 0 COMMENT '父部门id',
  `ancestors` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT '' COMMENT '祖级列表',
  `dept_name` varchar(30) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT '' COMMENT '部门名称',
  `order_num` int(0) NULL DEFAULT 0 COMMENT '显示顺序',
  `leader` varchar(20) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '负责人',
  `leader_id` int(0) NULL DEFAULT NULL COMMENT '负责人编号',
  `phone` varchar(11) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '联系电话',
  `email` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '邮箱',
  `status` char(1) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT '0' COMMENT '部门状态（0正常 1停用）',
  `del_flag` char(1) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT '0' COMMENT '删除标志（0代表存在 2代表删除）',
  `create_by` varchar(64) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT '' COMMENT '创建者',
  `create_time` datetime(0) NULL DEFAULT NULL COMMENT '创建时间',
  `update_by` varchar(64) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT '' COMMENT '更新者',
  `update_time` datetime(0) NULL DEFAULT NULL COMMENT '更新时间',
  PRIMARY KEY (`dept_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 112 CHARACTER SET = utf8 COLLATE = utf8_general_ci COMMENT = '部门表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of sys_dept
-- ----------------------------
INSERT INTO `sys_dept` VALUES (100, 0, '0', '若依科技', 0, '若依', 1, '15888888888', 'ry@qq.com', '0', '0', 'admin', '2018-03-16 11:33:00', 'ry', '2019-09-10 21:48:36');
INSERT INTO `sys_dept` VALUES (101, 100, '0,100', '深圳总公司', 1, '若依', 1, '15888888888', 'ry@qq.com', '0', '0', 'admin', '2018-03-16 11:33:00', 'ry', '2019-09-10 21:48:36');
INSERT INTO `sys_dept` VALUES (102, 100, '0,100', '长沙分公司', 2, '若依', 1, '15888888888', 'ry@qq.com', '0', '0', 'admin', '2018-03-16 11:33:00', 'ry', '2019-05-30 17:45:19');
INSERT INTO `sys_dept` VALUES (103, 101, '0,100,101', '研发部门', 1, '若依', 1, '15888888888', 'ry@qq.com', '0', '0', 'admin', '2018-03-16 11:33:00', 'ry', '2018-03-16 11:33:00');
INSERT INTO `sys_dept` VALUES (104, 101, '0,100,101', '市场部门', 2, '若依', 1, '15888888888', 'ry@qq.com', '0', '0', 'admin', '2018-03-16 11:33:00', 'ry', '2018-03-16 11:33:00');
INSERT INTO `sys_dept` VALUES (105, 101, '0,100,101', '测试部门', 3, '若依', 1, '15888888888', 'ry@qq.com', '0', '0', 'admin', '2018-03-16 11:33:00', 'ry', '2018-03-16 11:33:00');
INSERT INTO `sys_dept` VALUES (106, 101, '0,100,101', '财务部门', 4, '若依', 1, '15888888888', 'ry@qq.com', '0', '0', 'admin', '2018-03-16 11:33:00', 'ry', '2018-03-16 11:33:00');
INSERT INTO `sys_dept` VALUES (107, 101, '0,100,101', '运维部门', 5, '若依', 1, '15888888888', 'ry@qq.com', '0', '0', 'admin', '2018-03-16 11:33:00', 'ry', '2018-03-16 11:33:00');
INSERT INTO `sys_dept` VALUES (108, 102, '0,100,102', '市场部门', 1, '若依', 1, '15888888888', 'ry@qq.com', '0', '0', 'admin', '2018-03-16 11:33:00', 'ry', '2018-03-16 11:33:00');
INSERT INTO `sys_dept` VALUES (109, 102, '0,100,102', '财务部门', 2, '若依', 1, '15888888888', 'ry@qq.com', '0', '0', 'admin', '2018-03-16 11:33:00', 'ry', '2019-05-30 17:45:19');
INSERT INTO `sys_dept` VALUES (112, 108, '0,100,102,108', '1241', 124, '1124', 1, '1241', '142', '0', '2', '', '2019-05-30 17:14:39', '', NULL);

-- ----------------------------
-- Table structure for sys_logininfor
-- ----------------------------
DROP TABLE IF EXISTS `sys_logininfor`;
CREATE TABLE `sys_logininfor`  (
  `info_id` int(0) NOT NULL AUTO_INCREMENT COMMENT '访问ID',
  `login_name` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT '' COMMENT '登录账号',
  `ipaddr` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT '' COMMENT '登录IP地址',
  `login_location` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT '' COMMENT '登录地点',
  `browser` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT '' COMMENT '浏览器类型',
  `os` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT '' COMMENT '操作系统',
  `status` char(1) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT '0' COMMENT '登录状态（0成功 1失败）',
  `msg` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT '' COMMENT '提示消息',
  `login_time` datetime(0) NULL DEFAULT NULL COMMENT '访问时间',
  PRIMARY KEY (`info_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 11586 CHARACTER SET = utf8 COLLATE = utf8_general_ci COMMENT = '系统访问记录' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of sys_logininfor
-- ----------------------------
INSERT INTO `sys_logininfor` VALUES (10817, 'admin', '127.0.0.1', '内网IP', 'Unknown', 'Unknown', '0', '登录成功', '2020-05-18 11:50:33');
INSERT INTO `sys_logininfor` VALUES (10818, 'admin', '127.0.0.1', '内网IP', 'Unknown', 'Unknown', '0', '登录成功', '2020-05-18 14:45:08');
INSERT INTO `sys_logininfor` VALUES (10819, 'admin', '127.0.0.1', '内网IP', 'Unknown', 'Unknown', '0', '登录成功', '2020-05-18 14:53:24');
INSERT INTO `sys_logininfor` VALUES (10820, 'admin', '127.0.0.1', '内网IP', 'Unknown', 'Unknown', '0', '登录成功', '2020-05-18 14:53:43');
INSERT INTO `sys_logininfor` VALUES (10821, 'admin', '127.0.0.1', '内网IP', 'Unknown', 'Unknown', '0', '登录成功', '2020-05-18 15:28:31');
INSERT INTO `sys_logininfor` VALUES (10822, 'admin', '127.0.0.1', '内网IP', 'Unknown', 'Unknown', '0', '登录成功', '2020-05-18 15:28:37');
INSERT INTO `sys_logininfor` VALUES (10823, '', '192.168.2.156', '内网IP', 'Chrome', 'Windows 10', '1', '* 必须填写', '2020-05-18 18:29:10');
INSERT INTO `sys_logininfor` VALUES (10824, '123456', '192.168.2.156', '内网IP', 'Chrome', 'Windows 10', '1', '用户不存在/密码错误', '2020-05-18 18:29:23');
INSERT INTO `sys_logininfor` VALUES (10825, '123456', '192.168.2.156', '内网IP', 'Chrome', 'Windows 10', '1', '用户不存在/密码错误', '2020-05-18 18:29:25');
INSERT INTO `sys_logininfor` VALUES (10826, '123456', '192.168.2.156', '内网IP', 'Chrome', 'Windows 10', '1', '用户不存在/密码错误', '2020-05-18 18:30:30');
INSERT INTO `sys_logininfor` VALUES (10827, 'admin', '127.0.0.1', '内网IP', 'Unknown', 'Unknown', '0', '登录成功', '2020-05-18 18:33:18');
INSERT INTO `sys_logininfor` VALUES (10828, 'admin', '192.168.2.156', '内网IP', 'Chrome', 'Windows 10', '0', '登录成功', '2020-05-18 18:33:41');
INSERT INTO `sys_logininfor` VALUES (10829, 'admin', '192.168.2.156', '内网IP', 'Chrome', 'Windows 10', '0', '登录成功', '2020-05-18 18:33:45');
INSERT INTO `sys_logininfor` VALUES (10830, 'admin', '192.168.2.156', '内网IP', 'Chrome', 'Windows 10', '0', '登录成功', '2020-05-18 18:33:46');
INSERT INTO `sys_logininfor` VALUES (10831, 'admin', '192.168.2.156', '内网IP', 'Chrome', 'Windows 10', '0', '登录成功', '2020-05-18 18:33:46');
INSERT INTO `sys_logininfor` VALUES (10832, 'admin', '192.168.2.156', '内网IP', 'Chrome', 'Windows 10', '0', '登录成功', '2020-05-18 18:33:47');
INSERT INTO `sys_logininfor` VALUES (10833, 'admin', '192.168.2.156', '内网IP', 'Chrome', 'Windows 10', '0', '登录成功', '2020-05-18 18:33:47');
INSERT INTO `sys_logininfor` VALUES (10834, 'admin', '192.168.2.156', '内网IP', 'Chrome', 'Windows 10', '0', '登录成功', '2020-05-18 18:33:47');
INSERT INTO `sys_logininfor` VALUES (10835, 'admin', '192.168.2.156', '内网IP', 'Chrome', 'Windows 10', '0', '登录成功', '2020-05-18 18:33:47');
INSERT INTO `sys_logininfor` VALUES (10836, 'admin', '127.0.0.1', '内网IP', 'Unknown', 'Unknown', '0', '登录成功', '2020-05-19 01:23:07');
INSERT INTO `sys_logininfor` VALUES (10837, '', '0:0:0:0:0:0:0:1', 'XX XX', 'Chrome', 'Windows 10', '1', '* 必须填写', '2020-05-19 09:56:51');
INSERT INTO `sys_logininfor` VALUES (10838, '123456', '0:0:0:0:0:0:0:1', 'XX XX', 'Chrome', 'Windows 10', '1', '用户不存在/密码错误', '2020-05-19 09:57:00');
INSERT INTO `sys_logininfor` VALUES (10839, '123456', '0:0:0:0:0:0:0:1', 'XX XX', 'Chrome', 'Windows 10', '1', '用户不存在/密码错误', '2020-05-19 09:57:05');
INSERT INTO `sys_logininfor` VALUES (10840, '123456', '0:0:0:0:0:0:0:1', 'XX XX', 'Chrome', 'Windows 10', '1', '用户不存在/密码错误', '2020-05-19 09:57:15');
INSERT INTO `sys_logininfor` VALUES (10841, 'admin', '127.0.0.1', '内网IP', 'Unknown', 'Unknown', '0', '登录成功', '2020-05-19 09:57:50');
INSERT INTO `sys_logininfor` VALUES (10842, '123456', '0:0:0:0:0:0:0:1', 'XX XX', 'Chrome', 'Windows 10', '1', '用户不存在/密码错误', '2020-05-19 09:57:57');
INSERT INTO `sys_logininfor` VALUES (10843, '123456', '0:0:0:0:0:0:0:1', 'XX XX', 'Chrome', 'Windows 10', '1', '用户不存在/密码错误', '2020-05-19 09:58:00');
INSERT INTO `sys_logininfor` VALUES (10844, '123456', '0:0:0:0:0:0:0:1', 'XX XX', 'Chrome', 'Windows 10', '1', '用户不存在/密码错误', '2020-05-19 09:58:01');
INSERT INTO `sys_logininfor` VALUES (10845, '123456', '0:0:0:0:0:0:0:1', 'XX XX', 'Chrome', 'Windows 10', '1', '用户不存在/密码错误', '2020-05-19 09:58:01');
INSERT INTO `sys_logininfor` VALUES (10846, '123456', '0:0:0:0:0:0:0:1', 'XX XX', 'Chrome', 'Windows 10', '1', '用户不存在/密码错误', '2020-05-19 09:58:01');
INSERT INTO `sys_logininfor` VALUES (10847, '123456', '0:0:0:0:0:0:0:1', 'XX XX', 'Chrome', 'Windows 10', '1', '用户不存在/密码错误', '2020-05-19 09:58:02');
INSERT INTO `sys_logininfor` VALUES (10848, '123456', '0:0:0:0:0:0:0:1', 'XX XX', 'Chrome', 'Windows 10', '1', '用户不存在/密码错误', '2020-05-19 09:58:15');
INSERT INTO `sys_logininfor` VALUES (10849, 'admin', '0:0:0:0:0:0:0:1', 'XX XX', 'Chrome', 'Windows 10', '0', '登录成功', '2020-05-19 09:58:31');
INSERT INTO `sys_logininfor` VALUES (10850, 'admin', '127.0.0.1', '内网IP', 'Unknown', 'Unknown', '0', '登录成功', '2020-05-19 10:13:00');
INSERT INTO `sys_logininfor` VALUES (10851, 'admin', '127.0.0.1', '内网IP', 'Unknown', 'Unknown', '0', '登录成功', '2020-05-19 10:36:25');
INSERT INTO `sys_logininfor` VALUES (10852, 'admin', '127.0.0.1', '内网IP', 'Unknown', 'Unknown', '0', '登录成功', '2020-05-19 10:36:55');
INSERT INTO `sys_logininfor` VALUES (10853, 'admin', '127.0.0.1', '内网IP', 'Unknown', 'Unknown', '0', '登录成功', '2020-05-19 10:55:35');
INSERT INTO `sys_logininfor` VALUES (10854, 'admin', '127.0.0.1', '内网IP', 'Unknown', 'Unknown', '0', '登录成功', '2020-05-19 11:03:12');
INSERT INTO `sys_logininfor` VALUES (10855, 'admin', '127.0.0.1', '内网IP', 'Unknown', 'Unknown', '0', '登录成功', '2020-05-19 11:04:06');
INSERT INTO `sys_logininfor` VALUES (10856, 'admin', '127.0.0.1', '内网IP', 'Unknown', 'Unknown', '0', '登录成功', '2020-05-19 11:05:09');
INSERT INTO `sys_logininfor` VALUES (10857, 'admin', '127.0.0.1', '内网IP', 'Unknown', 'Unknown', '0', '登录成功', '2020-05-19 11:06:36');
INSERT INTO `sys_logininfor` VALUES (10858, 'admin', '127.0.0.1', '内网IP', 'Unknown', 'Unknown', '0', '登录成功', '2020-05-19 11:07:39');
INSERT INTO `sys_logininfor` VALUES (10859, 'admin', '127.0.0.1', '内网IP', 'Unknown', 'Unknown', '0', '登录成功', '2020-05-19 11:09:58');
INSERT INTO `sys_logininfor` VALUES (10860, 'admin', '127.0.0.1', '内网IP', 'Unknown', 'Unknown', '0', '登录成功', '2020-05-19 11:13:01');
INSERT INTO `sys_logininfor` VALUES (10861, 'admin', '127.0.0.1', '内网IP', 'Unknown', 'Unknown', '0', '登录成功', '2020-05-19 11:25:37');
INSERT INTO `sys_logininfor` VALUES (10862, 'admin', '127.0.0.1', '内网IP', 'Unknown', 'Unknown', '0', '登录成功', '2020-05-19 11:30:47');
INSERT INTO `sys_logininfor` VALUES (10863, 'admin', '127.0.0.1', '内网IP', 'Unknown', 'Unknown', '0', '登录成功', '2020-05-19 11:31:14');
INSERT INTO `sys_logininfor` VALUES (10864, 'admin', '127.0.0.1', '内网IP', 'Unknown', 'Unknown', '0', '登录成功', '2020-05-19 11:39:17');
INSERT INTO `sys_logininfor` VALUES (10865, 'admin', '127.0.0.1', '内网IP', 'Unknown', 'Unknown', '0', '登录成功', '2020-05-19 11:47:08');
INSERT INTO `sys_logininfor` VALUES (10866, 'admin', '0:0:0:0:0:0:0:1', 'XX XX', 'Chrome', 'Windows 10', '0', '登录成功', '2020-05-19 12:30:31');
INSERT INTO `sys_logininfor` VALUES (10867, 'admin', '127.0.0.1', '内网IP', 'Chrome', 'Windows 10', '0', '登录成功', '2020-05-19 22:07:15');
INSERT INTO `sys_logininfor` VALUES (10868, 'admin', '127.0.0.1', '内网IP', 'Unknown', 'Unknown', '0', '登录成功', '2020-05-19 22:08:36');
INSERT INTO `sys_logininfor` VALUES (10869, 'admin', '0:0:0:0:0:0:0:1', 'XX XX', 'Chrome', 'Windows 10', '1', '* 必须填写', '2020-05-20 10:14:03');
INSERT INTO `sys_logininfor` VALUES (10870, 'admin', '0:0:0:0:0:0:0:1', 'XX XX', 'Chrome', 'Windows 10', '0', '登录成功', '2020-05-20 10:24:44');
INSERT INTO `sys_logininfor` VALUES (10871, 'admin', '0:0:0:0:0:0:0:1', 'XX XX', 'Chrome', 'Windows 10', '0', '登录成功', '2020-05-20 10:33:37');
INSERT INTO `sys_logininfor` VALUES (10872, '梅西大爷', '0:0:0:0:0:0:0:1', 'XX XX', 'Chrome', 'Windows 10', '1', '用户不存在/密码错误', '2020-05-20 10:49:01');
INSERT INTO `sys_logininfor` VALUES (10873, 'admin', '0:0:0:0:0:0:0:1', 'XX XX', 'Chrome', 'Windows 10', '1', '用户不存在/密码错误', '2020-05-21 02:02:22');
INSERT INTO `sys_logininfor` VALUES (10874, 'test123', '0:0:0:0:0:0:0:1', 'XX XX', 'Chrome', 'Windows 10', '1', '用户不存在/密码错误', '2020-05-21 03:51:01');
INSERT INTO `sys_logininfor` VALUES (10875, 'test123', '0:0:0:0:0:0:0:1', 'XX XX', 'Chrome', 'Windows 10', '1', '用户不存在/密码错误', '2020-05-21 05:53:00');
INSERT INTO `sys_logininfor` VALUES (10876, 'test123', '0:0:0:0:0:0:0:1', 'XX XX', 'Chrome', 'Windows 10', '1', '* 必须填写', '2020-05-21 05:53:10');
INSERT INTO `sys_logininfor` VALUES (10877, 'admin', '0:0:0:0:0:0:0:1', 'XX XX', 'Chrome', 'Windows 10', '0', '登录成功', '2020-05-21 05:59:28');
INSERT INTO `sys_logininfor` VALUES (10878, 'test123', '0:0:0:0:0:0:0:1', 'XX XX', 'Chrome', 'Windows 10', '1', '* 必须填写', '2020-05-21 06:12:41');
INSERT INTO `sys_logininfor` VALUES (10879, 'test123', '0:0:0:0:0:0:0:1', 'XX XX', 'Chrome', 'Windows 10', '1', '* 必须填写', '2020-05-21 06:28:26');
INSERT INTO `sys_logininfor` VALUES (10880, 'test123', '0:0:0:0:0:0:0:1', 'XX XX', 'Chrome', 'Windows 10', '0', '退出成功', '2020-05-21 06:30:13');
INSERT INTO `sys_logininfor` VALUES (10881, 'test123', '0:0:0:0:0:0:0:1', 'XX XX', 'Chrome', 'Windows 10', '1', '用户不存在/密码错误', '2020-05-21 06:43:32');
INSERT INTO `sys_logininfor` VALUES (10882, 'test123', '0:0:0:0:0:0:0:1', 'XX XX', 'Chrome', 'Windows 10', '0', '退出成功', '2020-05-21 06:47:02');
INSERT INTO `sys_logininfor` VALUES (10883, 'test123', '0:0:0:0:0:0:0:1', 'XX XX', 'Chrome', 'Windows 10', '1', '用户不存在/密码错误', '2020-05-22 02:20:27');
INSERT INTO `sys_logininfor` VALUES (10884, 'test3333', '0:0:0:0:0:0:0:1', 'XX XX', 'Chrome', 'Windows 10', '1', '用户不存在/密码错误', '2020-05-22 02:21:32');
INSERT INTO `sys_logininfor` VALUES (10885, 'test123', '0:0:0:0:0:0:0:1', 'XX XX', 'Chrome', 'Windows 10', '1', '用户不存在/密码错误', '2020-05-22 02:22:21');
INSERT INTO `sys_logininfor` VALUES (10886, 'test123', '0:0:0:0:0:0:0:1', 'XX XX', 'Chrome', 'Windows 10', '1', '用户不存在/密码错误', '2020-05-22 02:23:20');
INSERT INTO `sys_logininfor` VALUES (10887, 'test123', '0:0:0:0:0:0:0:1', 'XX XX', 'Chrome', 'Windows 10', '0', '退出成功', '2020-05-22 02:26:00');
INSERT INTO `sys_logininfor` VALUES (10888, 'test123', '192.168.2.118', '内网IP', 'Chrome 8', 'Windows 10', '1', '用户不存在/密码错误', '2020-05-22 06:32:34');
INSERT INTO `sys_logininfor` VALUES (10889, 'test123', '192.168.2.118', '内网IP', 'Chrome 8', 'Windows 10', '0', '退出成功', '2020-05-22 06:32:50');
INSERT INTO `sys_logininfor` VALUES (10890, 'testpeng', '0:0:0:0:0:0:0:1', 'XX XX', 'Chrome 8', 'Windows 10', '1', '用户不存在/密码错误', '2020-05-22 06:37:35');
INSERT INTO `sys_logininfor` VALUES (10891, 'testpeng', '0:0:0:0:0:0:0:1', 'XX XX', 'Chrome 8', 'Windows 10', '0', '退出成功', '2020-05-22 06:38:58');
INSERT INTO `sys_logininfor` VALUES (10892, 'test123', '0:0:0:0:0:0:0:1', 'XX XX', 'Chrome', 'Windows 10', '0', '退出成功', '2020-05-22 07:03:09');
INSERT INTO `sys_logininfor` VALUES (10893, 'zjs123', '192.168.2.118', '内网IP', 'Chrome 8', 'Windows 10', '1', '用户不存在/密码错误', '2020-05-22 07:12:42');
INSERT INTO `sys_logininfor` VALUES (10894, 'test123', '192.168.2.118', '内网IP', 'Chrome 8', 'Windows 10', '0', '退出成功', '2020-05-22 07:14:40');
INSERT INTO `sys_logininfor` VALUES (10895, 'test123', '192.168.2.118', '内网IP', 'Chrome 8', 'Windows 10', '1', '用户不存在/密码错误', '2020-05-22 08:04:13');
INSERT INTO `sys_logininfor` VALUES (10896, 'test123', '192.168.2.118', '内网IP', 'Chrome 8', 'Windows 10', '1', '用户不存在/密码错误', '2020-05-22 08:24:28');
INSERT INTO `sys_logininfor` VALUES (10897, 'test123', '192.168.2.118', '内网IP', 'Chrome 8', 'Windows 10', '0', '退出成功', '2020-05-22 08:25:15');
INSERT INTO `sys_logininfor` VALUES (10898, 'test123', '192.168.2.118', '内网IP', 'Chrome 8', 'Windows 10', '0', '退出成功', '2020-05-22 08:30:48');
INSERT INTO `sys_logininfor` VALUES (10899, 'test123', '192.168.2.118', '内网IP', 'Chrome 8', 'Windows 10', '0', '退出成功', '2020-05-22 08:32:37');
INSERT INTO `sys_logininfor` VALUES (10900, 'test123', '192.168.2.118', '内网IP', 'Chrome 8', 'Windows 10', '0', '退出成功', '2020-05-22 08:42:44');
INSERT INTO `sys_logininfor` VALUES (10901, 'test123', '192.168.2.118', '内网IP', 'Chrome 8', 'Windows 10', '0', '退出成功', '2020-05-22 10:18:39');
INSERT INTO `sys_logininfor` VALUES (10902, 'test123', '192.168.2.118', '内网IP', 'Chrome 8', 'Windows 10', '1', '用户不存在/密码错误', '2020-05-22 10:26:07');
INSERT INTO `sys_logininfor` VALUES (10903, 'test123', '192.168.2.118', '内网IP', 'Chrome 8', 'Windows 10', '0', '退出成功', '2020-05-22 10:26:07');
INSERT INTO `sys_logininfor` VALUES (10904, 'test123', '192.168.2.118', '内网IP', 'Chrome 8', 'Windows 10', '0', '退出成功', '2020-05-22 10:27:38');
INSERT INTO `sys_logininfor` VALUES (10905, 'test123', '192.168.2.118', '内网IP', 'Chrome 8', 'Windows 10', '0', '退出成功', '2020-05-22 10:30:08');
INSERT INTO `sys_logininfor` VALUES (10906, 'test123', '192.168.2.118', '内网IP', 'Chrome 8', 'Windows 10', '0', '退出成功', '2020-05-22 10:32:57');
INSERT INTO `sys_logininfor` VALUES (10907, 'test123', '0:0:0:0:0:0:0:1', 'XX XX', 'Chrome', 'Windows 10', '0', '退出成功', '2020-05-25 01:57:48');
INSERT INTO `sys_logininfor` VALUES (10908, 'test123', '0:0:0:0:0:0:0:1', 'XX XX', 'Chrome', 'Windows 10', '1', '用户不存在/密码错误', '2020-05-25 01:57:48');
INSERT INTO `sys_logininfor` VALUES (10909, 'peng123', '0:0:0:0:0:0:0:1', 'XX XX', 'Chrome 8', 'Windows 10', '1', '用户不存在/密码错误', '2020-05-25 02:20:20');
INSERT INTO `sys_logininfor` VALUES (10910, 'peng123', '0:0:0:0:0:0:0:1', 'XX XX', 'Chrome 8', 'Windows 10', '1', '用户不存在/密码错误', '2020-05-25 02:20:20');
INSERT INTO `sys_logininfor` VALUES (10911, 'peng123', '0:0:0:0:0:0:0:1', 'XX XX', 'Chrome 8', 'Windows 10', '1', '用户不存在/密码错误', '2020-05-25 02:20:20');
INSERT INTO `sys_logininfor` VALUES (10912, 'testpeng', '0:0:0:0:0:0:0:1', 'XX XX', 'Chrome 8', 'Windows 10', '1', '用户不存在/密码错误', '2020-05-25 02:20:20');
INSERT INTO `sys_logininfor` VALUES (10913, 'testpeng', '0:0:0:0:0:0:0:1', 'XX XX', 'Chrome 8', 'Windows 10', '1', '用户不存在/密码错误', '2020-05-25 02:20:20');
INSERT INTO `sys_logininfor` VALUES (10914, 'testpeng', '0:0:0:0:0:0:0:1', 'XX XX', 'Chrome 8', 'Windows 10', '1', '用户不存在/密码错误', '2020-05-25 02:20:20');
INSERT INTO `sys_logininfor` VALUES (10915, 'testpeng', '0:0:0:0:0:0:0:1', 'XX XX', 'Chrome 8', 'Windows 10', '1', '用户不存在/密码错误', '2020-05-25 02:20:20');
INSERT INTO `sys_logininfor` VALUES (10916, 'testpeng', '0:0:0:0:0:0:0:1', 'XX XX', 'Chrome 8', 'Windows 10', '1', '用户不存在/密码错误', '2020-05-25 02:20:21');
INSERT INTO `sys_logininfor` VALUES (10917, 'testpan', '0:0:0:0:0:0:0:1', 'XX XX', 'Chrome 8', 'Windows 10', '1', '用户不存在/密码错误', '2020-05-25 02:20:55');
INSERT INTO `sys_logininfor` VALUES (10918, 'testpan', '0:0:0:0:0:0:0:1', 'XX XX', 'Chrome 8', 'Windows 10', '1', '用户不存在/密码错误', '2020-05-25 02:20:56');
INSERT INTO `sys_logininfor` VALUES (10919, 'testpan', '0:0:0:0:0:0:0:1', 'XX XX', 'Chrome 8', 'Windows 10', '1', '用户不存在/密码错误', '2020-05-25 02:21:02');
INSERT INTO `sys_logininfor` VALUES (10920, 'testpan', '0:0:0:0:0:0:0:1', 'XX XX', 'Chrome 8', 'Windows 10', '1', '用户不存在/密码错误', '2020-05-25 02:21:16');
INSERT INTO `sys_logininfor` VALUES (10921, 'testpeng', '0:0:0:0:0:0:0:1', 'XX XX', 'Chrome 8', 'Windows 10', '1', '用户不存在/密码错误', '2020-05-25 02:21:43');
INSERT INTO `sys_logininfor` VALUES (10922, 'testpeng', '0:0:0:0:0:0:0:1', 'XX XX', 'Chrome 8', 'Windows 10', '1', '用户不存在/密码错误', '2020-05-25 02:21:53');
INSERT INTO `sys_logininfor` VALUES (10923, 'testpeng', '0:0:0:0:0:0:0:1', 'XX XX', 'Chrome 8', 'Windows 10', '1', '用户不存在/密码错误', '2020-05-25 02:22:03');
INSERT INTO `sys_logininfor` VALUES (10924, 'test123', '192.168.2.171', '内网IP', 'Chrome 8', 'Windows 10', '0', '退出成功', '2020-05-25 02:24:51');
INSERT INTO `sys_logininfor` VALUES (10925, 'test123', '192.168.2.171', '内网IP', 'Chrome 8', 'Windows 10', '0', '退出成功', '2020-05-25 02:27:51');
INSERT INTO `sys_logininfor` VALUES (10926, 'test123', '192.168.2.171', '内网IP', 'Chrome 8', 'Windows 10', '0', '退出成功', '2020-05-25 02:29:44');
INSERT INTO `sys_logininfor` VALUES (10927, 'test123', '192.168.2.171', '内网IP', 'Chrome 8', 'Windows 10', '0', '退出成功', '2020-05-25 02:31:31');
INSERT INTO `sys_logininfor` VALUES (10928, 'test123', '192.168.2.171', '内网IP', 'Chrome 8', 'Windows 10', '0', '退出成功', '2020-05-25 02:33:28');
INSERT INTO `sys_logininfor` VALUES (10929, 'test123', '192.168.2.171', '内网IP', 'Chrome 8', 'Windows 10', '0', '退出成功', '2020-05-25 02:42:37');
INSERT INTO `sys_logininfor` VALUES (10930, 'test3333', '0:0:0:0:0:0:0:1', 'XX XX', 'Chrome', 'Windows 10', '1', '用户不存在/密码错误', '2020-05-25 02:44:48');
INSERT INTO `sys_logininfor` VALUES (10931, 'test3333', '0:0:0:0:0:0:0:1', 'XX XX', 'Chrome', 'Windows 10', '1', '用户不存在/密码错误', '2020-05-25 02:44:50');
INSERT INTO `sys_logininfor` VALUES (10932, 'test3333', '0:0:0:0:0:0:0:1', 'XX XX', 'Chrome', 'Windows 10', '0', '退出成功', '2020-05-25 02:44:56');
INSERT INTO `sys_logininfor` VALUES (10933, 'test123', '192.168.2.171', '内网IP', 'Chrome 8', 'Windows 10', '0', '退出成功', '2020-05-25 02:45:18');
INSERT INTO `sys_logininfor` VALUES (10934, 'testpeng', '0:0:0:0:0:0:0:1', 'XX XX', 'Chrome 8', 'Windows 10', '1', '用户不存在/密码错误', '2020-05-25 02:47:08');
INSERT INTO `sys_logininfor` VALUES (10935, 'testpeng', '0:0:0:0:0:0:0:1', 'XX XX', 'Chrome 8', 'Windows 10', '1', '用户不存在/密码错误', '2020-05-25 02:47:21');
INSERT INTO `sys_logininfor` VALUES (10936, 'testpeng', '0:0:0:0:0:0:0:1', 'XX XX', 'Chrome 8', 'Windows 10', '1', '* 必须填写', '2020-05-25 02:47:30');
INSERT INTO `sys_logininfor` VALUES (10937, 'testpeng', '0:0:0:0:0:0:0:1', 'XX XX', 'Chrome 8', 'Windows 10', '1', '用户不存在/密码错误', '2020-05-25 02:47:35');
INSERT INTO `sys_logininfor` VALUES (10938, 'testpeng', '0:0:0:0:0:0:0:1', 'XX XX', 'Chrome 8', 'Windows 10', '1', '用户不存在/密码错误', '2020-05-25 02:47:42');
INSERT INTO `sys_logininfor` VALUES (10939, 'testpeng', '0:0:0:0:0:0:0:1', 'XX XX', 'Chrome 8', 'Windows 10', '1', '用户不存在/密码错误', '2020-05-25 02:47:47');
INSERT INTO `sys_logininfor` VALUES (10940, 'testpeng', '0:0:0:0:0:0:0:1', 'XX XX', 'Chrome 8', 'Windows 10', '1', '用户不存在/密码错误', '2020-05-25 02:48:28');
INSERT INTO `sys_logininfor` VALUES (10941, 'test', '0:0:0:0:0:0:0:1', 'XX XX', 'Chrome 8', 'Windows 10', '1', '用户不存在/密码错误', '2020-05-25 02:48:32');
INSERT INTO `sys_logininfor` VALUES (10942, 'test123', '0:0:0:0:0:0:0:1', 'XX XX', 'Chrome 8', 'Windows 10', '1', '用户不存在/密码错误', '2020-05-25 02:48:36');
INSERT INTO `sys_logininfor` VALUES (10943, 'test', '0:0:0:0:0:0:0:1', 'XX XX', 'Chrome 8', 'Windows 10', '1', '用户不存在/密码错误', '2020-05-25 02:48:40');
INSERT INTO `sys_logininfor` VALUES (10944, 'test', '0:0:0:0:0:0:0:1', 'XX XX', 'Chrome 8', 'Windows 10', '1', '用户不存在/密码错误', '2020-05-25 02:49:05');
INSERT INTO `sys_logininfor` VALUES (10945, 'test', '0:0:0:0:0:0:0:1', 'XX XX', 'Chrome 8', 'Windows 10', '1', '用户不存在/密码错误', '2020-05-25 02:49:31');
INSERT INTO `sys_logininfor` VALUES (10946, 'testpeng', '0:0:0:0:0:0:0:1', 'XX XX', 'Chrome 8', 'Windows 10', '1', '用户不存在/密码错误', '2020-05-25 02:49:51');
INSERT INTO `sys_logininfor` VALUES (10947, 'testpeng', '0:0:0:0:0:0:0:1', 'XX XX', 'Chrome 8', 'Windows 10', '1', '用户不存在/密码错误', '2020-05-25 02:49:52');
INSERT INTO `sys_logininfor` VALUES (10948, 'testpeng', '0:0:0:0:0:0:0:1', 'XX XX', 'Chrome 8', 'Windows 10', '1', '用户不存在/密码错误', '2020-05-25 02:49:52');
INSERT INTO `sys_logininfor` VALUES (10949, 'testpeng', '0:0:0:0:0:0:0:1', 'XX XX', 'Chrome 8', 'Windows 10', '1', '用户不存在/密码错误', '2020-05-25 02:49:53');
INSERT INTO `sys_logininfor` VALUES (10950, 'testpeng', '0:0:0:0:0:0:0:1', 'XX XX', 'Chrome 8', 'Windows 10', '1', '用户不存在/密码错误', '2020-05-25 02:49:53');
INSERT INTO `sys_logininfor` VALUES (10951, 'testpeng', '0:0:0:0:0:0:0:1', 'XX XX', 'Chrome 8', 'Windows 10', '1', '用户不存在/密码错误', '2020-05-25 02:49:53');
INSERT INTO `sys_logininfor` VALUES (10952, 'testpeng', '0:0:0:0:0:0:0:1', 'XX XX', 'Chrome 8', 'Windows 10', '1', '用户不存在/密码错误', '2020-05-25 02:49:53');
INSERT INTO `sys_logininfor` VALUES (10953, 'testpeng', '0:0:0:0:0:0:0:1', 'XX XX', 'Chrome 8', 'Windows 10', '1', '用户不存在/密码错误', '2020-05-25 02:49:53');
INSERT INTO `sys_logininfor` VALUES (10954, 'testpeng', '0:0:0:0:0:0:0:1', 'XX XX', 'Chrome 8', 'Windows 10', '1', '用户不存在/密码错误', '2020-05-25 02:49:54');
INSERT INTO `sys_logininfor` VALUES (10955, 'testpeng', '0:0:0:0:0:0:0:1', 'XX XX', 'Chrome 8', 'Windows 10', '1', '用户不存在/密码错误', '2020-05-25 02:49:54');
INSERT INTO `sys_logininfor` VALUES (10956, 'testpeng', '0:0:0:0:0:0:0:1', 'XX XX', 'Chrome 8', 'Windows 10', '1', '用户不存在/密码错误', '2020-05-25 02:49:54');
INSERT INTO `sys_logininfor` VALUES (10957, 'testpeng', '0:0:0:0:0:0:0:1', 'XX XX', 'Chrome 8', 'Windows 10', '1', '用户不存在/密码错误', '2020-05-25 02:49:54');
INSERT INTO `sys_logininfor` VALUES (10958, 'testpeng', '0:0:0:0:0:0:0:1', 'XX XX', 'Chrome 8', 'Windows 10', '1', '用户不存在/密码错误', '2020-05-25 02:49:54');
INSERT INTO `sys_logininfor` VALUES (10959, 'testpeng', '0:0:0:0:0:0:0:1', 'XX XX', 'Chrome 8', 'Windows 10', '1', '用户不存在/密码错误', '2020-05-25 02:49:55');
INSERT INTO `sys_logininfor` VALUES (10960, 'testpeng', '0:0:0:0:0:0:0:1', 'XX XX', 'Chrome 8', 'Windows 10', '1', '用户不存在/密码错误', '2020-05-25 02:49:55');
INSERT INTO `sys_logininfor` VALUES (10961, 'testpeng', '0:0:0:0:0:0:0:1', 'XX XX', 'Chrome 8', 'Windows 10', '1', '用户不存在/密码错误', '2020-05-25 02:49:55');
INSERT INTO `sys_logininfor` VALUES (10962, 'testpeng', '0:0:0:0:0:0:0:1', 'XX XX', 'Chrome 8', 'Windows 10', '1', '用户不存在/密码错误', '2020-05-25 02:49:55');
INSERT INTO `sys_logininfor` VALUES (10963, 'testpeng', '0:0:0:0:0:0:0:1', 'XX XX', 'Chrome 8', 'Windows 10', '1', '用户不存在/密码错误', '2020-05-25 02:49:55');
INSERT INTO `sys_logininfor` VALUES (10964, 'testpeng', '0:0:0:0:0:0:0:1', 'XX XX', 'Chrome 8', 'Windows 10', '1', '用户不存在/密码错误', '2020-05-25 02:49:56');
INSERT INTO `sys_logininfor` VALUES (10965, 'testpeng', '0:0:0:0:0:0:0:1', 'XX XX', 'Chrome 8', 'Windows 10', '1', '用户不存在/密码错误', '2020-05-25 02:49:56');
INSERT INTO `sys_logininfor` VALUES (10966, 'testpeng', '0:0:0:0:0:0:0:1', 'XX XX', 'Chrome 8', 'Windows 10', '1', '用户不存在/密码错误', '2020-05-25 02:49:56');
INSERT INTO `sys_logininfor` VALUES (10967, 'testpeng', '0:0:0:0:0:0:0:1', 'XX XX', 'Chrome 8', 'Windows 10', '1', '用户不存在/密码错误', '2020-05-25 02:49:56');
INSERT INTO `sys_logininfor` VALUES (10968, 'testpeng', '0:0:0:0:0:0:0:1', 'XX XX', 'Chrome 8', 'Windows 10', '1', '用户不存在/密码错误', '2020-05-25 02:49:56');
INSERT INTO `sys_logininfor` VALUES (10969, 'testpeng', '0:0:0:0:0:0:0:1', 'XX XX', 'Chrome 8', 'Windows 10', '1', '用户不存在/密码错误', '2020-05-25 02:49:56');
INSERT INTO `sys_logininfor` VALUES (10970, 'testpeng', '0:0:0:0:0:0:0:1', 'XX XX', 'Chrome 8', 'Windows 10', '1', '用户不存在/密码错误', '2020-05-25 02:49:57');
INSERT INTO `sys_logininfor` VALUES (10971, 'testpeng', '0:0:0:0:0:0:0:1', 'XX XX', 'Chrome 8', 'Windows 10', '1', '用户不存在/密码错误', '2020-05-25 02:49:57');
INSERT INTO `sys_logininfor` VALUES (10972, 'testpeng', '0:0:0:0:0:0:0:1', 'XX XX', 'Chrome 8', 'Windows 10', '1', '用户不存在/密码错误', '2020-05-25 02:49:57');
INSERT INTO `sys_logininfor` VALUES (10973, 'testpeng', '0:0:0:0:0:0:0:1', 'XX XX', 'Chrome 8', 'Windows 10', '1', '用户不存在/密码错误', '2020-05-25 02:49:57');
INSERT INTO `sys_logininfor` VALUES (10974, 'testpeng', '0:0:0:0:0:0:0:1', 'XX XX', 'Chrome 8', 'Windows 10', '1', '用户不存在/密码错误', '2020-05-25 02:49:57');
INSERT INTO `sys_logininfor` VALUES (10975, 'testpeng', '0:0:0:0:0:0:0:1', 'XX XX', 'Chrome 8', 'Windows 10', '1', '用户不存在/密码错误', '2020-05-25 02:49:58');
INSERT INTO `sys_logininfor` VALUES (10976, 'testpeng', '0:0:0:0:0:0:0:1', 'XX XX', 'Chrome 8', 'Windows 10', '1', '用户不存在/密码错误', '2020-05-25 02:49:58');
INSERT INTO `sys_logininfor` VALUES (10977, 'testpeng', '0:0:0:0:0:0:0:1', 'XX XX', 'Chrome 8', 'Windows 10', '1', '用户不存在/密码错误', '2020-05-25 02:49:58');
INSERT INTO `sys_logininfor` VALUES (10978, 'testpeng', '0:0:0:0:0:0:0:1', 'XX XX', 'Chrome 8', 'Windows 10', '1', '用户不存在/密码错误', '2020-05-25 02:49:58');
INSERT INTO `sys_logininfor` VALUES (10979, 'testpeng', '0:0:0:0:0:0:0:1', 'XX XX', 'Chrome 8', 'Windows 10', '1', '用户不存在/密码错误', '2020-05-25 02:49:58');
INSERT INTO `sys_logininfor` VALUES (10980, 'testpeng', '0:0:0:0:0:0:0:1', 'XX XX', 'Chrome 8', 'Windows 10', '1', '用户不存在/密码错误', '2020-05-25 02:49:58');
INSERT INTO `sys_logininfor` VALUES (10981, 'testpeng', '0:0:0:0:0:0:0:1', 'XX XX', 'Chrome 8', 'Windows 10', '1', '用户不存在/密码错误', '2020-05-25 02:49:59');
INSERT INTO `sys_logininfor` VALUES (10982, 'testpeng', '0:0:0:0:0:0:0:1', 'XX XX', 'Chrome 8', 'Windows 10', '1', '用户不存在/密码错误', '2020-05-25 02:49:59');
INSERT INTO `sys_logininfor` VALUES (10983, 'testpeng', '0:0:0:0:0:0:0:1', 'XX XX', 'Chrome 8', 'Windows 10', '1', '用户不存在/密码错误', '2020-05-25 02:49:59');
INSERT INTO `sys_logininfor` VALUES (10984, 'testpeng', '0:0:0:0:0:0:0:1', 'XX XX', 'Chrome 8', 'Windows 10', '1', '用户不存在/密码错误', '2020-05-25 02:49:59');
INSERT INTO `sys_logininfor` VALUES (10985, 'testpeng', '0:0:0:0:0:0:0:1', 'XX XX', 'Chrome 8', 'Windows 10', '1', '用户不存在/密码错误', '2020-05-25 02:49:59');
INSERT INTO `sys_logininfor` VALUES (10986, 'testpeng', '0:0:0:0:0:0:0:1', 'XX XX', 'Chrome 8', 'Windows 10', '1', '用户不存在/密码错误', '2020-05-25 02:50:00');
INSERT INTO `sys_logininfor` VALUES (10987, 'testpeng', '0:0:0:0:0:0:0:1', 'XX XX', 'Chrome 8', 'Windows 10', '1', '用户不存在/密码错误', '2020-05-25 02:50:00');
INSERT INTO `sys_logininfor` VALUES (10988, 'testpeng', '0:0:0:0:0:0:0:1', 'XX XX', 'Chrome 8', 'Windows 10', '1', '用户不存在/密码错误', '2020-05-25 02:50:00');
INSERT INTO `sys_logininfor` VALUES (10989, 'testpeng', '0:0:0:0:0:0:0:1', 'XX XX', 'Chrome 8', 'Windows 10', '1', '用户不存在/密码错误', '2020-05-25 02:50:00');
INSERT INTO `sys_logininfor` VALUES (10990, 'testpeng', '0:0:0:0:0:0:0:1', 'XX XX', 'Chrome 8', 'Windows 10', '1', '用户不存在/密码错误', '2020-05-25 02:50:00');
INSERT INTO `sys_logininfor` VALUES (10991, 'testpeng', '0:0:0:0:0:0:0:1', 'XX XX', 'Chrome 8', 'Windows 10', '1', '用户不存在/密码错误', '2020-05-25 02:50:01');
INSERT INTO `sys_logininfor` VALUES (10992, 'testpeng', '0:0:0:0:0:0:0:1', 'XX XX', 'Chrome 8', 'Windows 10', '1', '用户不存在/密码错误', '2020-05-25 02:50:01');
INSERT INTO `sys_logininfor` VALUES (10993, 'testpeng', '0:0:0:0:0:0:0:1', 'XX XX', 'Chrome 8', 'Windows 10', '1', '用户不存在/密码错误', '2020-05-25 02:50:01');
INSERT INTO `sys_logininfor` VALUES (10994, 'testpeng', '0:0:0:0:0:0:0:1', 'XX XX', 'Chrome 8', 'Windows 10', '1', '用户不存在/密码错误', '2020-05-25 02:50:01');
INSERT INTO `sys_logininfor` VALUES (10995, 'testpeng', '0:0:0:0:0:0:0:1', 'XX XX', 'Chrome 8', 'Windows 10', '1', '用户不存在/密码错误', '2020-05-25 02:50:17');
INSERT INTO `sys_logininfor` VALUES (10996, 'testpeng', '0:0:0:0:0:0:0:1', 'XX XX', 'Chrome 8', 'Windows 10', '1', '用户不存在/密码错误', '2020-05-25 02:50:17');
INSERT INTO `sys_logininfor` VALUES (10997, 'testpeng', '0:0:0:0:0:0:0:1', 'XX XX', 'Chrome 8', 'Windows 10', '1', '用户不存在/密码错误', '2020-05-25 02:50:18');
INSERT INTO `sys_logininfor` VALUES (10998, 'testpeng', '0:0:0:0:0:0:0:1', 'XX XX', 'Chrome 8', 'Windows 10', '1', '用户不存在/密码错误', '2020-05-25 02:50:18');
INSERT INTO `sys_logininfor` VALUES (10999, 'testpeng', '0:0:0:0:0:0:0:1', 'XX XX', 'Chrome 8', 'Windows 10', '1', '用户不存在/密码错误', '2020-05-25 02:50:19');
INSERT INTO `sys_logininfor` VALUES (11000, 'testpeng', '0:0:0:0:0:0:0:1', 'XX XX', 'Chrome 8', 'Windows 10', '1', '用户不存在/密码错误', '2020-05-25 02:50:19');
INSERT INTO `sys_logininfor` VALUES (11001, 'testpeng', '0:0:0:0:0:0:0:1', 'XX XX', 'Chrome 8', 'Windows 10', '1', '用户不存在/密码错误', '2020-05-25 02:50:19');
INSERT INTO `sys_logininfor` VALUES (11002, 'testpeng', '0:0:0:0:0:0:0:1', 'XX XX', 'Chrome 8', 'Windows 10', '1', '用户不存在/密码错误', '2020-05-25 02:50:19');
INSERT INTO `sys_logininfor` VALUES (11003, 'testpeng', '0:0:0:0:0:0:0:1', 'XX XX', 'Chrome 8', 'Windows 10', '1', '用户不存在/密码错误', '2020-05-25 02:50:31');
INSERT INTO `sys_logininfor` VALUES (11004, 'testpeng', '0:0:0:0:0:0:0:1', 'XX XX', 'Chrome 8', 'Windows 10', '1', '用户不存在/密码错误', '2020-05-25 02:50:31');
INSERT INTO `sys_logininfor` VALUES (11005, 'peng123', '0:0:0:0:0:0:0:1', 'XX XX', 'Chrome 8', 'Windows 10', '1', '用户不存在/密码错误', '2020-05-25 02:50:33');
INSERT INTO `sys_logininfor` VALUES (11006, 'peng123', '0:0:0:0:0:0:0:1', 'XX XX', 'Chrome 8', 'Windows 10', '1', '用户不存在/密码错误', '2020-05-25 02:50:34');
INSERT INTO `sys_logininfor` VALUES (11007, 'peng123', '0:0:0:0:0:0:0:1', 'XX XX', 'Chrome 8', 'Windows 10', '1', '用户不存在/密码错误', '2020-05-25 02:50:34');
INSERT INTO `sys_logininfor` VALUES (11008, 'peng123', '0:0:0:0:0:0:0:1', 'XX XX', 'Chrome 8', 'Windows 10', '1', '用户不存在/密码错误', '2020-05-25 02:50:34');
INSERT INTO `sys_logininfor` VALUES (11009, 'peng123', '0:0:0:0:0:0:0:1', 'XX XX', 'Chrome 8', 'Windows 10', '1', '用户不存在/密码错误', '2020-05-25 02:50:35');
INSERT INTO `sys_logininfor` VALUES (11010, 'peng123', '0:0:0:0:0:0:0:1', 'XX XX', 'Chrome 8', 'Windows 10', '1', '用户不存在/密码错误', '2020-05-25 02:50:35');
INSERT INTO `sys_logininfor` VALUES (11011, 'peng123', '0:0:0:0:0:0:0:1', 'XX XX', 'Chrome 8', 'Windows 10', '1', '用户不存在/密码错误', '2020-05-25 02:50:36');
INSERT INTO `sys_logininfor` VALUES (11012, 'peng123', '0:0:0:0:0:0:0:1', 'XX XX', 'Chrome 8', 'Windows 10', '1', '用户不存在/密码错误', '2020-05-25 02:50:37');
INSERT INTO `sys_logininfor` VALUES (11013, 'peng123', '0:0:0:0:0:0:0:1', 'XX XX', 'Chrome 8', 'Windows 10', '1', '用户不存在/密码错误', '2020-05-25 02:50:38');
INSERT INTO `sys_logininfor` VALUES (11014, 'peng123', '0:0:0:0:0:0:0:1', 'XX XX', 'Chrome 8', 'Windows 10', '1', '用户不存在/密码错误', '2020-05-25 02:50:39');
INSERT INTO `sys_logininfor` VALUES (11015, 'peng123', '0:0:0:0:0:0:0:1', 'XX XX', 'Chrome 8', 'Windows 10', '1', '用户不存在/密码错误', '2020-05-25 02:50:39');
INSERT INTO `sys_logininfor` VALUES (11016, 'peng123', '0:0:0:0:0:0:0:1', 'XX XX', 'Chrome 8', 'Windows 10', '1', '用户不存在/密码错误', '2020-05-25 02:50:40');
INSERT INTO `sys_logininfor` VALUES (11017, 'peng123', '0:0:0:0:0:0:0:1', 'XX XX', 'Chrome 8', 'Windows 10', '1', '用户不存在/密码错误', '2020-05-25 02:50:41');
INSERT INTO `sys_logininfor` VALUES (11018, 'peng123', '0:0:0:0:0:0:0:1', 'XX XX', 'Chrome 8', 'Windows 10', '1', '用户不存在/密码错误', '2020-05-25 02:50:42');
INSERT INTO `sys_logininfor` VALUES (11019, 'peng123', '0:0:0:0:0:0:0:1', 'XX XX', 'Chrome 8', 'Windows 10', '1', '用户不存在/密码错误', '2020-05-25 02:50:42');
INSERT INTO `sys_logininfor` VALUES (11020, 'peng123', '0:0:0:0:0:0:0:1', 'XX XX', 'Chrome 8', 'Windows 10', '1', '用户不存在/密码错误', '2020-05-25 02:50:42');
INSERT INTO `sys_logininfor` VALUES (11021, 'peng123', '0:0:0:0:0:0:0:1', 'XX XX', 'Chrome 8', 'Windows 10', '1', '用户不存在/密码错误', '2020-05-25 02:50:43');
INSERT INTO `sys_logininfor` VALUES (11022, 'peng123', '0:0:0:0:0:0:0:1', 'XX XX', 'Chrome 8', 'Windows 10', '1', '用户不存在/密码错误', '2020-05-25 02:50:43');
INSERT INTO `sys_logininfor` VALUES (11023, 'testpeng', '0:0:0:0:0:0:0:1', 'XX XX', 'Chrome 8', 'Windows 10', '1', '用户不存在/密码错误', '2020-05-25 02:50:45');
INSERT INTO `sys_logininfor` VALUES (11024, 'test123', '0:0:0:0:0:0:0:1', 'XX XX', 'Chrome', 'Windows 10', '1', '用户不存在/密码错误', '2020-05-25 02:50:55');
INSERT INTO `sys_logininfor` VALUES (11025, 'test123', '0:0:0:0:0:0:0:1', 'XX XX', 'Chrome', 'Windows 10', '1', '用户不存在/密码错误', '2020-05-25 02:50:55');
INSERT INTO `sys_logininfor` VALUES (11026, 'test123', '0:0:0:0:0:0:0:1', 'XX XX', 'Chrome', 'Windows 10', '1', '用户不存在/密码错误', '2020-05-25 02:50:55');
INSERT INTO `sys_logininfor` VALUES (11027, 'test123', '0:0:0:0:0:0:0:1', 'XX XX', 'Chrome', 'Windows 10', '1', '用户不存在/密码错误', '2020-05-25 02:50:55');
INSERT INTO `sys_logininfor` VALUES (11028, 'test123', '0:0:0:0:0:0:0:1', 'XX XX', 'Chrome', 'Windows 10', '1', '用户不存在/密码错误', '2020-05-25 02:50:55');
INSERT INTO `sys_logininfor` VALUES (11029, 'test123', '0:0:0:0:0:0:0:1', 'XX XX', 'Chrome', 'Windows 10', '1', '用户不存在/密码错误', '2020-05-25 02:50:56');
INSERT INTO `sys_logininfor` VALUES (11030, 'test123', '0:0:0:0:0:0:0:1', 'XX XX', 'Chrome', 'Windows 10', '1', '用户不存在/密码错误', '2020-05-25 02:50:56');
INSERT INTO `sys_logininfor` VALUES (11031, 'test123', '0:0:0:0:0:0:0:1', 'XX XX', 'Chrome', 'Windows 10', '1', '用户不存在/密码错误', '2020-05-25 02:50:56');
INSERT INTO `sys_logininfor` VALUES (11032, 'test123', '0:0:0:0:0:0:0:1', 'XX XX', 'Chrome', 'Windows 10', '1', '用户不存在/密码错误', '2020-05-25 02:50:56');
INSERT INTO `sys_logininfor` VALUES (11033, 'test123', '0:0:0:0:0:0:0:1', 'XX XX', 'Chrome', 'Windows 10', '1', '用户不存在/密码错误', '2020-05-25 02:50:56');
INSERT INTO `sys_logininfor` VALUES (11034, 'test123', '0:0:0:0:0:0:0:1', 'XX XX', 'Chrome', 'Windows 10', '1', '用户不存在/密码错误', '2020-05-25 02:50:56');
INSERT INTO `sys_logininfor` VALUES (11035, 'test123', '0:0:0:0:0:0:0:1', 'XX XX', 'Chrome', 'Windows 10', '1', '用户不存在/密码错误', '2020-05-25 02:50:56');
INSERT INTO `sys_logininfor` VALUES (11036, 'test123', '0:0:0:0:0:0:0:1', 'XX XX', 'Chrome', 'Windows 10', '1', '用户不存在/密码错误', '2020-05-25 02:50:56');
INSERT INTO `sys_logininfor` VALUES (11037, 'test123', '0:0:0:0:0:0:0:1', 'XX XX', 'Chrome', 'Windows 10', '1', '用户不存在/密码错误', '2020-05-25 02:50:59');
INSERT INTO `sys_logininfor` VALUES (11038, 'test123', '0:0:0:0:0:0:0:1', 'XX XX', 'Chrome', 'Windows 10', '1', '用户不存在/密码错误', '2020-05-25 02:51:00');
INSERT INTO `sys_logininfor` VALUES (11039, 'peng123', '0:0:0:0:0:0:0:1', 'XX XX', 'Chrome 8', 'Windows 10', '1', '用户不存在/密码错误', '2020-05-25 02:51:16');
INSERT INTO `sys_logininfor` VALUES (11040, 'peng123', '0:0:0:0:0:0:0:1', 'XX XX', 'Chrome 8', 'Windows 10', '1', '用户不存在/密码错误', '2020-05-25 02:51:16');
INSERT INTO `sys_logininfor` VALUES (11041, 'peng123', '0:0:0:0:0:0:0:1', 'XX XX', 'Chrome 8', 'Windows 10', '1', '用户不存在/密码错误', '2020-05-25 02:51:17');
INSERT INTO `sys_logininfor` VALUES (11042, 'peng123', '0:0:0:0:0:0:0:1', 'XX XX', 'Chrome 8', 'Windows 10', '1', '用户不存在/密码错误', '2020-05-25 02:51:18');
INSERT INTO `sys_logininfor` VALUES (11043, 'peng123', '0:0:0:0:0:0:0:1', 'XX XX', 'Chrome 8', 'Windows 10', '1', '用户不存在/密码错误', '2020-05-25 02:51:18');
INSERT INTO `sys_logininfor` VALUES (11044, 'peng123', '0:0:0:0:0:0:0:1', 'XX XX', 'Chrome 8', 'Windows 10', '1', '用户不存在/密码错误', '2020-05-25 02:51:19');
INSERT INTO `sys_logininfor` VALUES (11045, 'peng123', '0:0:0:0:0:0:0:1', 'XX XX', 'Chrome 8', 'Windows 10', '1', '用户不存在/密码错误', '2020-05-25 02:52:57');
INSERT INTO `sys_logininfor` VALUES (11046, 'peng123', '0:0:0:0:0:0:0:1', 'XX XX', 'Chrome 8', 'Windows 10', '1', '用户不存在/密码错误', '2020-05-25 02:52:58');
INSERT INTO `sys_logininfor` VALUES (11047, 'peng123', '0:0:0:0:0:0:0:1', 'XX XX', 'Chrome 8', 'Windows 10', '1', '用户不存在/密码错误', '2020-05-25 02:52:59');
INSERT INTO `sys_logininfor` VALUES (11048, 'peng123', '0:0:0:0:0:0:0:1', 'XX XX', 'Chrome 8', 'Windows 10', '1', '用户不存在/密码错误', '2020-05-25 02:52:59');
INSERT INTO `sys_logininfor` VALUES (11049, 'peng123', '0:0:0:0:0:0:0:1', 'XX XX', 'Chrome 8', 'Windows 10', '1', '用户不存在/密码错误', '2020-05-25 02:53:00');
INSERT INTO `sys_logininfor` VALUES (11050, 'peng123', '0:0:0:0:0:0:0:1', 'XX XX', 'Chrome 8', 'Windows 10', '1', '用户不存在/密码错误', '2020-05-25 02:53:00');
INSERT INTO `sys_logininfor` VALUES (11051, 'peng123', '0:0:0:0:0:0:0:1', 'XX XX', 'Chrome 8', 'Windows 10', '1', '用户不存在/密码错误', '2020-05-25 02:53:05');
INSERT INTO `sys_logininfor` VALUES (11052, 'test3333', '192.168.2.171', '内网IP', 'Chrome 8', 'Windows 10', '1', '用户不存在/密码错误', '2020-05-25 02:53:11');
INSERT INTO `sys_logininfor` VALUES (11053, 'test3333', '192.168.2.171', '内网IP', 'Chrome 8', 'Windows 10', '1', '用户不存在/密码错误', '2020-05-25 02:53:17');
INSERT INTO `sys_logininfor` VALUES (11054, 'test3333', '192.168.2.171', '内网IP', 'Chrome 8', 'Windows 10', '1', '用户不存在/密码错误', '2020-05-25 02:53:25');
INSERT INTO `sys_logininfor` VALUES (11055, 'test3333', '192.168.2.171', '内网IP', 'Chrome 8', 'Windows 10', '0', '退出成功', '2020-05-25 02:53:35');
INSERT INTO `sys_logininfor` VALUES (11056, 'peng123', '0:0:0:0:0:0:0:1', 'XX XX', 'Chrome 8', 'Windows 10', '1', '用户不存在/密码错误', '2020-05-25 02:54:45');
INSERT INTO `sys_logininfor` VALUES (11057, 'peng123', '0:0:0:0:0:0:0:1', 'XX XX', 'Chrome 8', 'Windows 10', '1', '用户不存在/密码错误', '2020-05-25 02:54:45');
INSERT INTO `sys_logininfor` VALUES (11058, 'peng123', '0:0:0:0:0:0:0:1', 'XX XX', 'Chrome 8', 'Windows 10', '1', '用户不存在/密码错误', '2020-05-25 02:54:45');
INSERT INTO `sys_logininfor` VALUES (11059, 'peng123', '0:0:0:0:0:0:0:1', 'XX XX', 'Chrome 8', 'Windows 10', '1', '用户不存在/密码错误', '2020-05-25 02:54:45');
INSERT INTO `sys_logininfor` VALUES (11060, 'peng123', '0:0:0:0:0:0:0:1', 'XX XX', 'Chrome 8', 'Windows 10', '1', '用户不存在/密码错误', '2020-05-25 02:54:45');
INSERT INTO `sys_logininfor` VALUES (11061, 'peng123', '0:0:0:0:0:0:0:1', 'XX XX', 'Chrome 8', 'Windows 10', '1', '用户不存在/密码错误', '2020-05-25 02:54:45');
INSERT INTO `sys_logininfor` VALUES (11062, 'peng123', '0:0:0:0:0:0:0:1', 'XX XX', 'Chrome 8', 'Windows 10', '1', '用户不存在/密码错误', '2020-05-25 02:54:46');
INSERT INTO `sys_logininfor` VALUES (11063, 'peng123', '0:0:0:0:0:0:0:1', 'XX XX', 'Chrome 8', 'Windows 10', '1', '用户不存在/密码错误', '2020-05-25 02:54:46');
INSERT INTO `sys_logininfor` VALUES (11064, 'peng123', '0:0:0:0:0:0:0:1', 'XX XX', 'Chrome 8', 'Windows 10', '1', '用户不存在/密码错误', '2020-05-25 02:54:46');
INSERT INTO `sys_logininfor` VALUES (11065, 'peng123', '0:0:0:0:0:0:0:1', 'XX XX', 'Chrome 8', 'Windows 10', '1', '用户不存在/密码错误', '2020-05-25 02:54:46');
INSERT INTO `sys_logininfor` VALUES (11066, 'peng123', '0:0:0:0:0:0:0:1', 'XX XX', 'Chrome 8', 'Windows 10', '1', '用户不存在/密码错误', '2020-05-25 02:54:46');
INSERT INTO `sys_logininfor` VALUES (11067, 'peng123', '0:0:0:0:0:0:0:1', 'XX XX', 'Chrome 8', 'Windows 10', '1', '用户不存在/密码错误', '2020-05-25 02:54:47');
INSERT INTO `sys_logininfor` VALUES (11068, 'peng123', '0:0:0:0:0:0:0:1', 'XX XX', 'Chrome 8', 'Windows 10', '1', '用户不存在/密码错误', '2020-05-25 02:54:47');
INSERT INTO `sys_logininfor` VALUES (11069, 'peng123', '0:0:0:0:0:0:0:1', 'XX XX', 'Chrome 8', 'Windows 10', '1', '用户不存在/密码错误', '2020-05-25 02:54:47');
INSERT INTO `sys_logininfor` VALUES (11070, 'peng123', '0:0:0:0:0:0:0:1', 'XX XX', 'Chrome 8', 'Windows 10', '1', '用户不存在/密码错误', '2020-05-25 02:54:47');
INSERT INTO `sys_logininfor` VALUES (11071, 'peng123', '0:0:0:0:0:0:0:1', 'XX XX', 'Chrome 8', 'Windows 10', '1', '用户不存在/密码错误', '2020-05-25 02:54:47');
INSERT INTO `sys_logininfor` VALUES (11072, 'peng123', '0:0:0:0:0:0:0:1', 'XX XX', 'Chrome 8', 'Windows 10', '1', '用户不存在/密码错误', '2020-05-25 02:54:48');
INSERT INTO `sys_logininfor` VALUES (11073, 'peng123', '0:0:0:0:0:0:0:1', 'XX XX', 'Chrome 8', 'Windows 10', '1', '用户不存在/密码错误', '2020-05-25 02:54:48');
INSERT INTO `sys_logininfor` VALUES (11074, 'peng123', '0:0:0:0:0:0:0:1', 'XX XX', 'Chrome 8', 'Windows 10', '1', '用户不存在/密码错误', '2020-05-25 02:54:48');
INSERT INTO `sys_logininfor` VALUES (11075, 'peng123', '0:0:0:0:0:0:0:1', 'XX XX', 'Chrome 8', 'Windows 10', '1', '用户不存在/密码错误', '2020-05-25 02:54:48');
INSERT INTO `sys_logininfor` VALUES (11076, 'peng123', '0:0:0:0:0:0:0:1', 'XX XX', 'Chrome 8', 'Windows 10', '1', '用户不存在/密码错误', '2020-05-25 02:54:48');
INSERT INTO `sys_logininfor` VALUES (11077, 'peng123', '0:0:0:0:0:0:0:1', 'XX XX', 'Chrome 8', 'Windows 10', '1', '用户不存在/密码错误', '2020-05-25 02:54:48');
INSERT INTO `sys_logininfor` VALUES (11078, 'peng123', '0:0:0:0:0:0:0:1', 'XX XX', 'Chrome 8', 'Windows 10', '1', '用户不存在/密码错误', '2020-05-25 02:54:49');
INSERT INTO `sys_logininfor` VALUES (11079, 'peng123', '0:0:0:0:0:0:0:1', 'XX XX', 'Chrome 8', 'Windows 10', '1', '用户不存在/密码错误', '2020-05-25 02:54:49');
INSERT INTO `sys_logininfor` VALUES (11080, 'peng123', '0:0:0:0:0:0:0:1', 'XX XX', 'Chrome 8', 'Windows 10', '1', '用户不存在/密码错误', '2020-05-25 02:54:49');
INSERT INTO `sys_logininfor` VALUES (11081, 'peng123', '0:0:0:0:0:0:0:1', 'XX XX', 'Chrome 8', 'Windows 10', '1', '用户不存在/密码错误', '2020-05-25 02:54:49');
INSERT INTO `sys_logininfor` VALUES (11082, 'peng123', '0:0:0:0:0:0:0:1', 'XX XX', 'Chrome 8', 'Windows 10', '1', '用户不存在/密码错误', '2020-05-25 02:54:49');
INSERT INTO `sys_logininfor` VALUES (11083, 'peng123', '0:0:0:0:0:0:0:1', 'XX XX', 'Chrome 8', 'Windows 10', '1', '用户不存在/密码错误', '2020-05-25 02:54:50');
INSERT INTO `sys_logininfor` VALUES (11084, 'peng123', '0:0:0:0:0:0:0:1', 'XX XX', 'Chrome 8', 'Windows 10', '1', '用户不存在/密码错误', '2020-05-25 02:54:50');
INSERT INTO `sys_logininfor` VALUES (11085, 'peng123', '0:0:0:0:0:0:0:1', 'XX XX', 'Chrome 8', 'Windows 10', '1', '用户不存在/密码错误', '2020-05-25 02:54:50');
INSERT INTO `sys_logininfor` VALUES (11086, 'peng123', '0:0:0:0:0:0:0:1', 'XX XX', 'Chrome 8', 'Windows 10', '1', '用户不存在/密码错误', '2020-05-25 02:54:50');
INSERT INTO `sys_logininfor` VALUES (11087, 'peng123', '0:0:0:0:0:0:0:1', 'XX XX', 'Chrome 8', 'Windows 10', '1', '用户不存在/密码错误', '2020-05-25 02:54:50');
INSERT INTO `sys_logininfor` VALUES (11088, 'peng123', '0:0:0:0:0:0:0:1', 'XX XX', 'Chrome 8', 'Windows 10', '1', '用户不存在/密码错误', '2020-05-25 02:54:51');
INSERT INTO `sys_logininfor` VALUES (11089, 'peng123', '0:0:0:0:0:0:0:1', 'XX XX', 'Chrome 8', 'Windows 10', '1', '用户不存在/密码错误', '2020-05-25 02:54:51');
INSERT INTO `sys_logininfor` VALUES (11090, 'peng123', '0:0:0:0:0:0:0:1', 'XX XX', 'Chrome 8', 'Windows 10', '1', '用户不存在/密码错误', '2020-05-25 02:54:51');
INSERT INTO `sys_logininfor` VALUES (11091, 'peng123', '0:0:0:0:0:0:0:1', 'XX XX', 'Chrome 8', 'Windows 10', '1', '用户不存在/密码错误', '2020-05-25 02:54:51');
INSERT INTO `sys_logininfor` VALUES (11092, 'test123', '0:0:0:0:0:0:0:1', 'XX XX', 'Chrome', 'Windows 10', '0', '退出成功', '2020-05-25 02:55:23');
INSERT INTO `sys_logininfor` VALUES (11093, 'testpeng', '0:0:0:0:0:0:0:1', 'XX XX', 'Chrome 8', 'Windows 10', '1', '用户不存在/密码错误', '2020-05-25 02:55:23');
INSERT INTO `sys_logininfor` VALUES (11094, 'testpeng', '0:0:0:0:0:0:0:1', 'XX XX', 'Chrome 8', 'Windows 10', '1', '用户不存在/密码错误', '2020-05-25 02:55:24');
INSERT INTO `sys_logininfor` VALUES (11095, 'testpeng', '0:0:0:0:0:0:0:1', 'XX XX', 'Chrome 8', 'Windows 10', '1', '用户不存在/密码错误', '2020-05-25 02:55:24');
INSERT INTO `sys_logininfor` VALUES (11096, 'testpeng', '0:0:0:0:0:0:0:1', 'XX XX', 'Chrome 8', 'Windows 10', '1', '用户不存在/密码错误', '2020-05-25 02:55:24');
INSERT INTO `sys_logininfor` VALUES (11097, 'testpeng', '0:0:0:0:0:0:0:1', 'XX XX', 'Chrome 8', 'Windows 10', '1', '用户不存在/密码错误', '2020-05-25 02:55:25');
INSERT INTO `sys_logininfor` VALUES (11098, 'testpeng', '0:0:0:0:0:0:0:1', 'XX XX', 'Chrome 8', 'Windows 10', '1', '用户不存在/密码错误', '2020-05-25 02:55:27');
INSERT INTO `sys_logininfor` VALUES (11099, 'testpeng', '0:0:0:0:0:0:0:1', 'XX XX', 'Chrome 8', 'Windows 10', '1', '用户不存在/密码错误', '2020-05-25 02:55:27');
INSERT INTO `sys_logininfor` VALUES (11100, 'testpeng', '0:0:0:0:0:0:0:1', 'XX XX', 'Chrome 8', 'Windows 10', '1', '用户不存在/密码错误', '2020-05-25 02:55:27');
INSERT INTO `sys_logininfor` VALUES (11101, 'testpeng', '0:0:0:0:0:0:0:1', 'XX XX', 'Chrome 8', 'Windows 10', '1', '用户不存在/密码错误', '2020-05-25 02:55:28');
INSERT INTO `sys_logininfor` VALUES (11102, 'testpeng', '0:0:0:0:0:0:0:1', 'XX XX', 'Chrome 8', 'Windows 10', '1', '用户不存在/密码错误', '2020-05-25 02:55:28');
INSERT INTO `sys_logininfor` VALUES (11103, 'testpeng', '0:0:0:0:0:0:0:1', 'XX XX', 'Chrome 8', 'Windows 10', '1', '用户不存在/密码错误', '2020-05-25 02:55:28');
INSERT INTO `sys_logininfor` VALUES (11104, 'testpeng', '0:0:0:0:0:0:0:1', 'XX XX', 'Chrome 8', 'Windows 10', '1', '用户不存在/密码错误', '2020-05-25 02:55:28');
INSERT INTO `sys_logininfor` VALUES (11105, 'testpeng', '0:0:0:0:0:0:0:1', 'XX XX', 'Chrome 8', 'Windows 10', '1', '用户不存在/密码错误', '2020-05-25 02:55:28');
INSERT INTO `sys_logininfor` VALUES (11106, 'testpeng', '0:0:0:0:0:0:0:1', 'XX XX', 'Chrome 8', 'Windows 10', '1', '用户不存在/密码错误', '2020-05-25 02:55:28');
INSERT INTO `sys_logininfor` VALUES (11107, 'testpeng', '0:0:0:0:0:0:0:1', 'XX XX', 'Chrome 8', 'Windows 10', '1', '用户不存在/密码错误', '2020-05-25 02:55:29');
INSERT INTO `sys_logininfor` VALUES (11108, 'testpeng', '0:0:0:0:0:0:0:1', 'XX XX', 'Chrome 8', 'Windows 10', '1', '用户不存在/密码错误', '2020-05-25 02:55:29');
INSERT INTO `sys_logininfor` VALUES (11109, 'testpeng', '0:0:0:0:0:0:0:1', 'XX XX', 'Chrome 8', 'Windows 10', '1', '用户不存在/密码错误', '2020-05-25 02:55:31');
INSERT INTO `sys_logininfor` VALUES (11110, 'peng123', '0:0:0:0:0:0:0:1', 'XX XX', 'Chrome 8', 'Windows 10', '1', '用户不存在/密码错误', '2020-05-25 02:55:46');
INSERT INTO `sys_logininfor` VALUES (11111, 'testpeng', '0:0:0:0:0:0:0:1', 'XX XX', 'Chrome 8', 'Windows 10', '1', '用户不存在/密码错误', '2020-05-25 02:55:57');
INSERT INTO `sys_logininfor` VALUES (11112, 'test3333', '192.168.2.171', '内网IP', 'Chrome 8', 'Windows 10', '0', '退出成功', '2020-05-25 02:57:41');
INSERT INTO `sys_logininfor` VALUES (11113, 'test3333', '192.168.2.171', '内网IP', 'Chrome 8', 'Windows 10', '0', '退出成功', '2020-05-25 02:58:49');
INSERT INTO `sys_logininfor` VALUES (11114, 'test3333', '192.168.2.171', '内网IP', 'Chrome 8', 'Windows 10', '0', '退出成功', '2020-05-25 03:02:16');
INSERT INTO `sys_logininfor` VALUES (11115, 'test3333', '192.168.2.171', '内网IP', 'Chrome 8', 'Windows 10', '0', '退出成功', '2020-05-25 03:04:02');
INSERT INTO `sys_logininfor` VALUES (11116, 'test3333', '192.168.2.171', '内网IP', 'Chrome 8', 'Windows 10', '0', '退出成功', '2020-05-25 03:05:29');
INSERT INTO `sys_logininfor` VALUES (11117, 'test3333', '192.168.2.171', '内网IP', 'Chrome 8', 'Windows 10', '0', '退出成功', '2020-05-25 03:23:33');
INSERT INTO `sys_logininfor` VALUES (11118, 'test3333', '192.168.2.171', '内网IP', 'Chrome 8', 'Windows 10', '0', '退出成功', '2020-05-25 03:27:17');
INSERT INTO `sys_logininfor` VALUES (11119, 'test3333', '192.168.2.171', '内网IP', 'Chrome 8', 'Windows 10', '0', '退出成功', '2020-05-25 03:30:22');
INSERT INTO `sys_logininfor` VALUES (11120, 'test123', '0:0:0:0:0:0:0:1', 'XX XX', 'Chrome', 'Windows 10', '1', '用户不存在/密码错误', '2020-05-25 05:47:25');
INSERT INTO `sys_logininfor` VALUES (11121, 'test123', '0:0:0:0:0:0:0:1', 'XX XX', 'Chrome', 'Windows 10', '0', '退出成功', '2020-05-25 05:47:25');
INSERT INTO `sys_logininfor` VALUES (11122, 'test123', '0:0:0:0:0:0:0:1', 'XX XX', 'Chrome', 'Windows 10', '1', '用户不存在/密码错误', '2020-05-25 05:47:25');
INSERT INTO `sys_logininfor` VALUES (11123, 'test3333', '192.168.2.171', '内网IP', 'Chrome 8', 'Windows 10', '0', '退出成功', '2020-05-25 05:52:15');
INSERT INTO `sys_logininfor` VALUES (11124, '', '192.168.2.171', '内网IP', 'Chrome 8', 'Windows 10', '1', '* 必须填写', '2020-05-25 06:07:52');
INSERT INTO `sys_logininfor` VALUES (11125, 'tset3333', '192.168.2.171', '内网IP', 'Chrome 8', 'Windows 10', '1', '用户不存在/密码错误', '2020-05-25 06:09:06');
INSERT INTO `sys_logininfor` VALUES (11126, 'test3333', '192.168.2.171', '内网IP', 'Chrome 8', 'Windows 10', '0', '退出成功', '2020-05-25 06:10:09');
INSERT INTO `sys_logininfor` VALUES (11127, 'test3333', '192.168.2.171', '内网IP', 'Chrome 8', 'Windows 10', '0', '退出成功', '2020-05-25 06:47:20');
INSERT INTO `sys_logininfor` VALUES (11128, 'test3333', '192.168.2.171', '内网IP', 'Chrome 8', 'Windows 10', '0', '退出成功', '2020-05-25 06:48:41');
INSERT INTO `sys_logininfor` VALUES (11129, 'test1234', '192.168.2.171', '内网IP', 'Chrome 8', 'Windows 10', '0', '退出成功', '2020-05-25 06:54:29');
INSERT INTO `sys_logininfor` VALUES (11130, 'test1234', '192.168.2.171', '内网IP', 'Chrome 8', 'Windows 10', '0', '退出成功', '2020-05-25 06:56:34');
INSERT INTO `sys_logininfor` VALUES (11131, 'test456', '192.168.2.171', '内网IP', 'Chrome 8', 'Windows 10', '0', '退出成功', '2020-05-25 07:10:41');
INSERT INTO `sys_logininfor` VALUES (11132, 'test456', '192.168.2.171', '内网IP', 'Chrome 8', 'Windows 10', '0', '退出成功', '2020-05-25 07:17:51');
INSERT INTO `sys_logininfor` VALUES (11133, 'test456', '192.168.2.171', '内网IP', 'Chrome 8', 'Windows 10', '0', '退出成功', '2020-05-25 07:18:05');
INSERT INTO `sys_logininfor` VALUES (11134, 'test456', '192.168.2.171', '内网IP', 'Chrome 8', 'Windows 10', '0', '退出成功', '2020-05-25 07:20:44');
INSERT INTO `sys_logininfor` VALUES (11135, 'test456', '192.168.2.171', '内网IP', 'Chrome 8', 'Windows 10', '0', '退出成功', '2020-05-25 07:22:39');
INSERT INTO `sys_logininfor` VALUES (11136, 'test555', '192.168.2.171', '内网IP', 'Chrome 8', 'Windows 10', '0', '退出成功', '2020-05-25 07:23:37');
INSERT INTO `sys_logininfor` VALUES (11137, 'test555', '192.168.2.171', '内网IP', 'Chrome 8', 'Windows 10', '0', '退出成功', '2020-05-25 07:28:03');
INSERT INTO `sys_logininfor` VALUES (11138, 'test555', '192.168.2.171', '内网IP', 'Chrome 8', 'Windows 10', '0', '退出成功', '2020-05-25 07:29:41');
INSERT INTO `sys_logininfor` VALUES (11139, 'test555', '192.168.2.171', '内网IP', 'Chrome 8', 'Windows 10', '1', '用户不存在/密码错误', '2020-05-25 10:00:26');
INSERT INTO `sys_logininfor` VALUES (11140, 'test123', '192.168.2.171', '内网IP', 'Chrome 8', 'Windows 10', '1', '用户不存在/密码错误', '2020-05-25 13:39:39');
INSERT INTO `sys_logininfor` VALUES (11141, 'test03', '192.168.2.171', '内网IP', 'Chrome 8', 'Windows 10', '1', '用户不存在/密码错误', '2020-05-25 13:40:22');
INSERT INTO `sys_logininfor` VALUES (11142, 'test03', '192.168.2.171', '内网IP', 'Chrome 8', 'Windows 10', '1', '用户不存在/密码错误', '2020-05-25 13:40:36');
INSERT INTO `sys_logininfor` VALUES (11143, 'test01', '192.168.2.171', '内网IP', 'Chrome 8', 'Windows 10', '1', '用户不存在/密码错误', '2020-05-25 13:41:57');
INSERT INTO `sys_logininfor` VALUES (11144, 'test01', '192.168.2.171', '内网IP', 'Chrome 8', 'Windows 10', '1', '用户不存在/密码错误', '2020-05-25 13:42:26');
INSERT INTO `sys_logininfor` VALUES (11145, 'test123', '0:0:0:0:0:0:0:1', 'XX XX', 'Chrome', 'Windows 10', '0', '退出成功', '2020-05-26 05:11:43');
INSERT INTO `sys_logininfor` VALUES (11146, 'test123', '0:0:0:0:0:0:0:1', 'XX XX', 'Chrome', 'Windows 10', '1', '用户不存在/密码错误', '2020-05-26 05:11:43');
INSERT INTO `sys_logininfor` VALUES (11147, 'test999', '192.168.2.171', '内网IP', 'Chrome 8', 'Windows 10', '0', '退出成功', '2020-05-26 05:45:27');
INSERT INTO `sys_logininfor` VALUES (11148, 'testpeng', '0:0:0:0:0:0:0:1', 'XX XX', 'Chrome 8', 'Windows 10', '1', '用户不存在/密码错误', '2020-05-26 05:57:42');
INSERT INTO `sys_logininfor` VALUES (11149, 'peng123', '0:0:0:0:0:0:0:1', 'XX XX', 'Chrome 8', 'Windows 10', '1', '用户不存在/密码错误', '2020-05-26 05:57:50');
INSERT INTO `sys_logininfor` VALUES (11150, 'peng123', '0:0:0:0:0:0:0:1', 'XX XX', 'Chrome 8', 'Windows 10', '1', '用户不存在/密码错误', '2020-05-26 06:05:11');
INSERT INTO `sys_logininfor` VALUES (11151, 'testpeng', '0:0:0:0:0:0:0:1', 'XX XX', 'Chrome 8', 'Windows 10', '1', '用户不存在/密码错误', '2020-05-26 06:05:18');
INSERT INTO `sys_logininfor` VALUES (11152, 'testpeng', '0:0:0:0:0:0:0:1', 'XX XX', 'Chrome 8', 'Windows 10', '1', '用户不存在/密码错误', '2020-05-26 06:06:58');
INSERT INTO `sys_logininfor` VALUES (11153, 'testpeng', '0:0:0:0:0:0:0:1', 'XX XX', 'Chrome 8', 'Windows 10', '1', '用户不存在/密码错误', '2020-05-26 06:07:04');
INSERT INTO `sys_logininfor` VALUES (11154, 'testpeng', '0:0:0:0:0:0:0:1', 'XX XX', 'Chrome 8', 'Windows 10', '1', '用户不存在/密码错误', '2020-05-26 06:07:13');
INSERT INTO `sys_logininfor` VALUES (11155, 'peng123', '0:0:0:0:0:0:0:1', 'XX XX', 'Chrome 8', 'Windows 10', '1', '用户不存在/密码错误', '2020-05-26 06:12:57');
INSERT INTO `sys_logininfor` VALUES (11156, 'peng123', '0:0:0:0:0:0:0:1', 'XX XX', 'Chrome 8', 'Windows 10', '1', '用户不存在/密码错误', '2020-05-26 06:13:02');
INSERT INTO `sys_logininfor` VALUES (11157, 'peng123', '0:0:0:0:0:0:0:1', 'XX XX', 'Chrome 8', 'Windows 10', '1', '用户不存在/密码错误', '2020-05-26 06:13:06');
INSERT INTO `sys_logininfor` VALUES (11158, 'peng123', '0:0:0:0:0:0:0:1', 'XX XX', 'Chrome 8', 'Windows 10', '1', '用户不存在/密码错误', '2020-05-26 06:13:09');
INSERT INTO `sys_logininfor` VALUES (11159, 'peng123', '0:0:0:0:0:0:0:1', 'XX XX', 'Chrome 8', 'Windows 10', '1', '用户不存在/密码错误', '2020-05-26 06:13:10');
INSERT INTO `sys_logininfor` VALUES (11160, 'test123', '0:0:0:0:0:0:0:1', 'XX XX', 'Chrome 8', 'Windows 10', '0', '退出成功', '2020-05-26 06:13:30');
INSERT INTO `sys_logininfor` VALUES (11161, 'test999', '192.168.2.171', '内网IP', 'Chrome 8', 'Windows 10', '0', '退出成功', '2020-05-26 06:18:09');
INSERT INTO `sys_logininfor` VALUES (11162, 'test999', '192.168.2.171', '内网IP', 'Chrome 8', 'Windows 10', '0', '退出成功', '2020-05-26 06:21:02');
INSERT INTO `sys_logininfor` VALUES (11163, 'test999', '192.168.2.171', '内网IP', 'Chrome 8', 'Windows 10', '0', '退出成功', '2020-05-26 06:25:52');
INSERT INTO `sys_logininfor` VALUES (11164, 'test999', '192.168.2.171', '内网IP', 'Chrome 8', 'Windows 10', '0', '退出成功', '2020-05-26 06:28:45');
INSERT INTO `sys_logininfor` VALUES (11165, 'test999', '192.168.2.171', '内网IP', 'Chrome 8', 'Windows 10', '0', '退出成功', '2020-05-26 06:30:00');
INSERT INTO `sys_logininfor` VALUES (11166, 'test999', '192.168.2.171', '内网IP', 'Chrome 8', 'Windows 10', '0', '退出成功', '2020-05-26 06:38:12');
INSERT INTO `sys_logininfor` VALUES (11167, 'test999', '192.168.2.171', '内网IP', 'Chrome 8', 'Windows 10', '0', '退出成功', '2020-05-26 06:42:16');
INSERT INTO `sys_logininfor` VALUES (11168, 'test999', '192.168.2.171', '内网IP', 'Chrome 8', 'Windows 10', '0', '退出成功', '2020-05-26 06:45:31');
INSERT INTO `sys_logininfor` VALUES (11169, 'pan123', '0:0:0:0:0:0:0:1', 'XX XX', 'Chrome 8', 'Windows 10', '1', '用户不存在/密码错误', '2020-05-26 06:48:27');
INSERT INTO `sys_logininfor` VALUES (11170, 'test3333', '0:0:0:0:0:0:0:1', 'XX XX', 'Chrome 8', 'Windows 10', '0', '退出成功', '2020-05-26 06:48:57');
INSERT INTO `sys_logininfor` VALUES (11171, 'test999', '192.168.2.171', '内网IP', 'Chrome 8', 'Windows 10', '1', '用户不存在/密码错误', '2020-05-26 07:04:18');
INSERT INTO `sys_logininfor` VALUES (11172, 'test999', '192.168.2.171', '内网IP', 'Chrome 8', 'Windows 10', '1', '用户不存在/密码错误', '2020-05-26 07:04:53');
INSERT INTO `sys_logininfor` VALUES (11173, 'test999', '192.168.2.171', '内网IP', 'Chrome 8', 'Windows 10', '1', '用户不存在/密码错误', '2020-05-26 07:04:55');
INSERT INTO `sys_logininfor` VALUES (11174, 'test999', '192.168.2.171', '内网IP', 'Chrome 8', 'Windows 10', '1', '用户不存在/密码错误', '2020-05-26 07:05:04');
INSERT INTO `sys_logininfor` VALUES (11175, 'test999', '192.168.2.171', '内网IP', 'Chrome 8', 'Windows 10', '1', '用户不存在/密码错误', '2020-05-26 07:05:12');
INSERT INTO `sys_logininfor` VALUES (11176, 'test999', '192.168.2.171', '内网IP', 'Chrome 8', 'Windows 10', '1', '用户不存在/密码错误', '2020-05-26 07:05:19');
INSERT INTO `sys_logininfor` VALUES (11177, 'test999', '192.168.2.171', '内网IP', 'Chrome 8', 'Windows 10', '1', '用户不存在/密码错误', '2020-05-26 07:05:23');
INSERT INTO `sys_logininfor` VALUES (11178, 'test123', '0:0:0:0:0:0:0:1', 'XX XX', 'Chrome', 'Windows 10', '1', '用户不存在/密码错误', '2020-05-26 07:10:37');
INSERT INTO `sys_logininfor` VALUES (11179, 'test123', '0:0:0:0:0:0:0:1', 'XX XX', 'Chrome', 'Windows 10', '0', '退出成功', '2020-05-26 07:10:41');
INSERT INTO `sys_logininfor` VALUES (11180, 'test990', '192.168.2.171', '内网IP', 'Chrome 8', 'Windows 10', '0', '退出成功', '2020-05-26 07:11:17');
INSERT INTO `sys_logininfor` VALUES (11181, 'test990', '192.168.2.171', '内网IP', 'Chrome 8', 'Windows 10', '0', '退出成功', '2020-05-26 07:15:45');
INSERT INTO `sys_logininfor` VALUES (11182, 'test990', '192.168.2.171', '内网IP', 'Chrome 8', 'Windows 10', '0', '退出成功', '2020-05-26 07:15:52');
INSERT INTO `sys_logininfor` VALUES (11183, 'test999', '192.168.2.171', '内网IP', 'Chrome 8', 'Windows 10', '0', '退出成功', '2020-05-26 07:16:08');
INSERT INTO `sys_logininfor` VALUES (11184, 'test999', '192.168.2.171', '内网IP', 'Chrome 8', 'Windows 10', '0', '退出成功', '2020-05-26 07:17:55');
INSERT INTO `sys_logininfor` VALUES (11185, 'test999', '192.168.2.171', '内网IP', 'Chrome 8', 'Windows 10', '0', '退出成功', '2020-05-26 07:18:36');
INSERT INTO `sys_logininfor` VALUES (11186, 'test999', '192.168.2.171', '内网IP', 'Chrome 8', 'Windows 10', '0', '退出成功', '2020-05-26 07:26:17');
INSERT INTO `sys_logininfor` VALUES (11187, 'test999', '192.168.2.171', '内网IP', 'Chrome 8', 'Windows 10', '0', '退出成功', '2020-05-26 07:26:39');
INSERT INTO `sys_logininfor` VALUES (11188, 'test999', '192.168.2.171', '内网IP', 'Chrome 8', 'Windows 10', '0', '退出成功', '2020-05-26 07:26:56');
INSERT INTO `sys_logininfor` VALUES (11189, 'test999', '192.168.2.171', '内网IP', 'Chrome 8', 'Windows 10', '0', '退出成功', '2020-05-26 07:27:18');
INSERT INTO `sys_logininfor` VALUES (11190, 'test999', '192.168.2.171', '内网IP', 'Chrome 8', 'Windows 10', '0', '退出成功', '2020-05-26 07:27:35');
INSERT INTO `sys_logininfor` VALUES (11191, 'test999', '192.168.2.171', '内网IP', 'Chrome 8', 'Windows 10', '0', '退出成功', '2020-05-26 07:28:44');
INSERT INTO `sys_logininfor` VALUES (11192, 'test999', '192.168.2.171', '内网IP', 'Chrome 8', 'Windows 10', '0', '退出成功', '2020-05-26 07:31:31');
INSERT INTO `sys_logininfor` VALUES (11193, 'test999', '192.168.2.171', '内网IP', 'Chrome 8', 'Windows 10', '0', '退出成功', '2020-05-26 07:41:25');
INSERT INTO `sys_logininfor` VALUES (11194, 'test999', '192.168.2.171', '内网IP', 'Chrome 8', 'Windows 10', '0', '退出成功', '2020-05-26 07:42:46');
INSERT INTO `sys_logininfor` VALUES (11195, 'test999', '192.168.2.171', '内网IP', 'Chrome 8', 'Windows 10', '0', '退出成功', '2020-05-26 07:45:29');
INSERT INTO `sys_logininfor` VALUES (11196, 'test999', '192.168.2.171', '内网IP', 'Chrome 8', 'Windows 10', '0', '退出成功', '2020-05-26 07:48:13');
INSERT INTO `sys_logininfor` VALUES (11197, 'test000', '192.168.2.171', '内网IP', 'Chrome 8', 'Windows 10', '0', '退出成功', '2020-05-26 07:52:14');
INSERT INTO `sys_logininfor` VALUES (11198, 'test01', '192.168.2.171', '内网IP', 'Chrome 8', 'Windows 10', '1', '用户不存在/密码错误', '2020-05-26 08:59:35');
INSERT INTO `sys_logininfor` VALUES (11199, 'test01', '192.168.2.171', '内网IP', 'Chrome 8', 'Windows 10', '1', '用户不存在/密码错误', '2020-05-26 08:59:35');
INSERT INTO `sys_logininfor` VALUES (11200, 'test01', '192.168.2.171', '内网IP', 'Chrome 8', 'Windows 10', '0', '退出成功', '2020-05-26 08:59:51');
INSERT INTO `sys_logininfor` VALUES (11201, 'test01', '192.168.2.171', '内网IP', 'Chrome 8', 'Windows 10', '0', '退出成功', '2020-05-26 11:33:37');
INSERT INTO `sys_logininfor` VALUES (11202, 'test01', '192.168.2.171', '内网IP', 'Chrome 8', 'Windows 10', '0', '退出成功', '2020-05-26 11:35:24');
INSERT INTO `sys_logininfor` VALUES (11203, 'test01', '192.168.2.171', '内网IP', 'Chrome 8', 'Windows 10', '0', '退出成功', '2020-05-26 11:36:09');
INSERT INTO `sys_logininfor` VALUES (11204, 'test01', '192.168.2.171', '内网IP', 'Chrome 8', 'Windows 10', '0', '退出成功', '2020-05-26 11:36:48');
INSERT INTO `sys_logininfor` VALUES (11205, 'test01', '192.168.2.171', '内网IP', 'Chrome 8', 'Windows 10', '0', '退出成功', '2020-05-26 11:37:07');
INSERT INTO `sys_logininfor` VALUES (11206, 'test01', '192.168.2.171', '内网IP', 'Chrome 8', 'Windows 10', '0', '退出成功', '2020-05-26 11:37:14');
INSERT INTO `sys_logininfor` VALUES (11207, 'test01', '192.168.2.171', '内网IP', 'Chrome 8', 'Windows 10', '0', '退出成功', '2020-05-26 11:37:22');
INSERT INTO `sys_logininfor` VALUES (11208, 'test01', '192.168.2.171', '内网IP', 'Chrome 8', 'Windows 10', '0', '退出成功', '2020-05-26 11:37:28');
INSERT INTO `sys_logininfor` VALUES (11209, 'test01', '192.168.2.171', '内网IP', 'Chrome 8', 'Windows 10', '0', '退出成功', '2020-05-26 11:40:25');
INSERT INTO `sys_logininfor` VALUES (11210, 'test01', '192.168.2.171', '内网IP', 'Chrome 8', 'Windows 10', '0', '退出成功', '2020-05-26 11:40:37');
INSERT INTO `sys_logininfor` VALUES (11211, 'test01', '192.168.2.171', '内网IP', 'Chrome 8', 'Windows 10', '0', '退出成功', '2020-05-26 11:43:21');
INSERT INTO `sys_logininfor` VALUES (11212, 'test01', '192.168.2.136', '内网IP', 'Chrome 8', 'Windows 10', '1', '用户不存在/密码错误', '2020-05-26 11:46:41');
INSERT INTO `sys_logininfor` VALUES (11213, 'test01', '192.168.2.171', '内网IP', 'Chrome 8', 'Windows 10', '0', '退出成功', '2020-05-26 11:51:30');
INSERT INTO `sys_logininfor` VALUES (11214, 'test01', '192.168.2.171', '内网IP', 'Chrome 8', 'Windows 10', '0', '退出成功', '2020-05-26 11:53:27');
INSERT INTO `sys_logininfor` VALUES (11215, 'test01', '192.168.2.171', '内网IP', 'Chrome 8', 'Windows 10', '0', '退出成功', '2020-05-26 11:58:30');
INSERT INTO `sys_logininfor` VALUES (11216, 'test01', '192.168.2.171', '内网IP', 'Chrome 8', 'Windows 10', '0', '退出成功', '2020-05-26 12:03:57');
INSERT INTO `sys_logininfor` VALUES (11217, 'test01', '192.168.2.171', '内网IP', 'Chrome 8', 'Windows 10', '0', '退出成功', '2020-05-26 12:06:44');
INSERT INTO `sys_logininfor` VALUES (11218, 'test01', '192.168.2.136', '内网IP', 'Chrome 8', 'Windows 10', '1', '用户不存在/密码错误', '2020-05-26 12:07:58');
INSERT INTO `sys_logininfor` VALUES (11219, 'test01', '192.168.2.171', '内网IP', 'Chrome 8', 'Windows 10', '0', '退出成功', '2020-05-26 12:08:05');
INSERT INTO `sys_logininfor` VALUES (11220, 'test01', '192.168.2.136', '内网IP', 'Chrome 8', 'Windows 10', '1', '用户不存在/密码错误', '2020-05-26 12:08:16');
INSERT INTO `sys_logininfor` VALUES (11221, 'test123', '192.168.2.136', '内网IP', 'Chrome 8', 'Windows 10', '1', '用户不存在/密码错误', '2020-05-26 12:08:26');
INSERT INTO `sys_logininfor` VALUES (11222, 'test123', '0:0:0:0:0:0:0:1', 'XX XX', 'Chrome 8', 'Windows 10', '1', '用户不存在/密码错误', '2020-05-26 12:10:28');
INSERT INTO `sys_logininfor` VALUES (11223, 'test1234', '0:0:0:0:0:0:0:1', 'XX XX', 'Chrome 8', 'Windows 10', '1', '用户不存在/密码错误', '2020-05-26 12:10:32');
INSERT INTO `sys_logininfor` VALUES (11224, 'test', '0:0:0:0:0:0:0:1', 'XX XX', 'Chrome 8', 'Windows 10', '1', '用户不存在/密码错误', '2020-05-26 12:10:35');
INSERT INTO `sys_logininfor` VALUES (11225, 'test123', '0:0:0:0:0:0:0:1', 'XX XX', 'Chrome 8', 'Windows 10', '1', '用户不存在/密码错误', '2020-05-26 12:10:39');
INSERT INTO `sys_logininfor` VALUES (11226, 'test1234', '0:0:0:0:0:0:0:1', 'XX XX', 'Chrome 8', 'Windows 10', '1', '用户不存在/密码错误', '2020-05-26 12:10:41');
INSERT INTO `sys_logininfor` VALUES (11227, 'test123', '0:0:0:0:0:0:0:1', 'XX XX', 'Chrome 8', 'Windows 10', '1', '用户不存在/密码错误', '2020-05-26 12:11:07');
INSERT INTO `sys_logininfor` VALUES (11228, 'test01', '192.168.2.136', '内网IP', 'Chrome 8', 'Windows 10', '1', '用户不存在/密码错误', '2020-05-26 12:13:40');
INSERT INTO `sys_logininfor` VALUES (11229, 'test123', '0:0:0:0:0:0:0:1', 'XX XX', 'Chrome 8', 'Windows 10', '0', '退出成功', '2020-05-26 12:24:04');
INSERT INTO `sys_logininfor` VALUES (11230, 'test01', '192.168.2.171', '内网IP', 'Chrome 8', 'Windows 10', '0', '退出成功', '2020-05-26 12:24:12');
INSERT INTO `sys_logininfor` VALUES (11231, 'test01', '192.168.2.136', '内网IP', 'Chrome 8', 'Windows 10', '0', '退出成功', '2020-05-26 12:24:23');
INSERT INTO `sys_logininfor` VALUES (11232, 'test01', '192.168.2.136', '内网IP', 'Chrome 8', 'Windows 10', '0', '退出成功', '2020-05-26 12:25:49');
INSERT INTO `sys_logininfor` VALUES (11233, 'test01', '192.168.2.136', '内网IP', 'Chrome 8', 'Windows 10', '0', '退出成功', '2020-05-26 12:26:24');
INSERT INTO `sys_logininfor` VALUES (11234, 'test01', '192.168.2.171', '内网IP', 'Chrome 8', 'Windows 10', '0', '退出成功', '2020-05-26 12:30:47');
INSERT INTO `sys_logininfor` VALUES (11235, 'test01', '192.168.2.136', '内网IP', 'Chrome 8', 'Windows 10', '0', '退出成功', '2020-05-26 12:37:42');
INSERT INTO `sys_logininfor` VALUES (11236, 'test01', '192.168.2.171', '内网IP', 'Chrome 8', 'Windows 10', '0', '退出成功', '2020-05-26 13:08:47');
INSERT INTO `sys_logininfor` VALUES (11237, 'test01', '192.168.2.171', '内网IP', 'Chrome 8', 'Windows 10', '0', '退出成功', '2020-05-26 13:10:53');
INSERT INTO `sys_logininfor` VALUES (11238, 'test01', '192.168.2.171', '内网IP', 'Chrome 8', 'Windows 10', '0', '退出成功', '2020-05-26 13:12:26');
INSERT INTO `sys_logininfor` VALUES (11239, '13711111111', '192.168.2.171', '内网IP', 'Chrome 8', 'Windows 10', '0', '退出成功', '2020-05-26 13:13:23');
INSERT INTO `sys_logininfor` VALUES (11240, '13711111111', '192.168.2.171', '内网IP', 'Chrome 8', 'Windows 10', '0', '退出成功', '2020-05-26 13:20:19');
INSERT INTO `sys_logininfor` VALUES (11241, '13711111111', '192.168.2.171', '内网IP', 'Chrome 8', 'Windows 10', '0', '退出成功', '2020-05-26 13:20:44');
INSERT INTO `sys_logininfor` VALUES (11242, '13711111111', '192.168.2.171', '内网IP', 'Chrome 8', 'Windows 10', '0', '退出成功', '2020-05-26 13:23:02');
INSERT INTO `sys_logininfor` VALUES (11243, '13711111111', '192.168.2.171', '内网IP', 'Chrome 8', 'Windows 10', '0', '退出成功', '2020-05-26 13:24:14');
INSERT INTO `sys_logininfor` VALUES (11244, '13711111111', '192.168.2.171', '内网IP', 'Chrome 8', 'Windows 10', '0', '退出成功', '2020-05-26 13:27:48');
INSERT INTO `sys_logininfor` VALUES (11245, 'test01', '192.168.2.136', '内网IP', 'Chrome 8', 'Windows 10', '0', '退出成功', '2020-05-26 13:46:58');
INSERT INTO `sys_logininfor` VALUES (11246, 'test01', '192.168.2.136', '内网IP', 'Chrome 8', 'Windows 10', '0', '退出成功', '2020-05-26 13:47:36');
INSERT INTO `sys_logininfor` VALUES (11247, 'test01', '192.168.2.136', '内网IP', 'Chrome 8', 'Windows 10', '0', '退出成功', '2020-05-26 13:50:20');
INSERT INTO `sys_logininfor` VALUES (11248, 'test123', '0:0:0:0:0:0:0:1', 'XX XX', 'Chrome 8', 'Windows 10', '0', '退出成功', '2020-05-27 01:57:09');
INSERT INTO `sys_logininfor` VALUES (11249, 'test123', '0:0:0:0:0:0:0:1', 'XX XX', 'Chrome 8', 'Windows 10', '0', '退出成功', '2020-05-27 02:22:52');
INSERT INTO `sys_logininfor` VALUES (11250, 'test01', '192.168.2.136', '内网IP', 'Chrome 8', 'Windows 10', '0', '退出成功', '2020-05-27 03:12:03');
INSERT INTO `sys_logininfor` VALUES (11251, 'test01', '192.168.2.136', '内网IP', 'Chrome 8', 'Windows 10', '0', '退出成功', '2020-05-27 03:41:01');
INSERT INTO `sys_logininfor` VALUES (11252, 'test01', '192.168.2.136', '内网IP', 'Chrome 8', 'Windows 10', '0', '退出成功', '2020-05-27 03:49:52');
INSERT INTO `sys_logininfor` VALUES (11253, 'test01', '192.168.2.136', '内网IP', 'Chrome 8', 'Windows 10', '0', '退出成功', '2020-05-27 03:51:20');
INSERT INTO `sys_logininfor` VALUES (11254, 'test123', '0:0:0:0:0:0:0:1', 'XX XX', 'Chrome', 'Windows 10', '0', '退出成功', '2020-05-27 03:56:01');
INSERT INTO `sys_logininfor` VALUES (11255, 'test123', '0:0:0:0:0:0:0:1', 'XX XX', 'Chrome', 'Windows 10', '0', '退出成功', '2020-05-27 03:59:13');
INSERT INTO `sys_logininfor` VALUES (11256, 'test01', '192.168.2.136', '内网IP', 'Chrome 8', 'Windows 10', '0', '退出成功', '2020-05-27 04:02:02');
INSERT INTO `sys_logininfor` VALUES (11257, 'test01', '192.168.2.136', '内网IP', 'Chrome 8', 'Windows 10', '0', '退出成功', '2020-05-27 04:03:37');
INSERT INTO `sys_logininfor` VALUES (11258, 'test123', '0:0:0:0:0:0:0:1', 'XX XX', 'Chrome', 'Windows 10', '0', '退出成功', '2020-05-27 05:51:32');
INSERT INTO `sys_logininfor` VALUES (11259, 'test01', '192.168.2.136', '内网IP', 'Chrome 8', 'Windows 10', '0', '退出成功', '2020-05-27 06:16:48');
INSERT INTO `sys_logininfor` VALUES (11260, 'test01', '192.168.2.136', '内网IP', 'Chrome 8', 'Windows 10', '0', '退出成功', '2020-05-27 06:17:30');
INSERT INTO `sys_logininfor` VALUES (11261, 'test01', '192.168.2.136', '内网IP', 'Chrome 8', 'Windows 10', '0', '退出成功', '2020-05-27 06:22:16');
INSERT INTO `sys_logininfor` VALUES (11262, 'test123', '0:0:0:0:0:0:0:1', 'XX XX', 'Chrome 8', 'Windows 10', '0', '退出成功', '2020-05-27 06:24:16');
INSERT INTO `sys_logininfor` VALUES (11263, 'test123', '0:0:0:0:0:0:0:1', 'XX XX', 'Chrome 8', 'Windows 10', '0', '退出成功', '2020-05-27 06:27:27');
INSERT INTO `sys_logininfor` VALUES (11264, '13711111111', '192.168.2.171', '内网IP', 'Chrome 8', 'Windows 10', '0', '退出成功', '2020-05-27 06:59:57');
INSERT INTO `sys_logininfor` VALUES (11265, 'test01', '192.168.2.136', '内网IP', 'Chrome 8', 'Windows 10', '0', '退出成功', '2020-05-27 07:00:05');
INSERT INTO `sys_logininfor` VALUES (11266, '13711111111', '192.168.2.171', '内网IP', 'Chrome 8', 'Windows 10', '0', '退出成功', '2020-05-27 07:02:28');
INSERT INTO `sys_logininfor` VALUES (11267, '13711111111', '192.168.2.171', '内网IP', 'Chrome 8', 'Windows 10', '0', '退出成功', '2020-05-27 07:07:15');
INSERT INTO `sys_logininfor` VALUES (11268, '13711111111', '192.168.2.171', '内网IP', 'Chrome 8', 'Windows 10', '0', '退出成功', '2020-05-27 07:07:49');
INSERT INTO `sys_logininfor` VALUES (11269, '13711111111', '192.168.2.171', '内网IP', 'Chrome 8', 'Windows 10', '0', '退出成功', '2020-05-27 07:09:34');
INSERT INTO `sys_logininfor` VALUES (11270, '13711111111', '192.168.2.171', '内网IP', 'Chrome 8', 'Windows 10', '0', '退出成功', '2020-05-27 07:16:57');
INSERT INTO `sys_logininfor` VALUES (11271, '13711111111', '192.168.2.171', '内网IP', 'Chrome 8', 'Windows 10', '0', '退出成功', '2020-05-27 07:17:23');
INSERT INTO `sys_logininfor` VALUES (11272, '13711111111', '192.168.2.171', '内网IP', 'Chrome 8', 'Windows 10', '0', '退出成功', '2020-05-27 07:18:52');
INSERT INTO `sys_logininfor` VALUES (11273, '13711111111', '192.168.2.171', '内网IP', 'Chrome 8', 'Windows 10', '0', '退出成功', '2020-05-27 07:24:14');
INSERT INTO `sys_logininfor` VALUES (11274, '13711111111', '192.168.2.171', '内网IP', 'Chrome 8', 'Windows 10', '0', '退出成功', '2020-05-27 07:25:41');
INSERT INTO `sys_logininfor` VALUES (11275, 'test123', '0:0:0:0:0:0:0:1', 'XX XX', 'Chrome 8', 'Windows 10', '0', '退出成功', '2020-05-27 07:33:03');
INSERT INTO `sys_logininfor` VALUES (11276, '13711111111', '192.168.2.171', '内网IP', 'Chrome 8', 'Windows 10', '0', '退出成功', '2020-05-27 07:34:54');
INSERT INTO `sys_logininfor` VALUES (11277, 'test123', '0:0:0:0:0:0:0:1', 'XX XX', 'Chrome 8', 'Windows 10', '0', '退出成功', '2020-05-27 07:36:28');
INSERT INTO `sys_logininfor` VALUES (11278, 'test9999', '192.168.2.191', '内网IP', 'Chrome', 'Windows 10', '0', '退出成功', '2020-05-27 07:40:11');
INSERT INTO `sys_logininfor` VALUES (11279, '13711111111', '192.168.2.171', '内网IP', 'Chrome 8', 'Windows 10', '0', '退出成功', '2020-05-27 07:41:26');
INSERT INTO `sys_logininfor` VALUES (11280, 'test9999', '192.168.2.191', '内网IP', 'Chrome', 'Windows 10', '0', '退出成功', '2020-05-27 07:42:09');
INSERT INTO `sys_logininfor` VALUES (11281, '13711111111', '192.168.2.171', '内网IP', 'Chrome 8', 'Windows 10', '0', '退出成功', '2020-05-27 07:42:09');
INSERT INTO `sys_logininfor` VALUES (11282, '13711111111', '192.168.2.171', '内网IP', 'Chrome 8', 'Windows 10', '0', '退出成功', '2020-05-27 07:43:00');
INSERT INTO `sys_logininfor` VALUES (11283, 'test123', '0:0:0:0:0:0:0:1', 'XX XX', 'Chrome 8', 'Windows 10', '0', '退出成功', '2020-05-27 07:48:44');
INSERT INTO `sys_logininfor` VALUES (11284, '13711111111', '192.168.2.171', '内网IP', 'Chrome 8', 'Windows 10', '0', '退出成功', '2020-05-27 07:52:41');
INSERT INTO `sys_logininfor` VALUES (11285, 'test123', '0:0:0:0:0:0:0:1', 'XX XX', 'Chrome 8', 'Windows 10', '0', '退出成功', '2020-05-27 07:56:11');
INSERT INTO `sys_logininfor` VALUES (11286, 'test123', '0:0:0:0:0:0:0:1', 'XX XX', 'Chrome 8', 'Windows 10', '0', '退出成功', '2020-05-27 07:56:15');
INSERT INTO `sys_logininfor` VALUES (11287, 'test123', '0:0:0:0:0:0:0:1', 'XX XX', 'Chrome 8', 'Windows 10', '0', '退出成功', '2020-05-27 08:04:06');
INSERT INTO `sys_logininfor` VALUES (11288, 'test01', '192.168.2.136', '内网IP', 'Chrome 8', 'Windows 10', '0', '退出成功', '2020-05-27 08:04:38');
INSERT INTO `sys_logininfor` VALUES (11289, 'test123', '0:0:0:0:0:0:0:1', 'XX XX', 'Chrome 8', 'Windows 10', '0', '退出成功', '2020-05-27 08:06:43');
INSERT INTO `sys_logininfor` VALUES (11290, 'test123', '0:0:0:0:0:0:0:1', 'XX XX', 'Chrome 8', 'Windows 10', '0', '退出成功', '2020-05-27 08:07:47');
INSERT INTO `sys_logininfor` VALUES (11291, '13711111111', '192.168.2.171', '内网IP', 'Chrome 8', 'Windows 10', '0', '退出成功', '2020-05-27 08:12:36');
INSERT INTO `sys_logininfor` VALUES (11292, 'test123', '0:0:0:0:0:0:0:1', 'XX XX', 'Chrome 8', 'Windows 10', '0', '退出成功', '2020-05-27 08:13:05');
INSERT INTO `sys_logininfor` VALUES (11293, '13711111111', '192.168.2.171', '内网IP', 'Chrome 8', 'Windows 10', '0', '退出成功', '2020-05-27 08:13:06');
INSERT INTO `sys_logininfor` VALUES (11294, '13711111111', '192.168.2.171', '内网IP', 'Chrome 8', 'Windows 10', '0', '退出成功', '2020-05-27 08:17:41');
INSERT INTO `sys_logininfor` VALUES (11295, '13711111111', '192.168.2.171', '内网IP', 'Chrome 8', 'Windows 10', '0', '退出成功', '2020-05-27 08:18:15');
INSERT INTO `sys_logininfor` VALUES (11296, 'test01', '192.168.2.136', '内网IP', 'Chrome 8', 'Windows 10', '0', '退出成功', '2020-05-27 08:18:48');
INSERT INTO `sys_logininfor` VALUES (11297, '13711111111', '192.168.2.171', '内网IP', 'Chrome 8', 'Windows 10', '0', '退出成功', '2020-05-27 08:19:38');
INSERT INTO `sys_logininfor` VALUES (11298, 'test01', '192.168.2.136', '内网IP', 'Chrome 8', 'Windows 10', '0', '退出成功', '2020-05-27 08:21:38');
INSERT INTO `sys_logininfor` VALUES (11299, '13711111111', '192.168.2.171', '内网IP', 'Chrome 8', 'Windows 10', '0', '退出成功', '2020-05-27 08:27:01');
INSERT INTO `sys_logininfor` VALUES (11300, '13711111111', '192.168.2.171', '内网IP', 'Chrome 8', 'Windows 10', '0', '退出成功', '2020-05-27 08:27:35');
INSERT INTO `sys_logininfor` VALUES (11301, '13711111111', '192.168.2.171', '内网IP', 'Chrome 8', 'Windows 10', '0', '退出成功', '2020-05-27 08:28:35');
INSERT INTO `sys_logininfor` VALUES (11302, '', '127.0.0.1', '内网IP', 'Chrome', 'Windows 10', '1', '* 必须填写', '2020-05-27 08:29:38');
INSERT INTO `sys_logininfor` VALUES (11303, '', '127.0.0.1', '内网IP', 'Chrome', 'Windows 10', '1', '* 必须填写', '2020-05-27 08:29:40');
INSERT INTO `sys_logininfor` VALUES (11304, '13711111111', '192.168.2.171', '内网IP', 'Chrome 8', 'Windows 10', '0', '退出成功', '2020-05-27 08:29:45');
INSERT INTO `sys_logininfor` VALUES (11305, 'test02', '127.0.0.1', '内网IP', 'Chrome', 'Windows 10', '0', '退出成功', '2020-05-27 08:30:00');
INSERT INTO `sys_logininfor` VALUES (11306, '13711111111', '192.168.2.171', '内网IP', 'Chrome 8', 'Windows 10', '1', '用户不存在/密码错误', '2020-05-27 08:37:41');
INSERT INTO `sys_logininfor` VALUES (11307, 'test999', '192.168.2.171', '内网IP', 'Chrome 8', 'Windows 10', '0', '退出成功', '2020-05-27 08:38:54');
INSERT INTO `sys_logininfor` VALUES (11308, 'test999', '192.168.2.171', '内网IP', 'Chrome 8', 'Windows 10', '0', '退出成功', '2020-05-27 08:39:55');
INSERT INTO `sys_logininfor` VALUES (11309, 'test999', '192.168.2.171', '内网IP', 'Chrome 8', 'Windows 10', '0', '退出成功', '2020-05-27 08:40:24');
INSERT INTO `sys_logininfor` VALUES (11310, 'test01', '192.168.2.136', '内网IP', 'Chrome 8', 'Windows 10', '0', '退出成功', '2020-05-27 08:41:43');
INSERT INTO `sys_logininfor` VALUES (11311, 'test999', '192.168.2.171', '内网IP', 'Chrome 8', 'Windows 10', '0', '退出成功', '2020-05-27 08:42:04');
INSERT INTO `sys_logininfor` VALUES (11312, 'test999', '192.168.2.171', '内网IP', 'Chrome 8', 'Windows 10', '0', '退出成功', '2020-05-27 08:42:26');
INSERT INTO `sys_logininfor` VALUES (11313, 'test999', '192.168.2.171', '内网IP', 'Chrome 8', 'Windows 10', '0', '退出成功', '2020-05-27 08:42:58');
INSERT INTO `sys_logininfor` VALUES (11314, 'test01', '192.168.2.136', '内网IP', 'Chrome 8', 'Windows 10', '0', '退出成功', '2020-05-27 08:43:11');
INSERT INTO `sys_logininfor` VALUES (11315, 'test01', '192.168.2.136', '内网IP', 'Chrome 8', 'Windows 10', '0', '退出成功', '2020-05-27 08:43:55');
INSERT INTO `sys_logininfor` VALUES (11316, 'test01', '192.168.2.136', '内网IP', 'Chrome 8', 'Windows 10', '0', '退出成功', '2020-05-27 08:44:10');
INSERT INTO `sys_logininfor` VALUES (11317, 'test02', '127.0.0.1', '内网IP', 'Chrome', 'Windows 10', '0', '退出成功', '2020-05-27 08:48:28');
INSERT INTO `sys_logininfor` VALUES (11318, 'test01', '192.168.2.136', '内网IP', 'Chrome 8', 'Windows 10', '0', '退出成功', '2020-05-27 08:53:48');
INSERT INTO `sys_logininfor` VALUES (11319, 'test02', '127.0.0.1', '内网IP', 'Chrome', 'Windows 10', '0', '退出成功', '2020-05-27 08:59:00');
INSERT INTO `sys_logininfor` VALUES (11320, 'test02', '127.0.0.1', '内网IP', 'Chrome', 'Windows 10', '0', '退出成功', '2020-05-27 09:00:39');
INSERT INTO `sys_logininfor` VALUES (11321, 'test02', '127.0.0.1', '内网IP', 'Chrome', 'Windows 10', '0', '退出成功', '2020-05-27 09:45:53');
INSERT INTO `sys_logininfor` VALUES (11322, 'test02', '127.0.0.1', '内网IP', 'Chrome', 'Windows 10', '0', '退出成功', '2020-05-27 09:45:55');
INSERT INTO `sys_logininfor` VALUES (11323, 'test02', '127.0.0.1', '内网IP', 'Chrome', 'Windows 10', '0', '退出成功', '2020-05-27 09:45:56');
INSERT INTO `sys_logininfor` VALUES (11324, 'test02', '127.0.0.1', '内网IP', 'Chrome', 'Windows 10', '0', '退出成功', '2020-05-27 09:46:44');
INSERT INTO `sys_logininfor` VALUES (11325, 'test02', '127.0.0.1', '内网IP', 'Chrome', 'Windows 10', '0', '退出成功', '2020-05-27 09:49:53');
INSERT INTO `sys_logininfor` VALUES (11326, 'test02', '127.0.0.1', '内网IP', 'Chrome', 'Windows 10', '0', '退出成功', '2020-05-27 09:54:47');
INSERT INTO `sys_logininfor` VALUES (11327, 'test9999', '127.0.0.1', '内网IP', 'Chrome', 'Windows 10', '0', '退出成功', '2020-05-27 10:14:42');
INSERT INTO `sys_logininfor` VALUES (11328, 'test02', '127.0.0.1', '内网IP', 'Chrome', 'Windows 10', '0', '退出成功', '2020-05-27 10:15:55');
INSERT INTO `sys_logininfor` VALUES (11329, 'test9999', '0:0:0:0:0:0:0:1', 'XX XX', 'Chrome 8', 'Windows 10', '0', '退出成功', '2020-05-27 10:17:43');
INSERT INTO `sys_logininfor` VALUES (11330, 'test02', '127.0.0.1', '内网IP', 'Chrome', 'Windows 10', '0', '退出成功', '2020-05-27 10:19:03');
INSERT INTO `sys_logininfor` VALUES (11331, 'test02', '127.0.0.1', '内网IP', 'Chrome', 'Windows 10', '0', '退出成功', '2020-05-27 10:21:05');
INSERT INTO `sys_logininfor` VALUES (11332, 'test02', '127.0.0.1', '内网IP', 'Chrome', 'Windows 10', '0', '退出成功', '2020-05-27 10:21:36');
INSERT INTO `sys_logininfor` VALUES (11333, 'test02', '127.0.0.1', '内网IP', 'Chrome', 'Windows 10', '0', '退出成功', '2020-05-27 10:23:07');
INSERT INTO `sys_logininfor` VALUES (11334, 'test02', '127.0.0.1', '内网IP', 'Chrome', 'Windows 10', '0', '退出成功', '2020-05-27 10:23:35');
INSERT INTO `sys_logininfor` VALUES (11335, 'test9999', '0:0:0:0:0:0:0:1', 'XX XX', 'Chrome 8', 'Windows 10', '0', '退出成功', '2020-05-27 10:29:28');
INSERT INTO `sys_logininfor` VALUES (11336, 'test9999', '0:0:0:0:0:0:0:1', 'XX XX', 'Chrome 8', 'Windows 10', '0', '退出成功', '2020-05-27 10:35:48');
INSERT INTO `sys_logininfor` VALUES (11337, 'test9999', '0:0:0:0:0:0:0:1', 'XX XX', 'Chrome 8', 'Windows 10', '0', '退出成功', '2020-05-27 10:36:11');
INSERT INTO `sys_logininfor` VALUES (11338, 'test9999', '0:0:0:0:0:0:0:1', 'XX XX', 'Chrome 8', 'Windows 10', '0', '退出成功', '2020-05-27 10:37:47');
INSERT INTO `sys_logininfor` VALUES (11339, 'test9999', '0:0:0:0:0:0:0:1', 'XX XX', 'Chrome 8', 'Windows 10', '0', '退出成功', '2020-05-27 10:40:24');
INSERT INTO `sys_logininfor` VALUES (11340, 'test02', '127.0.0.1', '内网IP', 'Chrome', 'Windows 10', '0', '退出成功', '2020-05-27 10:42:22');
INSERT INTO `sys_logininfor` VALUES (11341, 'test999', '192.168.2.171', '内网IP', 'Chrome 8', 'Windows 10', '0', '退出成功', '2020-05-27 10:49:59');
INSERT INTO `sys_logininfor` VALUES (11342, 'test999', '192.168.2.171', '内网IP', 'Chrome 8', 'Windows 10', '0', '退出成功', '2020-05-27 10:50:07');
INSERT INTO `sys_logininfor` VALUES (11343, 'test999', '192.168.2.171', '内网IP', 'Chrome 8', 'Windows 10', '0', '退出成功', '2020-05-27 10:50:25');
INSERT INTO `sys_logininfor` VALUES (11344, 'test999', '192.168.2.171', '内网IP', 'Chrome 8', 'Windows 10', '0', '退出成功', '2020-05-27 10:50:48');
INSERT INTO `sys_logininfor` VALUES (11345, 'test999', '192.168.2.171', '内网IP', 'Chrome 8', 'Windows 10', '0', '退出成功', '2020-05-27 10:52:20');
INSERT INTO `sys_logininfor` VALUES (11346, 'test999', '192.168.2.171', '内网IP', 'Chrome 8', 'Windows 10', '0', '退出成功', '2020-05-27 10:52:59');
INSERT INTO `sys_logininfor` VALUES (11347, 'test999', '192.168.2.171', '内网IP', 'Chrome 8', 'Windows 10', '0', '退出成功', '2020-05-27 10:53:04');
INSERT INTO `sys_logininfor` VALUES (11348, 'test999', '192.168.2.171', '内网IP', 'Chrome 8', 'Windows 10', '0', '退出成功', '2020-05-27 10:53:10');
INSERT INTO `sys_logininfor` VALUES (11349, 'test123', '0:0:0:0:0:0:0:1', 'XX XX', 'Chrome', 'Windows 10', '0', '退出成功', '2020-05-27 10:53:40');
INSERT INTO `sys_logininfor` VALUES (11350, 'test999', '192.168.2.171', '内网IP', 'Chrome 8', 'Windows 10', '0', '退出成功', '2020-05-27 10:54:26');
INSERT INTO `sys_logininfor` VALUES (11351, 'test999', '192.168.2.171', '内网IP', 'Chrome 8', 'Windows 10', '0', '退出成功', '2020-05-27 10:54:41');
INSERT INTO `sys_logininfor` VALUES (11352, 'test123', '0:0:0:0:0:0:0:1', 'XX XX', 'Chrome', 'Windows 10', '0', '退出成功', '2020-05-27 10:56:11');
INSERT INTO `sys_logininfor` VALUES (11353, 'test123', '0:0:0:0:0:0:0:1', 'XX XX', 'Chrome', 'Windows 10', '0', '退出成功', '2020-05-27 11:01:21');
INSERT INTO `sys_logininfor` VALUES (11354, 'test999', '192.168.2.171', '内网IP', 'Chrome 8', 'Windows 10', '0', '退出成功', '2020-05-27 11:02:33');
INSERT INTO `sys_logininfor` VALUES (11355, 'test999', '192.168.2.171', '内网IP', 'Chrome 8', 'Windows 10', '0', '退出成功', '2020-05-27 11:02:37');
INSERT INTO `sys_logininfor` VALUES (11356, 'test01', '192.168.2.136', '内网IP', 'Chrome 8', 'Windows 10', '0', '退出成功', '2020-05-27 11:03:21');
INSERT INTO `sys_logininfor` VALUES (11357, 'test01', '192.168.2.136', '内网IP', 'Chrome 8', 'Windows 10', '0', '退出成功', '2020-05-27 11:03:23');
INSERT INTO `sys_logininfor` VALUES (11358, 'test01', '192.168.2.136', '内网IP', 'Chrome 8', 'Windows 10', '0', '退出成功', '2020-05-27 11:08:44');
INSERT INTO `sys_logininfor` VALUES (11359, 'test123', '0:0:0:0:0:0:0:1', 'XX XX', 'Chrome', 'Windows 10', '0', '退出成功', '2020-05-27 11:09:57');
INSERT INTO `sys_logininfor` VALUES (11360, 'test999', '192.168.2.171', '内网IP', 'Chrome 8', 'Windows 10', '0', '退出成功', '2020-05-27 11:10:13');
INSERT INTO `sys_logininfor` VALUES (11361, 'test999', '192.168.2.171', '内网IP', 'Chrome 8', 'Windows 10', '0', '退出成功', '2020-05-27 11:10:23');
INSERT INTO `sys_logininfor` VALUES (11362, 'test01', '192.168.2.136', '内网IP', 'Chrome 8', 'Windows 10', '0', '退出成功', '2020-05-27 11:28:33');
INSERT INTO `sys_logininfor` VALUES (11363, 'test01', '192.168.2.136', '内网IP', 'Chrome 8', 'Windows 10', '0', '退出成功', '2020-05-27 11:31:08');
INSERT INTO `sys_logininfor` VALUES (11364, 'test01', '192.168.2.136', '内网IP', 'Chrome 8', 'Windows 10', '0', '退出成功', '2020-05-27 11:33:56');
INSERT INTO `sys_logininfor` VALUES (11365, 'test01', '192.168.2.136', '内网IP', 'Chrome 8', 'Windows 10', '0', '退出成功', '2020-05-27 12:14:29');
INSERT INTO `sys_logininfor` VALUES (11366, 'test01', '192.168.2.136', '内网IP', 'Chrome 8', 'Windows 10', '0', '退出成功', '2020-05-27 12:36:39');
INSERT INTO `sys_logininfor` VALUES (11367, 'test01', '192.168.2.136', '内网IP', 'Chrome 8', 'Windows 10', '0', '退出成功', '2020-05-27 12:50:43');
INSERT INTO `sys_logininfor` VALUES (11368, 'test01', '127.0.0.1', '内网IP', 'Chrome', 'Windows 10', '0', '退出成功', '2020-05-27 13:40:11');
INSERT INTO `sys_logininfor` VALUES (11369, 'test01', '192.168.2.136', '内网IP', 'Chrome 8', 'Windows 10', '0', '退出成功', '2020-05-27 13:42:54');
INSERT INTO `sys_logininfor` VALUES (11370, 'test01', '192.168.2.136', '内网IP', 'Chrome 8', 'Windows 10', '0', '退出成功', '2020-05-27 13:52:57');
INSERT INTO `sys_logininfor` VALUES (11371, 'test01', '192.168.2.136', '内网IP', 'Chrome 8', 'Windows 10', '0', '退出成功', '2020-05-27 13:53:11');
INSERT INTO `sys_logininfor` VALUES (11372, 'test01', '127.0.0.1', '内网IP', 'Chrome', 'Windows 10', '0', '退出成功', '2020-05-27 14:01:37');
INSERT INTO `sys_logininfor` VALUES (11373, 'test01', '192.168.2.136', '内网IP', 'Chrome 8', 'Windows 10', '0', '退出成功', '2020-05-27 14:01:59');
INSERT INTO `sys_logininfor` VALUES (11374, '18520117015', '127.0.0.1', '内网IP', 'Chrome', 'Windows 10', '0', '退出成功', '2020-05-27 14:04:13');
INSERT INTO `sys_logininfor` VALUES (11375, 'test01', '192.168.2.136', '内网IP', 'Chrome 8', 'Windows 10', '0', '退出成功', '2020-05-28 01:54:54');
INSERT INTO `sys_logininfor` VALUES (11376, 'test9999', '0:0:0:0:0:0:0:1', 'XX XX', 'Chrome 8', 'Windows 10', '0', '退出成功', '2020-05-28 01:56:03');
INSERT INTO `sys_logininfor` VALUES (11377, 'test01', '192.168.2.136', '内网IP', 'Chrome 8', 'Windows 10', '0', '退出成功', '2020-05-28 01:59:31');
INSERT INTO `sys_logininfor` VALUES (11378, 'test01', '192.168.2.136', '内网IP', 'Chrome 8', 'Windows 10', '0', '退出成功', '2020-05-28 02:05:23');
INSERT INTO `sys_logininfor` VALUES (11379, 'test999', '192.168.2.171', '内网IP', 'Chrome 8', 'Windows 10', '0', '退出成功', '2020-05-28 02:08:49');
INSERT INTO `sys_logininfor` VALUES (11380, 'test01', '192.168.2.136', '内网IP', 'Chrome 8', 'Windows 10', '0', '退出成功', '2020-05-28 02:09:09');
INSERT INTO `sys_logininfor` VALUES (11381, 'test999', '192.168.2.171', '内网IP', 'Chrome 8', 'Windows 10', '0', '退出成功', '2020-05-28 02:11:17');
INSERT INTO `sys_logininfor` VALUES (11382, 'test999', '192.168.2.171', '内网IP', 'Chrome 8', 'Windows 10', '0', '退出成功', '2020-05-28 02:13:12');
INSERT INTO `sys_logininfor` VALUES (11383, 'test999', '192.168.2.171', '内网IP', 'Chrome 8', 'Windows 10', '0', '退出成功', '2020-05-28 02:14:39');
INSERT INTO `sys_logininfor` VALUES (11384, 'test999', '192.168.2.171', '内网IP', 'Chrome 8', 'Windows 10', '0', '退出成功', '2020-05-28 02:14:58');
INSERT INTO `sys_logininfor` VALUES (11385, 'test999', '192.168.2.171', '内网IP', 'Chrome 8', 'Windows 10', '0', '退出成功', '2020-05-28 02:16:24');
INSERT INTO `sys_logininfor` VALUES (11386, 'test999', '192.168.2.171', '内网IP', 'Chrome 8', 'Windows 10', '0', '退出成功', '2020-05-28 02:18:07');
INSERT INTO `sys_logininfor` VALUES (11387, 'test01', '192.168.2.136', '内网IP', 'Chrome 8', 'Windows 10', '0', '退出成功', '2020-05-28 02:46:38');
INSERT INTO `sys_logininfor` VALUES (11388, 'test01', '192.168.2.136', '内网IP', 'Chrome 8', 'Windows 10', '0', '退出成功', '2020-05-28 02:52:59');
INSERT INTO `sys_logininfor` VALUES (11389, 'test01', '192.168.2.136', '内网IP', 'Chrome 8', 'Windows 10', '0', '退出成功', '2020-05-28 03:06:32');
INSERT INTO `sys_logininfor` VALUES (11390, 'test01', '192.168.2.136', '内网IP', 'Chrome 8', 'Windows 10', '0', '退出成功', '2020-05-28 03:08:42');
INSERT INTO `sys_logininfor` VALUES (11391, 'test999', '192.168.2.171', '内网IP', 'Chrome 8', 'Windows 10', '0', '退出成功', '2020-05-28 06:00:43');
INSERT INTO `sys_logininfor` VALUES (11392, 'test999', '192.168.2.171', '内网IP', 'Chrome 8', 'Windows 10', '0', '退出成功', '2020-05-28 06:01:04');
INSERT INTO `sys_logininfor` VALUES (11393, 'test123', '0:0:0:0:0:0:0:1', 'XX XX', 'Chrome', 'Windows 10', '0', '退出成功', '2020-05-28 06:04:56');
INSERT INTO `sys_logininfor` VALUES (11394, 'test999', '192.168.2.171', '内网IP', 'Chrome 8', 'Windows 10', '0', '退出成功', '2020-05-28 06:06:11');
INSERT INTO `sys_logininfor` VALUES (11395, 'test999', '192.168.2.171', '内网IP', 'Chrome 8', 'Windows 10', '0', '退出成功', '2020-05-28 06:10:30');
INSERT INTO `sys_logininfor` VALUES (11396, 'test999', '192.168.2.171', '内网IP', 'Chrome 8', 'Windows 10', '0', '退出成功', '2020-05-28 06:12:25');
INSERT INTO `sys_logininfor` VALUES (11397, 'test999', '192.168.2.171', '内网IP', 'Chrome 8', 'Windows 10', '0', '退出成功', '2020-05-28 06:16:48');
INSERT INTO `sys_logininfor` VALUES (11398, 'test999', '192.168.2.171', '内网IP', 'Chrome 8', 'Windows 10', '0', '退出成功', '2020-05-28 06:19:22');
INSERT INTO `sys_logininfor` VALUES (11399, 'test999', '192.168.2.171', '内网IP', 'Chrome 8', 'Windows 10', '0', '退出成功', '2020-05-28 06:20:45');
INSERT INTO `sys_logininfor` VALUES (11400, 'test999', '192.168.2.171', '内网IP', 'Chrome 8', 'Windows 10', '0', '退出成功', '2020-05-28 06:24:31');
INSERT INTO `sys_logininfor` VALUES (11401, 'test999', '192.168.2.171', '内网IP', 'Chrome 8', 'Windows 10', '0', '退出成功', '2020-05-28 06:25:27');
INSERT INTO `sys_logininfor` VALUES (11402, 'test999', '192.168.2.171', '内网IP', 'Chrome 8', 'Windows 10', '0', '退出成功', '2020-05-28 06:28:48');
INSERT INTO `sys_logininfor` VALUES (11403, 'test01', '192.168.2.136', '内网IP', 'Chrome 8', 'Windows 10', '0', '退出成功', '2020-05-28 06:29:11');
INSERT INTO `sys_logininfor` VALUES (11404, 'test999', '192.168.2.171', '内网IP', 'Chrome 8', 'Windows 10', '0', '退出成功', '2020-05-28 06:29:17');
INSERT INTO `sys_logininfor` VALUES (11405, 'test999', '192.168.2.171', '内网IP', 'Chrome 8', 'Windows 10', '0', '退出成功', '2020-05-28 06:32:51');
INSERT INTO `sys_logininfor` VALUES (11406, 'test999', '192.168.2.171', '内网IP', 'Chrome 8', 'Windows 10', '0', '退出成功', '2020-05-28 06:35:03');
INSERT INTO `sys_logininfor` VALUES (11407, 'test999', '192.168.2.171', '内网IP', 'Chrome 8', 'Windows 10', '0', '退出成功', '2020-05-28 06:35:47');
INSERT INTO `sys_logininfor` VALUES (11408, 'test123', '0:0:0:0:0:0:0:1', 'XX XX', 'Chrome', 'Windows 10', '0', '退出成功', '2020-05-28 06:36:22');
INSERT INTO `sys_logininfor` VALUES (11409, 'test999', '192.168.2.171', '内网IP', 'Chrome 8', 'Windows 10', '0', '退出成功', '2020-05-28 06:40:38');
INSERT INTO `sys_logininfor` VALUES (11410, 'test999', '192.168.2.171', '内网IP', 'Chrome 8', 'Windows 10', '0', '退出成功', '2020-05-28 06:44:51');
INSERT INTO `sys_logininfor` VALUES (11411, 'test999', '192.168.2.171', '内网IP', 'Chrome 8', 'Windows 10', '0', '退出成功', '2020-05-28 06:51:44');
INSERT INTO `sys_logininfor` VALUES (11412, 'test999', '192.168.2.171', '内网IP', 'Chrome 8', 'Windows 10', '0', '退出成功', '2020-05-28 06:53:35');
INSERT INTO `sys_logininfor` VALUES (11413, 'test999', '192.168.2.171', '内网IP', 'Chrome 8', 'Windows 10', '0', '退出成功', '2020-05-28 06:58:07');
INSERT INTO `sys_logininfor` VALUES (11414, 'test999', '192.168.2.171', '内网IP', 'Chrome 8', 'Windows 10', '0', '退出成功', '2020-05-28 06:58:55');
INSERT INTO `sys_logininfor` VALUES (11415, 'test999', '192.168.2.171', '内网IP', 'Chrome 8', 'Windows 10', '0', '退出成功', '2020-05-28 07:00:05');
INSERT INTO `sys_logininfor` VALUES (11416, 'test999', '192.168.2.171', '内网IP', 'Chrome 8', 'Windows 10', '0', '退出成功', '2020-05-28 07:24:27');
INSERT INTO `sys_logininfor` VALUES (11417, 'test999', '192.168.2.171', '内网IP', 'Chrome 8', 'Windows 10', '0', '退出成功', '2020-05-28 07:25:09');
INSERT INTO `sys_logininfor` VALUES (11418, 'test999', '192.168.2.171', '内网IP', 'Chrome 8', 'Windows 10', '0', '退出成功', '2020-05-28 07:32:57');
INSERT INTO `sys_logininfor` VALUES (11419, 'test999', '192.168.2.171', '内网IP', 'Chrome 8', 'Windows 10', '0', '退出成功', '2020-05-28 07:34:55');
INSERT INTO `sys_logininfor` VALUES (11420, 'test999', '192.168.2.171', '内网IP', 'Chrome 8', 'Windows 10', '0', '退出成功', '2020-05-28 07:39:11');
INSERT INTO `sys_logininfor` VALUES (11421, 'test999', '192.168.2.171', '内网IP', 'Chrome 8', 'Windows 10', '0', '退出成功', '2020-05-28 08:17:49');
INSERT INTO `sys_logininfor` VALUES (11422, 'test9999', '0:0:0:0:0:0:0:1', 'XX XX', 'Chrome 8', 'Windows 10', '0', '退出成功', '2020-05-28 08:27:06');
INSERT INTO `sys_logininfor` VALUES (11423, 'test123', '192.168.2.171', '内网IP', 'Chrome 8', 'Windows 10', '0', '退出成功', '2020-05-28 08:36:23');
INSERT INTO `sys_logininfor` VALUES (11424, 'test123', '192.168.2.171', '内网IP', 'Chrome 8', 'Windows 10', '0', '退出成功', '2020-05-28 08:41:24');
INSERT INTO `sys_logininfor` VALUES (11425, 'test123', '192.168.2.171', '内网IP', 'Chrome 8', 'Windows 10', '0', '退出成功', '2020-05-28 08:41:41');
INSERT INTO `sys_logininfor` VALUES (11426, 'test123', '192.168.2.171', '内网IP', 'Chrome 8', 'Windows 10', '0', '退出成功', '2020-05-28 08:41:51');
INSERT INTO `sys_logininfor` VALUES (11427, 'test01', '192.168.2.136', '内网IP', 'Chrome 8', 'Windows 10', '0', '退出成功', '2020-05-28 10:00:58');
INSERT INTO `sys_logininfor` VALUES (11428, 'test01', '192.168.2.136', '内网IP', 'Chrome 8', 'Windows 10', '0', '退出成功', '2020-05-28 10:21:38');
INSERT INTO `sys_logininfor` VALUES (11429, 'test01', '192.168.2.136', '内网IP', 'Chrome 8', 'Windows 10', '0', '退出成功', '2020-05-28 10:23:34');
INSERT INTO `sys_logininfor` VALUES (11430, 'test123', '192.168.2.171', '内网IP', 'Chrome 8', 'Windows 10', '0', '退出成功', '2020-05-28 11:14:44');
INSERT INTO `sys_logininfor` VALUES (11431, 'test9999', '0:0:0:0:0:0:0:1', 'XX XX', 'Chrome 8', 'Windows 10', '0', '退出成功', '2020-05-29 01:58:31');
INSERT INTO `sys_logininfor` VALUES (11432, 'test999', '192.168.2.171', '内网IP', 'Chrome 8', 'Windows 10', '0', '退出成功', '2020-05-29 02:50:46');
INSERT INTO `sys_logininfor` VALUES (11433, 'test999', '192.168.2.171', '内网IP', 'Chrome 8', 'Windows 10', '0', '退出成功', '2020-05-29 02:51:06');
INSERT INTO `sys_logininfor` VALUES (11434, 'test999', '192.168.2.171', '内网IP', 'Chrome 8', 'Windows 10', '0', '退出成功', '2020-05-29 02:53:08');
INSERT INTO `sys_logininfor` VALUES (11435, 'test999', '192.168.2.171', '内网IP', 'Chrome 8', 'Windows 10', '0', '退出成功', '2020-05-29 02:59:48');
INSERT INTO `sys_logininfor` VALUES (11436, 'test999', '192.168.2.171', '内网IP', 'Chrome 8', 'Windows 10', '0', '退出成功', '2020-05-29 03:00:29');
INSERT INTO `sys_logininfor` VALUES (11437, 'test999', '192.168.2.171', '内网IP', 'Chrome 8', 'Windows 10', '0', '退出成功', '2020-05-29 03:04:53');
INSERT INTO `sys_logininfor` VALUES (11438, 'test999', '192.168.2.171', '内网IP', 'Chrome 8', 'Windows 10', '0', '退出成功', '2020-05-29 03:05:52');
INSERT INTO `sys_logininfor` VALUES (11439, 'test123', '0:0:0:0:0:0:0:1', 'XX XX', 'Chrome', 'Windows 10', '0', '退出成功', '2020-05-29 03:12:37');
INSERT INTO `sys_logininfor` VALUES (11440, 'test999', '192.168.2.171', '内网IP', 'Chrome 8', 'Windows 10', '0', '退出成功', '2020-05-29 03:17:31');
INSERT INTO `sys_logininfor` VALUES (11441, 'test999', '192.168.2.171', '内网IP', 'Chrome 8', 'Windows 10', '0', '退出成功', '2020-05-29 03:20:05');
INSERT INTO `sys_logininfor` VALUES (11442, 'test999', '192.168.2.171', '内网IP', 'Chrome 8', 'Windows 10', '0', '退出成功', '2020-05-29 03:25:33');
INSERT INTO `sys_logininfor` VALUES (11443, 'test999', '192.168.2.171', '内网IP', 'Chrome 8', 'Windows 10', '0', '退出成功', '2020-05-29 03:28:26');
INSERT INTO `sys_logininfor` VALUES (11444, 'test123', '192.168.2.171', '内网IP', 'Chrome 8', 'Windows 10', '0', '退出成功', '2020-05-29 03:28:37');
INSERT INTO `sys_logininfor` VALUES (11445, 'test123', '192.168.2.171', '内网IP', 'Chrome 8', 'Windows 10', '0', '退出成功', '2020-05-29 03:43:59');
INSERT INTO `sys_logininfor` VALUES (11446, 'test123', '192.168.2.171', '内网IP', 'Chrome 8', 'Windows 10', '0', '退出成功', '2020-05-29 03:44:09');
INSERT INTO `sys_logininfor` VALUES (11447, 'test123', '192.168.2.171', '内网IP', 'Chrome 8', 'Windows 10', '0', '退出成功', '2020-05-29 03:44:15');
INSERT INTO `sys_logininfor` VALUES (11448, 'test123', '192.168.2.171', '内网IP', 'Chrome 8', 'Windows 10', '0', '退出成功', '2020-05-29 03:44:30');
INSERT INTO `sys_logininfor` VALUES (11449, 'test123', '192.168.2.171', '内网IP', 'Chrome 8', 'Windows 10', '0', '退出成功', '2020-05-29 03:46:52');
INSERT INTO `sys_logininfor` VALUES (11450, 'test123', '0:0:0:0:0:0:0:1', 'XX XX', 'Chrome', 'Windows 10', '0', '退出成功', '2020-05-29 03:47:13');
INSERT INTO `sys_logininfor` VALUES (11451, 'test123', '192.168.2.171', '内网IP', 'Chrome 8', 'Windows 10', '0', '退出成功', '2020-05-29 03:47:33');
INSERT INTO `sys_logininfor` VALUES (11452, 'test123', '192.168.2.171', '内网IP', 'Chrome 8', 'Windows 10', '0', '退出成功', '2020-05-29 03:49:09');
INSERT INTO `sys_logininfor` VALUES (11453, 'test123', '192.168.2.171', '内网IP', 'Chrome 8', 'Windows 10', '0', '退出成功', '2020-05-29 03:50:04');
INSERT INTO `sys_logininfor` VALUES (11454, 'test123', '192.168.2.171', '内网IP', 'Chrome 8', 'Windows 10', '0', '退出成功', '2020-05-29 03:52:12');
INSERT INTO `sys_logininfor` VALUES (11455, 'test123', '192.168.2.171', '内网IP', 'Chrome 8', 'Windows 10', '0', '退出成功', '2020-05-29 03:52:33');
INSERT INTO `sys_logininfor` VALUES (11456, 'test123', '192.168.2.171', '内网IP', 'Chrome 8', 'Windows 10', '0', '退出成功', '2020-05-29 03:52:46');
INSERT INTO `sys_logininfor` VALUES (11457, 'test123', '192.168.2.171', '内网IP', 'Chrome 8', 'Windows 10', '0', '退出成功', '2020-05-29 03:53:03');
INSERT INTO `sys_logininfor` VALUES (11458, 'test123', '192.168.2.171', '内网IP', 'Chrome 8', 'Windows 10', '0', '退出成功', '2020-05-29 03:55:48');
INSERT INTO `sys_logininfor` VALUES (11459, 'test123', '192.168.2.171', '内网IP', 'Chrome 8', 'Windows 10', '0', '退出成功', '2020-05-29 03:56:04');
INSERT INTO `sys_logininfor` VALUES (11460, 'test123', '192.168.2.171', '内网IP', 'Chrome 8', 'Windows 10', '0', '退出成功', '2020-05-29 06:03:35');
INSERT INTO `sys_logininfor` VALUES (11461, 'test123', '192.168.2.171', '内网IP', 'Chrome 8', 'Windows 10', '0', '退出成功', '2020-05-29 06:06:22');
INSERT INTO `sys_logininfor` VALUES (11462, 'test123', '192.168.2.171', '内网IP', 'Chrome 8', 'Windows 10', '0', '退出成功', '2020-05-29 06:11:42');
INSERT INTO `sys_logininfor` VALUES (11463, 'test123', '192.168.2.171', '内网IP', 'Chrome 8', 'Windows 10', '0', '退出成功', '2020-05-29 06:19:14');
INSERT INTO `sys_logininfor` VALUES (11464, 'test123', '192.168.2.171', '内网IP', 'Chrome 8', 'Windows 10', '0', '退出成功', '2020-05-29 06:39:36');
INSERT INTO `sys_logininfor` VALUES (11465, '', '192.168.2.171', '内网IP', 'Chrome 8', 'Windows 10', '1', '* 必须填写', '2020-05-29 07:16:34');
INSERT INTO `sys_logininfor` VALUES (11466, 'test123', '192.168.2.171', '内网IP', 'Chrome 8', 'Windows 10', '1', '* 必须填写', '2020-05-29 07:17:19');
INSERT INTO `sys_logininfor` VALUES (11467, 'test123', '0:0:0:0:0:0:0:1', 'XX XX', 'Chrome', 'Windows 10', '0', '退出成功', '2020-05-29 07:18:15');
INSERT INTO `sys_logininfor` VALUES (11468, 'test123', '192.168.2.171', '内网IP', 'Chrome 8', 'Windows 10', '1', '* 必须填写', '2020-05-29 07:18:25');
INSERT INTO `sys_logininfor` VALUES (11469, 'test123', '192.168.2.171', '内网IP', 'Chrome 8', 'Windows 10', '1', '* 必须填写', '2020-05-29 07:18:49');
INSERT INTO `sys_logininfor` VALUES (11470, 'test123', '192.168.2.171', '内网IP', 'Chrome 8', 'Windows 10', '1', '* 必须填写', '2020-05-29 07:20:04');
INSERT INTO `sys_logininfor` VALUES (11471, 'test123', '192.168.2.171', '内网IP', 'Chrome 8', 'Windows 10', '1', '* 必须填写', '2020-05-29 07:20:06');
INSERT INTO `sys_logininfor` VALUES (11472, 'test123', '192.168.2.171', '内网IP', 'Chrome 8', 'Windows 10', '1', '* 必须填写', '2020-05-29 07:20:06');
INSERT INTO `sys_logininfor` VALUES (11473, 'test123', '192.168.2.171', '内网IP', 'Chrome 8', 'Windows 10', '1', '* 必须填写', '2020-05-29 07:20:06');
INSERT INTO `sys_logininfor` VALUES (11474, 'test123', '192.168.2.171', '内网IP', 'Chrome 8', 'Windows 10', '1', '* 必须填写', '2020-05-29 07:21:33');
INSERT INTO `sys_logininfor` VALUES (11475, 'test123', '192.168.2.171', '内网IP', 'Chrome 8', 'Windows 10', '0', '退出成功', '2020-05-29 07:25:48');
INSERT INTO `sys_logininfor` VALUES (11476, 'test123', '192.168.2.171', '内网IP', 'Chrome 8', 'Windows 10', '0', '退出成功', '2020-05-29 07:26:29');
INSERT INTO `sys_logininfor` VALUES (11477, 'test123', '192.168.2.171', '内网IP', 'Chrome 8', 'Windows 10', '0', '退出成功', '2020-05-29 07:26:38');
INSERT INTO `sys_logininfor` VALUES (11478, 'test123', '192.168.2.171', '内网IP', 'Chrome 8', 'Windows 10', '0', '退出成功', '2020-05-29 07:28:27');
INSERT INTO `sys_logininfor` VALUES (11479, 'test123', '192.168.2.171', '内网IP', 'Chrome 8', 'Windows 10', '0', '退出成功', '2020-05-29 07:31:46');
INSERT INTO `sys_logininfor` VALUES (11480, 'test123', '192.168.2.171', '内网IP', 'Chrome 8', 'Windows 10', '0', '退出成功', '2020-05-29 07:33:32');
INSERT INTO `sys_logininfor` VALUES (11481, 'test123', '192.168.2.171', '内网IP', 'Chrome 8', 'Windows 10', '0', '退出成功', '2020-05-29 07:38:22');
INSERT INTO `sys_logininfor` VALUES (11482, 'test123', '192.168.2.171', '内网IP', 'Chrome 8', 'Windows 10', '0', '退出成功', '2020-05-29 07:38:27');
INSERT INTO `sys_logininfor` VALUES (11483, 'test123', '192.168.2.171', '内网IP', 'Chrome 8', 'Windows 10', '0', '退出成功', '2020-05-29 07:39:52');
INSERT INTO `sys_logininfor` VALUES (11484, 'test123', '192.168.2.171', '内网IP', 'Chrome 8', 'Windows 10', '0', '退出成功', '2020-05-29 07:41:25');
INSERT INTO `sys_logininfor` VALUES (11485, 'test123', '192.168.2.171', '内网IP', 'Chrome 8', 'Windows 10', '0', '退出成功', '2020-05-29 08:02:26');
INSERT INTO `sys_logininfor` VALUES (11486, 'test123', '0:0:0:0:0:0:0:1', 'XX XX', 'Chrome', 'Windows 10', '0', '退出成功', '2020-05-29 08:09:00');
INSERT INTO `sys_logininfor` VALUES (11487, 'test999', '192.168.2.171', '内网IP', 'Chrome 8', 'Windows 10', '0', '退出成功', '2020-05-29 08:28:57');
INSERT INTO `sys_logininfor` VALUES (11488, 'test999', '192.168.2.171', '内网IP', 'Chrome 8', 'Windows 10', '0', '退出成功', '2020-05-29 08:29:16');
INSERT INTO `sys_logininfor` VALUES (11489, '137111111111', '192.168.2.171', '内网IP', 'Chrome 8', 'Windows 10', '1', '用户不存在/密码错误', '2020-05-29 08:29:34');
INSERT INTO `sys_logininfor` VALUES (11490, '137111111111', '192.168.2.171', '内网IP', 'Chrome 8', 'Windows 10', '1', '用户不存在/密码错误', '2020-05-29 08:29:40');
INSERT INTO `sys_logininfor` VALUES (11491, '137111111111', '192.168.2.171', '内网IP', 'Chrome 8', 'Windows 10', '1', '用户不存在/密码错误', '2020-05-29 08:29:44');
INSERT INTO `sys_logininfor` VALUES (11492, '137111111111', '192.168.2.171', '内网IP', 'Chrome 8', 'Windows 10', '1', '用户不存在/密码错误', '2020-05-29 08:29:55');
INSERT INTO `sys_logininfor` VALUES (11493, '137111111111', '192.168.2.171', '内网IP', 'Chrome 8', 'Windows 10', '1', '用户不存在/密码错误', '2020-05-29 08:30:06');
INSERT INTO `sys_logininfor` VALUES (11494, '137111111111', '192.168.2.171', '内网IP', 'Chrome 8', 'Windows 10', '1', '用户不存在/密码错误', '2020-05-29 08:30:09');
INSERT INTO `sys_logininfor` VALUES (11495, 'test999', '192.168.2.171', '内网IP', 'Chrome 8', 'Windows 10', '0', '退出成功', '2020-05-29 08:30:57');
INSERT INTO `sys_logininfor` VALUES (11496, 'test999', '192.168.2.171', '内网IP', 'Chrome 8', 'Windows 10', '0', '退出成功', '2020-05-29 08:36:15');
INSERT INTO `sys_logininfor` VALUES (11497, 'test999', '192.168.2.171', '内网IP', 'Chrome 8', 'Windows 10', '0', '退出成功', '2020-05-29 08:40:55');
INSERT INTO `sys_logininfor` VALUES (11498, 'test999', '192.168.2.171', '内网IP', 'Chrome 8', 'Windows 10', '0', '退出成功', '2020-05-29 08:42:17');
INSERT INTO `sys_logininfor` VALUES (11499, 'test999', '192.168.2.171', '内网IP', 'Chrome 8', 'Windows 10', '0', '退出成功', '2020-05-29 08:42:23');
INSERT INTO `sys_logininfor` VALUES (11500, 'test999', '192.168.2.171', '内网IP', 'Chrome 8', 'Windows 10', '0', '退出成功', '2020-05-29 08:43:50');
INSERT INTO `sys_logininfor` VALUES (11501, 'test999', '192.168.2.171', '内网IP', 'Chrome 8', 'Windows 10', '0', '退出成功', '2020-05-29 08:59:09');
INSERT INTO `sys_logininfor` VALUES (11502, 'test999', '192.168.2.171', '内网IP', 'Chrome 8', 'Windows 10', '0', '退出成功', '2020-05-29 09:01:08');
INSERT INTO `sys_logininfor` VALUES (11503, 'test999', '192.168.2.171', '内网IP', 'Chrome 8', 'Windows 10', '0', '退出成功', '2020-05-29 09:01:11');
INSERT INTO `sys_logininfor` VALUES (11504, 'test999', '192.168.2.171', '内网IP', 'Chrome 8', 'Windows 10', '0', '退出成功', '2020-05-29 10:27:06');
INSERT INTO `sys_logininfor` VALUES (11505, 'test999', '192.168.2.171', '内网IP', 'Chrome 8', 'Windows 10', '0', '退出成功', '2020-05-29 10:27:46');
INSERT INTO `sys_logininfor` VALUES (11506, 'test999', '192.168.2.171', '内网IP', 'Chrome 8', 'Windows 10', '0', '退出成功', '2020-05-29 10:28:23');
INSERT INTO `sys_logininfor` VALUES (11507, 'test123', '192.168.2.171', '内网IP', 'Chrome 8', 'Windows 10', '0', '退出成功', '2020-05-29 10:28:35');
INSERT INTO `sys_logininfor` VALUES (11508, 'test123', '192.168.2.171', '内网IP', 'Chrome 8', 'Windows 10', '0', '退出成功', '2020-05-29 10:32:06');
INSERT INTO `sys_logininfor` VALUES (11509, 'test123', '192.168.2.171', '内网IP', 'Chrome 8', 'Windows 10', '0', '退出成功', '2020-05-29 10:32:53');
INSERT INTO `sys_logininfor` VALUES (11510, 'test123', '192.168.2.171', '内网IP', 'Chrome 8', 'Windows 10', '0', '退出成功', '2020-05-29 10:33:52');
INSERT INTO `sys_logininfor` VALUES (11511, 'test123', '192.168.2.171', '内网IP', 'Chrome 8', 'Windows 10', '0', '退出成功', '2020-05-29 10:34:53');
INSERT INTO `sys_logininfor` VALUES (11512, 'test123', '192.168.2.171', '内网IP', 'Chrome 8', 'Windows 10', '0', '退出成功', '2020-05-29 10:35:01');
INSERT INTO `sys_logininfor` VALUES (11513, 'test123', '192.168.2.171', '内网IP', 'Chrome 8', 'Windows 10', '0', '退出成功', '2020-05-29 10:35:17');
INSERT INTO `sys_logininfor` VALUES (11514, 'test123', '192.168.2.171', '内网IP', 'Chrome 8', 'Windows 10', '0', '退出成功', '2020-05-29 10:43:18');
INSERT INTO `sys_logininfor` VALUES (11515, 'test123', '192.168.2.171', '内网IP', 'Chrome 8', 'Windows 10', '0', '退出成功', '2020-05-29 10:55:17');
INSERT INTO `sys_logininfor` VALUES (11516, 'test123', '192.168.2.171', '内网IP', 'Chrome 8', 'Windows 10', '0', '退出成功', '2020-05-29 11:00:17');
INSERT INTO `sys_logininfor` VALUES (11517, 'test123', '192.168.2.171', '内网IP', 'Chrome 8', 'Windows 10', '0', '退出成功', '2020-05-29 11:04:43');
INSERT INTO `sys_logininfor` VALUES (11518, 'test123', '192.168.2.171', '内网IP', 'Chrome 8', 'Windows 10', '0', '退出成功', '2020-05-29 11:24:15');
INSERT INTO `sys_logininfor` VALUES (11519, 'test999', '192.168.2.171', '内网IP', 'Chrome 8', 'Windows 10', '0', '退出成功', '2020-05-29 11:24:37');
INSERT INTO `sys_logininfor` VALUES (11520, 'test999', '192.168.2.171', '内网IP', 'Chrome 8', 'Windows 10', '0', '退出成功', '2020-05-29 11:25:41');
INSERT INTO `sys_logininfor` VALUES (11521, 'test999', '192.168.2.171', '内网IP', 'Chrome 8', 'Windows 10', '0', '退出成功', '2020-05-29 11:26:39');
INSERT INTO `sys_logininfor` VALUES (11522, 'test999', '192.168.2.171', '内网IP', 'Chrome 8', 'Windows 10', '0', '退出成功', '2020-05-29 11:28:07');
INSERT INTO `sys_logininfor` VALUES (11523, 'test999', '192.168.2.171', '内网IP', 'Chrome 8', 'Windows 10', '0', '退出成功', '2020-05-29 11:34:43');
INSERT INTO `sys_logininfor` VALUES (11524, 'test999', '192.168.2.171', '内网IP', 'Chrome 8', 'Windows 10', '0', '退出成功', '2020-05-29 11:34:52');
INSERT INTO `sys_logininfor` VALUES (11525, 'test999', '192.168.2.171', '内网IP', 'Chrome 8', 'Windows 10', '0', '退出成功', '2020-05-29 11:43:19');
INSERT INTO `sys_logininfor` VALUES (11526, 'test999', '192.168.2.171', '内网IP', 'Chrome 8', 'Windows 10', '0', '退出成功', '2020-05-29 11:43:28');
INSERT INTO `sys_logininfor` VALUES (11527, 'test123', '192.168.2.171', '内网IP', 'Chrome 8', 'Windows 10', '0', '退出成功', '2020-05-29 11:43:41');
INSERT INTO `sys_logininfor` VALUES (11528, 'test123', '192.168.2.171', '内网IP', 'Chrome 8', 'Windows 10', '0', '退出成功', '2020-05-29 11:44:01');
INSERT INTO `sys_logininfor` VALUES (11529, 'test123', '192.168.2.171', '内网IP', 'Chrome 8', 'Windows 10', '0', '退出成功', '2020-05-29 11:48:43');
INSERT INTO `sys_logininfor` VALUES (11530, 'test123', '192.168.2.171', '内网IP', 'Chrome 8', 'Windows 10', '0', '退出成功', '2020-05-29 11:48:51');
INSERT INTO `sys_logininfor` VALUES (11531, 'test123', '192.168.2.171', '内网IP', 'Chrome 8', 'Windows 10', '0', '退出成功', '2020-05-29 11:49:10');
INSERT INTO `sys_logininfor` VALUES (11532, 'test123', '192.168.2.171', '内网IP', 'Chrome 8', 'Windows 10', '0', '退出成功', '2020-05-29 11:50:22');
INSERT INTO `sys_logininfor` VALUES (11533, 'test123', '192.168.2.171', '内网IP', 'Chrome 8', 'Windows 10', '0', '退出成功', '2020-05-29 11:51:12');
INSERT INTO `sys_logininfor` VALUES (11534, 'test123', '192.168.2.171', '内网IP', 'Chrome 8', 'Windows 10', '0', '退出成功', '2020-05-29 11:57:30');
INSERT INTO `sys_logininfor` VALUES (11535, 'test123', '192.168.2.171', '内网IP', 'Chrome 8', 'Windows 10', '0', '退出成功', '2020-05-29 11:59:19');
INSERT INTO `sys_logininfor` VALUES (11536, 'test123', '192.168.2.171', '内网IP', 'Chrome 8', 'Windows 10', '0', '退出成功', '2020-05-29 12:02:30');
INSERT INTO `sys_logininfor` VALUES (11537, 'test123', '192.168.2.171', '内网IP', 'Chrome 8', 'Windows 10', '0', '退出成功', '2020-05-29 12:10:27');
INSERT INTO `sys_logininfor` VALUES (11538, 'test123', '192.168.2.171', '内网IP', 'Chrome 8', 'Windows 10', '0', '退出成功', '2020-05-29 12:17:27');
INSERT INTO `sys_logininfor` VALUES (11539, 'test123', '192.168.2.171', '内网IP', 'Chrome 8', 'Windows 10', '0', '退出成功', '2020-05-29 12:17:41');
INSERT INTO `sys_logininfor` VALUES (11540, 'test123', '192.168.2.171', '内网IP', 'Chrome 8', 'Windows 10', '0', '退出成功', '2020-05-29 12:17:51');
INSERT INTO `sys_logininfor` VALUES (11541, 'test123', '192.168.2.171', '内网IP', 'Chrome 8', 'Windows 10', '0', '退出成功', '2020-05-29 12:18:51');
INSERT INTO `sys_logininfor` VALUES (11542, 'test123', '192.168.2.171', '内网IP', 'Chrome 8', 'Windows 10', '0', '退出成功', '2020-05-29 12:19:10');
INSERT INTO `sys_logininfor` VALUES (11543, 'test123', '192.168.2.171', '内网IP', 'Chrome 8', 'Windows 10', '0', '退出成功', '2020-05-29 12:21:57');
INSERT INTO `sys_logininfor` VALUES (11544, 'test123', '192.168.2.171', '内网IP', 'Chrome 8', 'Windows 10', '0', '退出成功', '2020-05-29 12:23:21');
INSERT INTO `sys_logininfor` VALUES (11545, 'test123', '192.168.2.171', '内网IP', 'Chrome 8', 'Windows 10', '0', '退出成功', '2020-05-29 12:30:01');
INSERT INTO `sys_logininfor` VALUES (11546, 'test123', '192.168.2.171', '内网IP', 'Chrome 8', 'Windows 10', '0', '退出成功', '2020-05-29 12:37:05');
INSERT INTO `sys_logininfor` VALUES (11547, 'test123', '192.168.2.171', '内网IP', 'Chrome 8', 'Windows 10', '0', '退出成功', '2020-05-29 12:39:56');
INSERT INTO `sys_logininfor` VALUES (11548, 'test123', '192.168.2.171', '内网IP', 'Chrome 8', 'Windows 10', '0', '退出成功', '2020-05-29 12:40:25');
INSERT INTO `sys_logininfor` VALUES (11549, 'test123', '192.168.2.171', '内网IP', 'Chrome 8', 'Windows 10', '0', '退出成功', '2020-05-29 12:43:32');
INSERT INTO `sys_logininfor` VALUES (11550, '137111111111', '192.168.2.171', '内网IP', 'Chrome 8', 'Windows 10', '1', '用户不存在/密码错误', '2020-06-01 16:50:41');
INSERT INTO `sys_logininfor` VALUES (11551, '137111111111', '192.168.2.171', '内网IP', 'Chrome 8', 'Windows 10', '1', '用户不存在/密码错误', '2020-06-01 16:50:47');
INSERT INTO `sys_logininfor` VALUES (11552, 'test01', '192.168.2.171', '内网IP', 'Chrome 8', 'Windows 10', '0', '退出成功', '2020-06-01 16:51:24');
INSERT INTO `sys_logininfor` VALUES (11553, 'admin', '192.168.2.191', '内网IP', 'Chrome', 'Windows 10', '0', '登录成功', '2020-06-01 16:52:04');
INSERT INTO `sys_logininfor` VALUES (11554, 'test01', '192.168.2.171', '内网IP', 'Chrome 8', 'Windows 10', '0', '退出成功', '2020-06-01 18:57:40');
INSERT INTO `sys_logininfor` VALUES (11555, 'test01', '192.168.2.171', '内网IP', 'Chrome 8', 'Windows 10', '0', '退出成功', '2020-06-01 18:57:56');
INSERT INTO `sys_logininfor` VALUES (11556, 'admin', '192.168.2.136', '内网IP', 'Chrome 8', 'Windows 10', '0', '登录成功', '2020-06-01 18:59:09');
INSERT INTO `sys_logininfor` VALUES (11557, 'admin', '192.168.2.136', '内网IP', 'Chrome 8', 'Windows 10', '0', '登录成功', '2020-06-01 18:59:50');
INSERT INTO `sys_logininfor` VALUES (11558, 'admin', '192.168.2.136', '内网IP', 'Chrome 8', 'Windows 10', '0', '登录成功', '2020-06-01 19:06:23');
INSERT INTO `sys_logininfor` VALUES (11559, 'admin', '192.168.2.136', '内网IP', 'Chrome 8', 'Windows 10', '0', '登录成功', '2020-06-01 19:08:04');
INSERT INTO `sys_logininfor` VALUES (11560, 'admin', '192.168.2.136', '内网IP', 'Chrome 8', 'Windows 10', '0', '登录成功', '2020-06-01 19:09:01');
INSERT INTO `sys_logininfor` VALUES (11561, 'admin', '192.168.2.136', '内网IP', 'Chrome 8', 'Windows 10', '0', '登录成功', '2020-06-01 19:09:18');
INSERT INTO `sys_logininfor` VALUES (11562, 'test01', '192.168.2.171', '内网IP', 'Chrome 8', 'Windows 10', '0', '退出成功', '2020-06-01 19:28:01');
INSERT INTO `sys_logininfor` VALUES (11563, 'admin', '192.168.2.136', '内网IP', 'Chrome 8', 'Windows 10', '0', '登录成功', '2020-06-01 20:14:42');
INSERT INTO `sys_logininfor` VALUES (11564, 'admin', '192.168.2.136', '内网IP', 'Chrome 8', 'Windows 10', '0', '登录成功', '2020-06-01 20:15:06');
INSERT INTO `sys_logininfor` VALUES (11565, 'admin', '192.168.2.136', '内网IP', 'Chrome 8', 'Windows 10', '0', '登录成功', '2020-06-01 20:15:40');
INSERT INTO `sys_logininfor` VALUES (11566, 'admin', '192.168.2.136', '内网IP', 'Chrome 8', 'Windows 10', '0', '登录成功', '2020-06-01 20:24:29');
INSERT INTO `sys_logininfor` VALUES (11567, 'admin', '192.168.2.136', '内网IP', 'Chrome 8', 'Windows 10', '0', '登录成功', '2020-06-01 20:31:02');
INSERT INTO `sys_logininfor` VALUES (11568, 'admin', '192.168.2.136', '内网IP', 'Chrome 8', 'Windows 10', '0', '登录成功', '2020-06-01 20:33:09');
INSERT INTO `sys_logininfor` VALUES (11569, 'admin', '192.168.2.136', '内网IP', 'Chrome 8', 'Windows 10', '0', '登录成功', '2020-06-01 20:34:29');
INSERT INTO `sys_logininfor` VALUES (11570, 'admin', '192.168.2.136', '内网IP', 'Chrome 8', 'Windows 10', '0', '登录成功', '2020-06-01 20:34:39');
INSERT INTO `sys_logininfor` VALUES (11571, 'test9999', '0:0:0:0:0:0:0:1', 'XX XX', 'Chrome 8', 'Windows 10', '0', '退出成功', '2020-06-01 20:44:54');
INSERT INTO `sys_logininfor` VALUES (11572, 'test9999', '0:0:0:0:0:0:0:1', 'XX XX', 'Chrome 8', 'Windows 10', '0', '退出成功', '2020-06-02 09:55:51');
INSERT INTO `sys_logininfor` VALUES (11573, 'test9999', '0:0:0:0:0:0:0:1', 'XX XX', 'Chrome 8', 'Windows 10', '0', '退出成功', '2020-06-02 10:00:52');
INSERT INTO `sys_logininfor` VALUES (11574, 'test9999', '0:0:0:0:0:0:0:1', 'XX XX', 'Chrome 8', 'Windows 10', '0', '退出成功', '2020-06-02 10:05:09');
INSERT INTO `sys_logininfor` VALUES (11575, 'AAAAAA', '0:0:0:0:0:0:0:1', 'XX XX', 'Chrome', 'Windows 10', '0', '退出成功', '2020-06-02 11:48:41');
INSERT INTO `sys_logininfor` VALUES (11576, 'AAAAAA', '0:0:0:0:0:0:0:1', 'XX XX', 'Chrome 8', 'Windows 10', '0', '退出成功', '2020-06-02 14:55:56');
INSERT INTO `sys_logininfor` VALUES (11577, 'AAAAAA', '0:0:0:0:0:0:0:1', 'XX XX', 'Chrome 8', 'Windows 10', '0', '退出成功', '2020-06-02 15:17:39');
INSERT INTO `sys_logininfor` VALUES (11578, 'AAAAAA', '0:0:0:0:0:0:0:1', 'XX XX', 'Chrome 8', 'Windows 10', '0', '退出成功', '2020-06-02 15:25:25');
INSERT INTO `sys_logininfor` VALUES (11579, 'test01', '0:0:0:0:0:0:0:1', 'XX XX', 'Chrome', 'Windows 10', '0', '退出成功', '2020-06-02 15:25:52');
INSERT INTO `sys_logininfor` VALUES (11580, 'AAAAAA', '0:0:0:0:0:0:0:1', 'XX XX', 'Chrome 8', 'Windows 10', '0', '退出成功', '2020-06-02 15:32:25');
INSERT INTO `sys_logininfor` VALUES (11581, 'AAAAAA', '0:0:0:0:0:0:0:1', 'XX XX', 'Chrome 8', 'Windows 10', '0', '退出成功', '2020-06-02 15:40:17');
INSERT INTO `sys_logininfor` VALUES (11582, 'AAAAAA', '0:0:0:0:0:0:0:1', 'XX XX', 'Chrome 8', 'Windows 10', '0', '退出成功', '2020-06-02 15:46:59');
INSERT INTO `sys_logininfor` VALUES (11583, 'AAAAAA', '0:0:0:0:0:0:0:1', 'XX XX', 'Chrome 8', 'Windows 10', '0', '退出成功', '2020-06-02 16:29:36');
INSERT INTO `sys_logininfor` VALUES (11584, 'AAAAAA', '0:0:0:0:0:0:0:1', 'XX XX', 'Chrome 8', 'Windows 10', '0', '退出成功', '2020-06-02 17:51:39');
INSERT INTO `sys_logininfor` VALUES (11585, 'AAAAAA', '0:0:0:0:0:0:0:1', 'XX XX', 'Chrome 8', 'Windows 10', '0', '退出成功', '2020-06-02 18:05:10');
INSERT INTO `sys_logininfor` VALUES (11586, 'AAAAAA', '0:0:0:0:0:0:0:1', 'XX XX', 'Chrome 8', 'Windows 10', '0', '退出成功', '2020-06-02 18:59:45');

-- ----------------------------
-- Table structure for sys_menu
-- ----------------------------
DROP TABLE IF EXISTS `sys_menu`;
CREATE TABLE `sys_menu`  (
  `id` int(0) NOT NULL AUTO_INCREMENT,
  `menu_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '菜单名',
  `parent_id` int(0) NULL DEFAULT NULL COMMENT '父id',
  `can_see` tinyint(1) NULL DEFAULT NULL COMMENT '能否查看',
  `can_update` tinyint(1) NULL DEFAULT NULL COMMENT '能否编辑',
  `lv` int(0) NULL DEFAULT NULL COMMENT '等级',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 107 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of sys_menu
-- ----------------------------
INSERT INTO `sys_menu` VALUES (1, 'Workbenck', 0, 1, 1, 2);
INSERT INTO `sys_menu` VALUES (2, 'User', 0, 1, 1, 2);
INSERT INTO `sys_menu` VALUES (3, 'Games', 0, 1, 1, 2);
INSERT INTO `sys_menu` VALUES (4, 'Financing', 0, 1, 1, 2);
INSERT INTO `sys_menu` VALUES (5, 'Operation', 0, 1, 1, 2);
INSERT INTO `sys_menu` VALUES (6, 'Data', 0, 1, 1, 2);
INSERT INTO `sys_menu` VALUES (8, 'System', 0, 1, 1, 2);
INSERT INTO `sys_menu` VALUES (9, 'message', 1, 1, 1, 2);
INSERT INTO `sys_menu` VALUES (10, 'chart', 1, 1, 1, 2);
INSERT INTO `sys_menu` VALUES (11, 'PlatformComprehensiveReport', 1, 1, 1, 2);
INSERT INTO `sys_menu` VALUES (12, 'userMessage', 2, 1, 1, 2);
INSERT INTO `sys_menu` VALUES (13, 'loginPlatform', 2, 1, 1, 2);
INSERT INTO `sys_menu` VALUES (14, 'bankManagement', 2, 1, 1, 2);
INSERT INTO `sys_menu` VALUES (16, 'onlineUsers', 2, 1, 1, 2);
INSERT INTO `sys_menu` VALUES (18, 'taggedUser', 2, 1, 1, 2);
INSERT INTO `sys_menu` VALUES (19, 'freezeIP', 2, 1, 1, 2);
INSERT INTO `sys_menu` VALUES (21, 'userLoginRecord', 2, 1, 1, 2);
INSERT INTO `sys_menu` VALUES (23, 'vipset', 2, 1, 1, 2);
INSERT INTO `sys_menu` VALUES (24, 'viptier', 2, 1, 1, 2);
INSERT INTO `sys_menu` VALUES (26, 'rebateSet', 2, 1, 1, 2);
INSERT INTO `sys_menu` VALUES (28, 'agentQuery', 2, 1, 1, 2);
INSERT INTO `sys_menu` VALUES (30, 'vipAgency', 2, 1, 1, 2);
INSERT INTO `sys_menu` VALUES (31, 'platformManage', 3, 1, 1, 2);
INSERT INTO `sys_menu` VALUES (32, 'classifySet', 3, 1, 1, 2);
INSERT INTO `sys_menu` VALUES (34, 'recommend', 3, 1, 1, 2);
INSERT INTO `sys_menu` VALUES (36, 'functionSet', 5, 1, 1, 2);
INSERT INTO `sys_menu` VALUES (38, 'gongnengList', 5, 1, 1, 2);
INSERT INTO `sys_menu` VALUES (39, 'rollingAnnouncement', 5, 1, 1, 2);
INSERT INTO `sys_menu` VALUES (41, 'xitongBulletin', 5, 1, 1, 2);
INSERT INTO `sys_menu` VALUES (42, 'mailBox', 5, 1, 1, 2);
INSERT INTO `sys_menu` VALUES (44, 'pushMessage', 5, 1, 1, 2);
INSERT INTO `sys_menu` VALUES (45, 'safeDepositBox', 5, 1, 1, 2);
INSERT INTO `sys_menu` VALUES (47, 'registration', 5, 1, 1, 2);
INSERT INTO `sys_menu` VALUES (48, 'registerFree', 5, 1, 1, 2);
INSERT INTO `sys_menu` VALUES (49, 'loginPresent', 5, 1, 1, 2);
INSERT INTO `sys_menu` VALUES (51, 'placingBonus', 5, 1, 1, 2);
INSERT INTO `sys_menu` VALUES (52, 'washCode', 5, 1, 1, 2);
INSERT INTO `sys_menu` VALUES (53, 'rankingsReward', 5, 1, 1, 2);
INSERT INTO `sys_menu` VALUES (54, 'luckyThing', 5, 1, 1, 2);
INSERT INTO `sys_menu` VALUES (55, 'signIn', 5, 1, 1, 2);
INSERT INTO `sys_menu` VALUES (57, 'replaceBank', 5, 1, 1, 2);
INSERT INTO `sys_menu` VALUES (59, 'replaceManage', 5, 1, 1, 2);
INSERT INTO `sys_menu` VALUES (61, 'replaceIncome', 5, 1, 1, 2);
INSERT INTO `sys_menu` VALUES (63, 'replaceSaveUp', 5, 1, 1, 2);
INSERT INTO `sys_menu` VALUES (64, 'addThirdparty', 6, 1, 1, 2);
INSERT INTO `sys_menu` VALUES (65, 'addThirdparty', 4, 1, 1, 2);
INSERT INTO `sys_menu` VALUES (66, 'paySetting', 6, 1, 1, 2);
INSERT INTO `sys_menu` VALUES (68, 'autoPayment', 4, 1, 1, 2);
INSERT INTO `sys_menu` VALUES (69, 'PrePaid', 4, 1, 1, 2);
INSERT INTO `sys_menu` VALUES (70, 'companyIncome', 4, 1, 1, 2);
INSERT INTO `sys_menu` VALUES (72, 'netSilver', 4, 1, 1, 2);
INSERT INTO `sys_menu` VALUES (73, 'weiXin', 4, 1, 1, 2);
INSERT INTO `sys_menu` VALUES (75, 'zhiFuBao', 4, 1, 1, 2);
INSERT INTO `sys_menu` VALUES (77, 'QQpayment', 4, 1, 1, 2);
INSERT INTO `sys_menu` VALUES (78, 'AgencyHigher', 4, 1, 1, 2);
INSERT INTO `sys_menu` VALUES (79, 'ThirdParty', 4, 1, 1, 2);
INSERT INTO `sys_menu` VALUES (80, 'ShimobunManage', 4, 1, 1, 2);
INSERT INTO `sys_menu` VALUES (81, 'LabourUpDown', 4, 1, 1, 2);
INSERT INTO `sys_menu` VALUES (82, 'ManualRecording', 4, 1, 1, 2);
INSERT INTO `sys_menu` VALUES (83, 'ManualDepositRecord', 4, 1, 1, 2);
INSERT INTO `sys_menu` VALUES (84, 'FlowRecord', 4, 1, 1, 2);
INSERT INTO `sys_menu` VALUES (85, 'goldWater', 4, 1, 1, 2);
INSERT INTO `sys_menu` VALUES (86, 'reportUsers', 6, 1, 1, 2);
INSERT INTO `sys_menu` VALUES (87, 'firstRechargeRepor', 6, 1, 1, 2);
INSERT INTO `sys_menu` VALUES (88, 'upfenReport', 6, 1, 1, 2);
INSERT INTO `sys_menu` VALUES (89, 'downfenReport', 6, 1, 1, 2);
INSERT INTO `sys_menu` VALUES (90, 'PlatformGameReport', 6, 1, 1, 2);
INSERT INTO `sys_menu` VALUES (91, 'platformOnSingle', 6, 1, 1, 2);
INSERT INTO `sys_menu` VALUES (92, 'reportMoney', 6, 1, 1, 2);
INSERT INTO `sys_menu` VALUES (93, 'childAccount', 8, 1, 1, 2);
INSERT INTO `sys_menu` VALUES (95, 'rolePower', 8, 1, 1, 2);
INSERT INTO `sys_menu` VALUES (96, 'loginRecord', 8, 1, 1, 2);
INSERT INTO `sys_menu` VALUES (97, 'operationRecord', 8, 1, 1, 2);
INSERT INTO `sys_menu` VALUES (100, 'managerList', 8, 1, 1, 2);
INSERT INTO `sys_menu` VALUES (101, 'Google', 8, 1, 1, 2);
INSERT INTO `sys_menu` VALUES (102, 'FAQset', 8, 1, 1, 2);
INSERT INTO `sys_menu` VALUES (103, 'dialogueSet', 8, 1, 1, 2);
INSERT INTO `sys_menu` VALUES (104, 'dialogueRecord', 8, 1, 1, 2);
INSERT INTO `sys_menu` VALUES (106, 'userComplaint', 8, 1, 1, 2);
INSERT INTO `sys_menu` VALUES (107, 'openSite', 8, 1, 1, 2);

-- ----------------------------
-- Table structure for sys_oper_log
-- ----------------------------
DROP TABLE IF EXISTS `sys_oper_log`;
CREATE TABLE `sys_oper_log`  (
  `oper_id` int(0) NOT NULL AUTO_INCREMENT COMMENT '日志主键',
  `title` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT '' COMMENT '模块标题',
  `business_type` int(0) NULL DEFAULT 0 COMMENT '业务类型（0其它 1新增 2修改 3删除）',
  `method` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT '' COMMENT '方法名称',
  `request_method` varchar(10) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `operator_type` int(0) NULL DEFAULT 0 COMMENT '操作类别（0其它 1后台用户 2手机端用户）',
  `oper_name` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT '' COMMENT '操作人员',
  `dept_name` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT '' COMMENT '部门名称',
  `oper_url` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT '' COMMENT '请求URL',
  `oper_ip` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT '' COMMENT '主机地址',
  `oper_location` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT '' COMMENT '操作地点',
  `oper_param` varchar(2000) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT '' COMMENT '请求参数',
  `status` int(0) NULL DEFAULT 0 COMMENT '操作状态（0正常 1异常）',
  `error_msg` varchar(2000) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT '' COMMENT '错误消息',
  `oper_time` datetime(0) NULL DEFAULT NULL COMMENT '操作时间',
  PRIMARY KEY (`oper_id`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci COMMENT = '操作日志记录' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of sys_oper_log
-- ----------------------------

-- ----------------------------
-- Table structure for sys_role
-- ----------------------------
DROP TABLE IF EXISTS `sys_role`;
CREATE TABLE `sys_role`  (
  `role_id` int(0) NOT NULL AUTO_INCREMENT COMMENT '角色ID',
  `role_name` varchar(30) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '角色名称',
  `role_key` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '角色权限字符串',
  `role_sort` int(0) NOT NULL COMMENT '显示顺序',
  `data_scope` char(1) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT '1' COMMENT '数据范围（1：全部数据权限 2：自定数据权限）',
  `status` char(1) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '角色状态（0正常 1停用）',
  `del_flag` char(1) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT '0' COMMENT '删除标志（0代表存在 2代表删除）',
  `create_by` varchar(64) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT '' COMMENT '创建者',
  `create_time` datetime(0) NULL DEFAULT NULL COMMENT '创建时间',
  `update_by` varchar(64) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT '' COMMENT '更新者',
  `update_time` datetime(0) NULL DEFAULT NULL COMMENT '更新时间',
  `remark` varchar(500) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '备注',
  PRIMARY KEY (`role_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 12 CHARACTER SET = utf8 COLLATE = utf8_general_ci COMMENT = '角色信息表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of sys_role
-- ----------------------------
INSERT INTO `sys_role` VALUES (1, '超级管理员', 'admin', 1, '1', '0', '0', 'admin', '2018-03-16 11:33:00', 'ry', '2019-05-30 15:42:31', '管理员');
INSERT INTO `sys_role` VALUES (2, '普通管理员', 'common', 2, '2', '0', '0', 'admin', '2018-03-16 11:33:00', 'ry', '2019-05-30 15:42:33', '普通角色');

-- ----------------------------
-- Table structure for sys_role_menu
-- ----------------------------
DROP TABLE IF EXISTS `sys_role_menu`;
CREATE TABLE `sys_role_menu`  (
  `id` int(0) NOT NULL AUTO_INCREMENT,
  `role_id` int(0) NULL DEFAULT NULL,
  `menu_id` int(0) NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 80 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of sys_role_menu
-- ----------------------------
INSERT INTO `sys_role_menu` VALUES (1, 1, 1);
INSERT INTO `sys_role_menu` VALUES (2, 1, 2);
INSERT INTO `sys_role_menu` VALUES (3, 1, 3);
INSERT INTO `sys_role_menu` VALUES (4, 1, 4);
INSERT INTO `sys_role_menu` VALUES (5, 1, 5);
INSERT INTO `sys_role_menu` VALUES (6, 1, 6);
INSERT INTO `sys_role_menu` VALUES (7, 1, 8);
INSERT INTO `sys_role_menu` VALUES (8, 1, 9);
INSERT INTO `sys_role_menu` VALUES (9, 1, 10);
INSERT INTO `sys_role_menu` VALUES (10, 1, 11);
INSERT INTO `sys_role_menu` VALUES (11, 1, 12);
INSERT INTO `sys_role_menu` VALUES (12, 1, 13);
INSERT INTO `sys_role_menu` VALUES (13, 1, 14);
INSERT INTO `sys_role_menu` VALUES (14, 1, 16);
INSERT INTO `sys_role_menu` VALUES (15, 1, 18);
INSERT INTO `sys_role_menu` VALUES (16, 1, 19);
INSERT INTO `sys_role_menu` VALUES (17, 1, 21);
INSERT INTO `sys_role_menu` VALUES (18, 1, 23);
INSERT INTO `sys_role_menu` VALUES (19, 1, 24);
INSERT INTO `sys_role_menu` VALUES (20, 1, 26);
INSERT INTO `sys_role_menu` VALUES (21, 1, 28);
INSERT INTO `sys_role_menu` VALUES (22, 1, 30);
INSERT INTO `sys_role_menu` VALUES (23, 1, 31);
INSERT INTO `sys_role_menu` VALUES (24, 1, 32);
INSERT INTO `sys_role_menu` VALUES (25, 1, 34);
INSERT INTO `sys_role_menu` VALUES (26, 1, 36);
INSERT INTO `sys_role_menu` VALUES (27, 1, 38);
INSERT INTO `sys_role_menu` VALUES (28, 1, 39);
INSERT INTO `sys_role_menu` VALUES (29, 1, 41);
INSERT INTO `sys_role_menu` VALUES (30, 1, 42);
INSERT INTO `sys_role_menu` VALUES (31, 1, 44);
INSERT INTO `sys_role_menu` VALUES (32, 1, 45);
INSERT INTO `sys_role_menu` VALUES (33, 1, 47);
INSERT INTO `sys_role_menu` VALUES (34, 1, 48);
INSERT INTO `sys_role_menu` VALUES (35, 1, 49);
INSERT INTO `sys_role_menu` VALUES (36, 1, 51);
INSERT INTO `sys_role_menu` VALUES (37, 1, 52);
INSERT INTO `sys_role_menu` VALUES (38, 1, 53);
INSERT INTO `sys_role_menu` VALUES (39, 1, 54);
INSERT INTO `sys_role_menu` VALUES (40, 1, 55);
INSERT INTO `sys_role_menu` VALUES (41, 1, 57);
INSERT INTO `sys_role_menu` VALUES (42, 1, 59);
INSERT INTO `sys_role_menu` VALUES (43, 1, 61);
INSERT INTO `sys_role_menu` VALUES (44, 1, 63);
INSERT INTO `sys_role_menu` VALUES (45, 1, 64);
INSERT INTO `sys_role_menu` VALUES (46, 1, 65);
INSERT INTO `sys_role_menu` VALUES (47, 1, 66);
INSERT INTO `sys_role_menu` VALUES (48, 1, 68);
INSERT INTO `sys_role_menu` VALUES (49, 1, 69);
INSERT INTO `sys_role_menu` VALUES (50, 1, 70);
INSERT INTO `sys_role_menu` VALUES (51, 1, 72);
INSERT INTO `sys_role_menu` VALUES (52, 1, 73);
INSERT INTO `sys_role_menu` VALUES (53, 1, 75);
INSERT INTO `sys_role_menu` VALUES (54, 1, 77);
INSERT INTO `sys_role_menu` VALUES (55, 1, 78);
INSERT INTO `sys_role_menu` VALUES (56, 1, 79);
INSERT INTO `sys_role_menu` VALUES (57, 1, 80);
INSERT INTO `sys_role_menu` VALUES (58, 1, 81);
INSERT INTO `sys_role_menu` VALUES (59, 1, 82);
INSERT INTO `sys_role_menu` VALUES (60, 1, 83);
INSERT INTO `sys_role_menu` VALUES (61, 1, 84);
INSERT INTO `sys_role_menu` VALUES (62, 1, 85);
INSERT INTO `sys_role_menu` VALUES (63, 1, 86);
INSERT INTO `sys_role_menu` VALUES (64, 1, 87);
INSERT INTO `sys_role_menu` VALUES (65, 1, 88);
INSERT INTO `sys_role_menu` VALUES (66, 1, 89);
INSERT INTO `sys_role_menu` VALUES (67, 1, 90);
INSERT INTO `sys_role_menu` VALUES (68, 1, 91);
INSERT INTO `sys_role_menu` VALUES (69, 1, 92);
INSERT INTO `sys_role_menu` VALUES (70, 1, 93);
INSERT INTO `sys_role_menu` VALUES (71, 1, 95);
INSERT INTO `sys_role_menu` VALUES (72, 1, 96);
INSERT INTO `sys_role_menu` VALUES (73, 1, 97);
INSERT INTO `sys_role_menu` VALUES (74, 1, 100);
INSERT INTO `sys_role_menu` VALUES (75, 1, 101);
INSERT INTO `sys_role_menu` VALUES (76, 1, 102);
INSERT INTO `sys_role_menu` VALUES (77, 1, 103);
INSERT INTO `sys_role_menu` VALUES (78, 1, 104);
INSERT INTO `sys_role_menu` VALUES (79, 1, 106);
INSERT INTO `sys_role_menu` VALUES (80, 1, 107);

-- ----------------------------
-- Table structure for sys_user
-- ----------------------------
DROP TABLE IF EXISTS `sys_user`;
CREATE TABLE `sys_user`  (
  `user_id` int(0) NOT NULL AUTO_INCREMENT COMMENT '用户ID',
  `dept_id` int(0) NULL DEFAULT NULL COMMENT '部门ID',
  `login_name` varchar(30) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '登录账号',
  `user_name` varchar(30) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '用户昵称',
  `user_type` varchar(2) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT '00' COMMENT '用户类型（00系统用户）',
  `email` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT '' COMMENT '用户邮箱',
  `phonenumber` varchar(11) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT '' COMMENT '手机号码',
  `sex` char(1) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT '0' COMMENT '用户性别（0男 1女 2未知）',
  `avatar` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT '' COMMENT '头像路径',
  `password` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT '' COMMENT '密码',
  `salt` varchar(20) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT '' COMMENT '盐加密',
  `status` char(1) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT '0' COMMENT '帐号状态（0正常 1停用）',
  `del_flag` char(1) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT '0' COMMENT '删除标志（0代表存在 2代表删除）',
  `login_ip` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT '' COMMENT '最后登陆IP',
  `login_date` datetime(0) NULL DEFAULT NULL COMMENT '最后登陆时间',
  `create_by` varchar(64) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT '' COMMENT '创建者',
  `create_time` datetime(0) NULL DEFAULT NULL COMMENT '创建时间',
  `update_by` varchar(64) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT '' COMMENT '更新者',
  `update_time` datetime(0) NULL DEFAULT NULL COMMENT '更新时间',
  `remark` varchar(500) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT '' COMMENT '备注',
  PRIMARY KEY (`user_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 4 CHARACTER SET = utf8 COLLATE = utf8_general_ci COMMENT = '用户信息表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of sys_user
-- ----------------------------
INSERT INTO `sys_user` VALUES (1, 103, 'admin', '若依', '00', 'ry@163.com', '15888888888', '1', '', '3d3e2e119996cedb7401025cced5c1b0', '111111', '0', '0', '127.0.0.1', '2019-06-12 17:56:55', 'admin', '2018-03-16 11:33:00', 'ry', '2019-06-12 17:56:55', '管理员');
INSERT INTO `sys_user` VALUES (2, 105, 'ry', '若依', '00', 'ry@qq.com', '15666666666', '1', '', '8e6d98b90472783cc73c17047ddccf36', '222222', '1', '0', '127.0.0.1', '2018-03-16 11:33:00', 'admin', '2018-03-16 11:33:00', 'ry', '2019-06-06 16:19:22', '测试员');
INSERT INTO `sys_user` VALUES (3, 105, 'ry1111', '若依', '00', '', '', '0', '', '', '', '0', '0', '', NULL, '', '2019-05-30 16:10:02', '', '2019-06-12 14:49:36', '测试员');
INSERT INTO `sys_user` VALUES (4, 105, '2ry2', '若依', '00', '', '', '0', '', '', '', '0', '0', '', NULL, '', '2019-05-30 16:10:22', '', '2019-06-12 14:49:42', '测试员');

-- ----------------------------
-- Table structure for sys_user_role
-- ----------------------------
DROP TABLE IF EXISTS `sys_user_role`;
CREATE TABLE `sys_user_role`  (
  `user_id` int(0) NOT NULL COMMENT '用户ID',
  `role_id` int(0) NOT NULL COMMENT '角色ID',
  PRIMARY KEY (`user_id`, `role_id`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci COMMENT = '用户和角色关联表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of sys_user_role
-- ----------------------------
INSERT INTO `sys_user_role` VALUES (1, 1);
INSERT INTO `sys_user_role` VALUES (1, 2);
INSERT INTO `sys_user_role` VALUES (2, 2);
INSERT INTO `sys_user_role` VALUES (3, 2);
INSERT INTO `sys_user_role` VALUES (4, 2);

SET FOREIGN_KEY_CHECKS = 1;
